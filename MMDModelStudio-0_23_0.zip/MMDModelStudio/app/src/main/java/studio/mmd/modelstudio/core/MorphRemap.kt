package studio.mmd.modelstudio.core

import kotlin.math.abs

/**
 * Remapeamento de morphs de vértice quando a malha muda (Extrudir, Inset, Subdividir, Apagar face, Limpar).
 * Cada vértice novo procura o vértice antigo mais próximo (espaço local do objeto):
 *  - se coincide com um antigo, copia o deslocamento dele;
 *  - se fica exatamente no meio de dois ou mais antigos (ponto médio de aresta da Subdivisão), usa a MÉDIA dos
 *    deslocamentos deles (interpolação linear);
 *  - caso contrário copia o deslocamento do mais próximo.
 * Vértices que ficam sem deslocamento saem da lista; se nenhum sobra, devolve null (o morph deve ser descartado).
 */
object MorphRemap {
    fun remap(oldPos: FloatArray, m: Morph, newPos: FloatArray): Morph? {
        val on = oldPos.size / 3
        val nn = newPos.size / 3
        if (m.isGroup || on == 0 || nn == 0) return null
        // deslocamento por vértice antigo (zero para quem não está no morph)
        val dense = FloatArray(on * 3)
        for (k in m.idx.indices) {
            val v = m.idx[k]
            if (v < 0 || v >= on || k * 3 + 2 >= m.d.size) continue
            dense[v * 3] = m.d[k * 3]
            dense[v * 3 + 1] = m.d[k * 3 + 1]
            dense[v * 3 + 2] = m.d[k * 3 + 2]
        }
        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var minZ = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE; var maxZ = -Float.MAX_VALUE
        for (i in 0 until on) {
            val x = oldPos[i * 3]; val y = oldPos[i * 3 + 1]; val z = oldPos[i * 3 + 2]
            if (x < minX) minX = x; if (x > maxX) maxX = x
            if (y < minY) minY = y; if (y > maxY) maxY = y
            if (z < minZ) minZ = z; if (z > maxZ) maxZ = z
        }
        val ext = maxOf(maxX - minX, maxY - minY, maxZ - minZ, 1e-4f)
        val dim = Math.ceil(Math.cbrt(on.toDouble())).toInt().coerceIn(1, 64)
        val cell = ext / dim
        fun cellOf(v: Float, mn: Float): Int = ((v - mn) / cell).toInt().coerceIn(0, dim - 1)
        fun keyOf(ix: Int, iy: Int, iz: Int): Int = (ix * dim + iy) * dim + iz
        val grid = HashMap<Int, ArrayList<Int>>()
        for (i in 0 until on) {
            val k = keyOf(cellOf(oldPos[i * 3], minX), cellOf(oldPos[i * 3 + 1], minY), cellOf(oldPos[i * 3 + 2], minZ))
            grid.getOrPut(k) { ArrayList() }.add(i)
        }
        val candI = ArrayList<Int>()
        val candD = ArrayList<Float>()
        val outIdx = ArrayList<Int>()
        val outD = ArrayList<Float>()
        for (v in 0 until nn) {
            val px = newPos[v * 3]; val py = newPos[v * 3 + 1]; val pz = newPos[v * 3 + 2]
            val cx = cellOf(px, minX); val cy = cellOf(py, minY); val cz = cellOf(pz, minZ)
            candI.clear(); candD.clear()
            var best = -1
            var bestD = Float.MAX_VALUE
            var r = 0
            while (r < dim) {
                for (ix in maxOf(0, cx - r)..minOf(dim - 1, cx + r)) {
                    for (iy in maxOf(0, cy - r)..minOf(dim - 1, cy + r)) {
                        for (iz in maxOf(0, cz - r)..minOf(dim - 1, cz + r)) {
                            if (maxOf(abs(ix - cx), abs(iy - cy), abs(iz - cz)) != r) continue
                            val list = grid[keyOf(ix, iy, iz)] ?: continue
                            for (i in list) {
                                val dx = oldPos[i * 3] - px; val dy = oldPos[i * 3 + 1] - py; val dz = oldPos[i * 3 + 2] - pz
                                val d = dx * dx + dy * dy + dz * dz
                                candI.add(i); candD.add(d)
                                if (d < bestD) { bestD = d; best = i }
                            }
                        }
                    }
                }
                // qualquer ponto fora das cascas já vistas está a pelo menos r*cell (com folga de 0,2% para os empates)
                if (best >= 0) {
                    val reach = r * cell
                    if (bestD * 1.002f <= reach * reach) break
                }
                r++
            }
            if (best < 0) continue
            var sx = 0f; var sy = 0f; var sz = 0f
            if (bestD < 1e-10f) {
                // coincide com um vértice antigo: copia o dele
                sx = dense[best * 3]; sy = dense[best * 3 + 1]; sz = dense[best * 3 + 2]
            } else {
                val lim = bestD * 1.002f + 1e-12f
                var n = 0
                for (j in candI.indices) {
                    if (candD[j] <= lim) {
                        val i = candI[j]
                        sx += dense[i * 3]; sy += dense[i * 3 + 1]; sz += dense[i * 3 + 2]
                        n++
                    }
                }
                if (n > 0) { sx /= n; sy /= n; sz /= n }
            }
            if (sx * sx + sy * sy + sz * sz > 1e-12f) {
                outIdx.add(v); outD.add(sx); outD.add(sy); outD.add(sz)
            }
        }
        if (outIdx.isEmpty()) return null
        return m.copy(idx = outIdx.toIntArray(), d = outD.toFloatArray())
    }
}
