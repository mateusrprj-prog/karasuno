package studio.mmd.modelstudio.core

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Transformações afins 3x4 em DoubleArray(12): [0..8] = matriz 3x3 (linha a linha), [9..11] = translação.
 * Mesma convenção do renderizador e do exportador PMX: T · Ry · Rx · Rz · S.
 */
object Xform {
    fun identity(): DoubleArray = doubleArrayOf(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0)

    private fun mul3(x: DoubleArray, y: DoubleArray): DoubleArray {
        val r = DoubleArray(9)
        for (i in 0..2) for (j in 0..2) r[i * 3 + j] = x[i * 3] * y[j] + x[i * 3 + 1] * y[3 + j] + x[i * 3 + 2] * y[6 + j]
        return r
    }

    /** Matriz de rotação 3x3 (graus): Ry · Rx · Rz. */
    fun rotation(r: Vec3): DoubleArray {
        val rx = Math.toRadians(r.x.toDouble()); val ry = Math.toRadians(r.y.toDouble()); val rz = Math.toRadians(r.z.toDouble())
        val cx = cos(rx); val sx = sin(rx); val cy = cos(ry); val sy = sin(ry); val cz = cos(rz); val sz = sin(rz)
        val rX = doubleArrayOf(1.0, 0.0, 0.0, 0.0, cx, -sx, 0.0, sx, cx)
        val rY = doubleArrayOf(cy, 0.0, sy, 0.0, 1.0, 0.0, -sy, 0.0, cy)
        val rZ = doubleArrayOf(cz, -sz, 0.0, sz, cz, 0.0, 0.0, 0.0, 1.0)
        return mul3(mul3(rY, rX), rZ)
    }

    /** a ∘ b: aplica b primeiro, depois a. */
    fun compose(a: DoubleArray, b: DoubleArray): DoubleArray {
        val r = DoubleArray(12)
        val m = mul3(a, b)
        for (i in 0..8) r[i] = m[i]
        for (i in 0..2) r[9 + i] = a[i * 3] * b[9] + a[i * 3 + 1] * b[10] + a[i * 3 + 2] * b[11] + a[9 + i]
        return r
    }

    /** Matriz de mundo do objeto (pai incluído). Limite de profundidade protege contra ciclos. */
    fun world(o: SceneObject, byId: Map<String, SceneObject>, depth: Int = 0): DoubleArray {
        val rot = rotation(o.rotation)
        val s = o.scale.toDouble()
        val local = DoubleArray(12)
        for (i in 0..8) local[i] = rot[i] * s
        local[9] = o.position.x.toDouble(); local[10] = o.position.y.toDouble(); local[11] = o.position.z.toDouble()
        val p = o.parentId?.let { byId[it] }
        if (p == null || depth >= 32) return local
        return compose(world(p, byId, depth + 1), local)
    }

    /** Aplica m ao ponto (x, y, z) e grava o resultado em out[0..2]. */
    fun applyTo(m: DoubleArray, x: Double, y: Double, z: Double, out: DoubleArray) {
        out[0] = m[0] * x + m[1] * y + m[2] * z + m[9]
        out[1] = m[3] * x + m[4] * y + m[5] * z + m[10]
        out[2] = m[6] * x + m[7] * y + m[8] * z + m[11]
    }

    /** Inversa de uma transformação afim; null se a matriz for singular. */
    fun inverse(m: DoubleArray): DoubleArray? {
        val a = m[0]; val b = m[1]; val c = m[2]
        val d = m[3]; val e = m[4]; val f = m[5]
        val g = m[6]; val h = m[7]; val k = m[8]
        val det = a * (e * k - f * h) - b * (d * k - f * g) + c * (d * h - e * g)
        if (abs(det) < 1e-12) return null
        val inv = 1.0 / det
        val r = DoubleArray(12)
        r[0] = (e * k - f * h) * inv; r[1] = (c * h - b * k) * inv; r[2] = (b * f - c * e) * inv
        r[3] = (f * g - d * k) * inv; r[4] = (a * k - c * g) * inv; r[5] = (c * d - a * f) * inv
        r[6] = (d * h - e * g) * inv; r[7] = (b * g - a * h) * inv; r[8] = (a * e - b * d) * inv
        for (i in 0..2) r[9 + i] = -(r[i * 3] * m[9] + r[i * 3 + 1] * m[10] + r[i * 3 + 2] * m[11])
        return r
    }
}
