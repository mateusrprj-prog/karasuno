package studio.mmd.modelstudio.core

import kotlin.math.abs

/**
 * Pesos por vértice: até 4 influências (osso, peso) por vértice. Imutável por convenção.
 * [palette] = ids dos ossos usados; [idx] e [w] têm 4 posições por vértice (idx = posição na palette; -1 = vazio).
 * Os pesos de um vértice somam 1 (ou o vértice não tem nenhuma influência).
 */
class VertexWeights(val palette: List<String>, val idx: IntArray, val w: FloatArray) {
    val vertexCount: Int get() = idx.size / 4
}

class WeightEdit(val weights: VertexWeights?, val changed: Int)

/** Operações puras sobre pesos (sem Android). Cada operação devolve um VertexWeights novo. */
object Weighting {
    private const val MAX_INF = 4
    private const val MIN_W = 0.01f

    private class Seg(val id: String, val ax: Float, val ay: Float, val az: Float, val bx: Float, val by: Float, val bz: Float)

    fun toMaps(vw: VertexWeights?, vertexCount: Int): Array<HashMap<String, Float>> {
        val maps = Array(vertexCount) { HashMap<String, Float>(4) }
        if (vw != null && vw.vertexCount == vertexCount) {
            for (v in 0 until vertexCount) {
                for (k in 0 until 4) {
                    val i = vw.idx[v * 4 + k]
                    val x = vw.w[v * 4 + k]
                    if (i < 0 || i >= vw.palette.size || x <= 0f) continue
                    val id = vw.palette[i]
                    maps[v][id] = (maps[v][id] ?: 0f) + x
                }
            }
        }
        return maps
    }

    /** Fica com as 4 maiores influências de cada vértice, descarta as menores que 1% e normaliza para somar 1. */
    fun fromMaps(maps: Array<HashMap<String, Float>>): VertexWeights? {
        val palette = ArrayList<String>()
        val pIndex = HashMap<String, Int>()
        val n = maps.size
        val idx = IntArray(n * 4) { -1 }
        val w = FloatArray(n * 4)
        var any = false
        for (v in 0 until n) {
            val top = maps[v].entries.filter { it.value > 0f }.sortedByDescending { it.value }.take(MAX_INF)
            var sum = 0f
            for (e in top) sum += e.value
            if (sum <= 0f) continue
            val kept = top.filter { it.value / sum >= MIN_W }
            var sum2 = 0f
            for (e in kept) sum2 += e.value
            if (sum2 <= 0f) continue
            any = true
            var k = 0
            for (e in kept) {
                val key = e.key
                var pi = pIndex[key]
                if (pi == null) {
                    palette.add(key)
                    pi = palette.size - 1
                    pIndex[key] = pi
                }
                idx[v * 4 + k] = pi
                w[v * 4 + k] = e.value / sum2
                k++
            }
        }
        return if (any) VertexWeights(palette, idx, w) else null
    }

    /** Influências do vértice, da maior para a menor. */
    fun influences(vw: VertexWeights, v: Int): List<Pair<String, Float>> {
        val out = ArrayList<Pair<String, Float>>()
        if (v < 0 || v >= vw.vertexCount) return out
        for (k in 0 until 4) {
            val i = vw.idx[v * 4 + k]
            val x = vw.w[v * 4 + k]
            if (i < 0 || i >= vw.palette.size || x <= 0f) continue
            out.add(Pair(vw.palette[i], x))
        }
        return out
    }

    /** Peso de cada vértice no osso [boneId] (0..1). Objeto sem pesos ligado a esse osso conta 1 em todos os vértices. */
    fun weightOf(o: SceneObject, boneId: String): FloatArray {
        val n = o.mesh.vertexCount
        val out = FloatArray(n)
        val w = o.weights
        if (w != null && w.vertexCount == n) {
            for (v in 0 until n) {
                for (k in 0 until 4) {
                    val i = w.idx[v * 4 + k]
                    if (i >= 0 && i < w.palette.size && w.palette[i] == boneId) out[v] += w.w[v * 4 + k]
                }
            }
        } else if (o.boneId == boneId) {
            for (v in 0 until n) out[v] = 1f
        }
        return out
    }

    fun countWeighted(vw: VertexWeights): Int {
        var c = 0
        for (v in 0 until vw.vertexCount) {
            var any = false
            for (k in 0 until 4) if (vw.idx[v * 4 + k] >= 0 && vw.w[v * 4 + k] > 0f) any = true
            if (any) c++
        }
        return c
    }

    /** Posições dos vértices no mundo (x, y, z intercalados). */
    fun worldPositions(o: SceneObject, byId: Map<String, SceneObject>): FloatArray {
        val m = Xform.world(o, byId)
        val src = o.mesh.positions
        val out = FloatArray(src.size)
        val tmp = DoubleArray(3)
        for (v in 0 until o.mesh.vertexCount) {
            Xform.applyTo(m, src[v * 3].toDouble(), src[v * 3 + 1].toDouble(), src[v * 3 + 2].toDouble(), tmp)
            out[v * 3] = tmp[0].toFloat(); out[v * 3 + 1] = tmp[1].toFloat(); out[v * 3 + 2] = tmp[2].toFloat()
        }
        return out
    }

    // ---------- pesos automáticos ----------
    private fun segments(bones: List<Bone>): List<Seg> {
        val byId = bones.associateBy { it.id }
        // o osso "centro" (raiz de movimento) não deforma nada: fica de fora, se houver outros
        val usable = bones.filter { it.ik == null && !(it.parentId == null && (it.id == "b:center" || it.name == "センター")) }.ifEmpty { bones.filter { it.ik == null }.ifEmpty { bones } }
        val out = ArrayList<Seg>()
        for (b in usable) {
            val p = b.position
            var tx = p.x; var ty = p.y; var tz = p.z
            val child = bones.firstOrNull { it.parentId == b.id && it.ik == null }
            val parent = b.parentId?.let { byId[it] }
            if (child != null) {
                tx = child.position.x; ty = child.position.y; tz = child.position.z
            } else if (parent != null) {
                var dx = p.x - parent.position.x; var dy = p.y - parent.position.y; var dz = p.z - parent.position.z
                if (dx * dx + dy * dy + dz * dz < 1e-8f) { dx = 0f; dy = 0.1f; dz = 0f } else { dx *= 0.5f; dy *= 0.5f; dz *= 0.5f }
                tx = p.x + dx; ty = p.y + dy; tz = p.z + dz
            }
            out.add(Seg(b.id, p.x, p.y, p.z, tx, ty, tz))
        }
        return out
    }

    private fun distSeg(px: Float, py: Float, pz: Float, s: Seg): Float {
        val abx = s.bx - s.ax; val aby = s.by - s.ay; val abz = s.bz - s.az
        val apx = px - s.ax; val apy = py - s.ay; val apz = pz - s.az
        val l2 = abx * abx + aby * aby + abz * abz
        var t = if (l2 < 1e-12f) 0f else (apx * abx + apy * aby + apz * abz) / l2
        if (t < 0f) t = 0f
        if (t > 1f) t = 1f
        val dx = px - (s.ax + abx * t); val dy = py - (s.ay + aby * t); val dz = pz - (s.az + abz * t)
        return Math.sqrt((dx * dx + dy * dy + dz * dz).toDouble()).toFloat()
    }

    /**
     * Proposta automática: cada vértice recebe peso dos 4 ossos mais próximos (distância até o segmento osso→filho),
     * com peso 1/(d²+0,0025)^1,5; influências abaixo de 5% são descartadas. [world] = posições no mundo.
     * [targets] = vértices a recalcular (null = todos); os demais mantêm o peso de [base].
     */
    fun auto(world: FloatArray, bones: List<Bone>, base: VertexWeights?, targets: Set<Int>?): VertexWeights? {
        val n = world.size / 3
        val segs = segments(bones)
        if (segs.isEmpty()) return base
        val maps = toMaps(base, n)
        val range: Iterable<Int> = targets ?: (0 until n)
        for (v in range) {
            if (v < 0 || v >= n) continue
            val px = world[v * 3]; val py = world[v * 3 + 1]; val pz = world[v * 3 + 2]
            val ds = FloatArray(segs.size) { distSeg(px, py, pz, segs[it]) }
            val order = ds.indices.sortedBy { ds[it] }.take(MAX_INF)
            val raw = DoubleArray(order.size)
            var total = 0.0
            for ((k, si) in order.withIndex()) {
                val d = ds[si].toDouble()
                raw[k] = 1.0 / Math.pow(d * d + 0.0025, 1.5)
                total += raw[k]
            }
            val m = maps[v]
            m.clear()
            for ((k, si) in order.withIndex()) {
                val f = raw[k] / total
                if (f >= 0.05) m[segs[si].id] = f.toFloat()
            }
        }
        return fromMaps(maps)
    }

    // ---------- pintura manual (sobre os vértices selecionados) ----------
    fun assign(base: VertexWeights?, n: Int, sel: Set<Int>, boneId: String): WeightEdit {
        val maps = toMaps(base, n)
        var changed = 0
        for (v in sel) {
            if (v < 0 || v >= n) continue
            maps[v].clear()
            maps[v][boneId] = 1f
            changed++
        }
        return WeightEdit(fromMaps(maps), changed)
    }

    fun clear(base: VertexWeights?, n: Int, sel: Set<Int>): WeightEdit {
        val maps = toMaps(base, n)
        var changed = 0
        for (v in sel) {
            if (v < 0 || v >= n) continue
            maps[v].clear()
            changed++
        }
        return WeightEdit(fromMaps(maps), changed)
    }

    /** Aplica [delta] ao peso de [boneId] num vértice (mapa osso→peso). Devolve true se mudou algo. */
    private fun adjustOne(m: HashMap<String, Float>, boneId: String, delta: Float): Boolean {
        val cur = m[boneId] ?: 0f
        val target = (cur + delta).coerceIn(0f, 1f)
        var others = 0f
        for ((k, x) in m) if (k != boneId) others += x
        if (others <= 1e-6f) {
            // sem outro osso para ceder ou receber peso: só dá para ligar ao osso (100%)
            if (delta > 0f && cur < 0.999f) { m.clear(); m[boneId] = 1f; return true }
            return false
        }
        if (abs(target - cur) < 1e-6f) return false
        val f = (1f - target) / others
        val keys = ArrayList<String>(m.keys)
        for (k in keys) if (k != boneId) m[k] = (m[k] ?: 0f) * f
        if (target > 0f) m[boneId] = target else m.remove(boneId)
        return true
    }

    /** Soma [delta] (-1..1) ao peso do osso; os outros ossos do vértice dividem o que sobra, na mesma proporção. */
    fun adjust(base: VertexWeights?, n: Int, sel: Set<Int>, boneId: String, delta: Float): WeightEdit {
        val maps = toMaps(base, n)
        var changed = 0
        for (v in sel) {
            if (v < 0 || v >= n) continue
            if (adjustOne(maps[v], boneId, delta)) changed++
        }
        return WeightEdit(fromMaps(maps), changed)
    }

    /**
     * Pincel: todo vértice a até [radius] de (cx,cy,cz) (espaço local do objeto) recebe [delta] vezes a queda linear
     * (1 no centro, 0 na borda). [delta] positivo pinta o osso; negativo apaga.
     */
    fun brush(base: VertexWeights?, positions: FloatArray, boneId: String, cx: Float, cy: Float, cz: Float, radius: Float, delta: Float): WeightEdit {
        val n = positions.size / 3
        val maps = toMaps(base, n)
        var changed = 0
        val r2 = radius * radius
        if (radius <= 0f) return WeightEdit(base, 0)
        for (v in 0 until n) {
            val dx = positions[v * 3] - cx; val dy = positions[v * 3 + 1] - cy; val dz = positions[v * 3 + 2] - cz
            val d2 = dx * dx + dy * dy + dz * dz
            if (d2 > r2) continue
            val fall = 1f - kotlin.math.sqrt(d2) / radius
            if (fall <= 0.02f) continue
            if (adjustOne(maps[v], boneId, delta * fall)) changed++
        }
        return if (changed == 0) WeightEdit(base, 0) else WeightEdit(fromMaps(maps), changed)
    }

    /** Troca os ossos do vértice pelos do lado oposto segundo [swap] (copia de pesos espelhada). */
    fun swapped(m: HashMap<String, Float>, swap: (String) -> String): HashMap<String, Float> {
        val out = HashMap<String, Float>(4)
        for ((k, x) in m) { val k2 = swap(k); out[k2] = (out[k2] ?: 0f) + x }
        return out
    }

    /** Espelha pesos: para cada par (origem → destino) em [partners], o destino recebe os pesos da origem com ossos trocados por [swap]. */
    fun mirror(base: VertexWeights?, n: Int, partners: Map<Int, Int>, swap: (String) -> String): WeightEdit {
        if (base == null) return WeightEdit(null, 0)
        val maps = toMaps(base, n)
        val src = Array(n) { maps[it] }
        var changed = 0
        for ((i, j) in partners) {
            if (i < 0 || i >= n || j < 0 || j >= n) continue
            maps[j] = swapped(src[i], swap)
            changed++
        }
        return WeightEdit(fromMaps(maps), changed)
    }

    /** Pincel de suavizar: vértices a até [radius] do centro recebem a média com os vizinhos (uma passada por toque). */
    fun brushSmooth(base: VertexWeights?, mesh: MeshData, cx: Float, cy: Float, cz: Float, radius: Float): WeightEdit {
        if (base == null || radius <= 0f) return WeightEdit(base, 0)
        val p = mesh.positions
        val sel = HashSet<Int>()
        val r2 = radius * radius
        for (v in 0 until p.size / 3) {
            val dx = p[v * 3] - cx; val dy = p[v * 3 + 1] - cy; val dz = p[v * 3 + 2] - cz
            if (dx * dx + dy * dy + dz * dz <= r2) sel.add(v)
        }
        if (sel.isEmpty()) return WeightEdit(base, 0)
        return smooth(base, mesh, sel)
    }

    /** Suaviza: cada vértice selecionado recebe a média dos pesos dele e dos vizinhos (uma passada). */
    fun smooth(base: VertexWeights?, mesh: MeshData, sel: Set<Int>): WeightEdit {
        val n = mesh.vertexCount
        val maps = toMaps(base, n)
        val nb = Array(n) { HashSet<Int>() }
        for (t in 0 until mesh.triangleCount) {
            val a = mesh.indices[t * 3]; val b = mesh.indices[t * 3 + 1]; val c = mesh.indices[t * 3 + 2]
            nb[a].add(b); nb[a].add(c); nb[b].add(a); nb[b].add(c); nb[c].add(a); nb[c].add(b)
        }
        val result = HashMap<Int, HashMap<String, Float>>()
        for (v in sel) {
            if (v < 0 || v >= n) continue
            val acc = HashMap<String, Float>()
            for ((k, x) in maps[v]) acc[k] = (acc[k] ?: 0f) + x
            for (u in nb[v]) for ((k, x) in maps[u]) acc[k] = (acc[k] ?: 0f) + x
            result[v] = acc
        }
        for ((v, acc) in result) maps[v] = acc
        return WeightEdit(fromMaps(maps), result.size)
    }

    /**
     * Remapeia pesos depois de uma mudança de topologia: cada vértice novo copia os pesos do vértice ANTIGO mais próximo
     * (posições no espaço local do objeto). Vértice que não mudou de lugar copia o seu próprio (distância 0).
     * Usa uma grade espacial, então é rápido mesmo com dezenas de milhares de vértices.
     */
    fun remap(oldPos: FloatArray, base: VertexWeights, newPos: FloatArray): VertexWeights? {
        val on = oldPos.size / 3
        val nn = newPos.size / 3
        if (on == 0 || nn == 0 || base.vertexCount != on) return null
        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var minZ = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE; var maxZ = -Float.MAX_VALUE
        for (i in 0 until on) {
            val x = oldPos[i * 3]; val y = oldPos[i * 3 + 1]; val z = oldPos[i * 3 + 2]
            if (x < minX) minX = x; if (x > maxX) maxX = x
            if (y < minY) minY = y; if (y > maxY) maxY = y
            if (z < minZ) minZ = z; if (z > maxZ) maxZ = z
        }
        val ext = maxOf(maxX - minX, maxY - minY, maxZ - minZ, 1e-4f)
        val dim = Math.ceil(Math.cbrt(on.toDouble())).toInt().coerceIn(1, 64)
        val cell = ext / dim
        fun cellOf(v: Float, mn: Float): Int = ((v - mn) / cell).toInt().coerceIn(0, dim - 1)
        fun keyOf(ix: Int, iy: Int, iz: Int): Int = (ix * dim + iy) * dim + iz
        val grid = HashMap<Int, ArrayList<Int>>()
        for (i in 0 until on) {
            val k = keyOf(cellOf(oldPos[i * 3], minX), cellOf(oldPos[i * 3 + 1], minY), cellOf(oldPos[i * 3 + 2], minZ))
            grid.getOrPut(k) { ArrayList() }.add(i)
        }
        val oldMaps = toMaps(base, on)
        val newMaps = Array(nn) { HashMap<String, Float>(4) }
        for (v in 0 until nn) {
            val px = newPos[v * 3]; val py = newPos[v * 3 + 1]; val pz = newPos[v * 3 + 2]
            val cx = cellOf(px, minX); val cy = cellOf(py, minY); val cz = cellOf(pz, minZ)
            var best = -1
            var bestD = Float.MAX_VALUE
            var r = 0
            while (r < dim) {
                for (ix in maxOf(0, cx - r)..minOf(dim - 1, cx + r)) {
                    for (iy in maxOf(0, cy - r)..minOf(dim - 1, cy + r)) {
                        for (iz in maxOf(0, cz - r)..minOf(dim - 1, cz + r)) {
                            // só a casca de raio r (o interior já foi visto nas voltas anteriores)
                            if (maxOf(abs(ix - cx), abs(iy - cy), abs(iz - cz)) != r) continue
                            val list = grid[keyOf(ix, iy, iz)] ?: continue
                            for (i in list) {
                                val dx = oldPos[i * 3] - px; val dy = oldPos[i * 3 + 1] - py; val dz = oldPos[i * 3 + 2] - pz
                                val d = dx * dx + dy * dy + dz * dz
                                if (d < bestD) { bestD = d; best = i }
                            }
                        }
                    }
                }
                // qualquer ponto fora desta casca está a pelo menos r*cell de distância
                if (best >= 0) {
                    val reach = r * cell
                    if (bestD <= reach * reach) break
                }
                r++
            }
            if (best >= 0) newMaps[v].putAll(oldMaps[best])
        }
        return fromMaps(newMaps)
    }

    /** Remove das influências os ossos que não estão em [valid] (osso excluído). */
    fun retain(base: VertexWeights?, valid: Set<String>): VertexWeights? {
        if (base == null) return null
        val maps = toMaps(base, base.vertexCount)
        for (m in maps) m.keys.retainAll(valid)
        return fromMaps(maps)
    }
}
