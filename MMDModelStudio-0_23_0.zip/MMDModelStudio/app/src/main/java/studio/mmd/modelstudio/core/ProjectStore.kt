package studio.mmd.modelstudio.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object ProjectJson {
    fun toJson(p: ModelProject): String {
        val root = JSONObject()
        root.put("schemaVersion", p.schemaVersion)
        root.put("name", p.name)
        val arr = JSONArray()
        for (o in p.objects) {
            val jo = JSONObject()
            jo.put("id", o.id)
            jo.put("name", o.name)
            jo.put("position", JSONArray(listOf(o.position.x.toDouble(), o.position.y.toDouble(), o.position.z.toDouble())))
            jo.put("rotation", JSONArray(listOf(o.rotation.x.toDouble(), o.rotation.y.toDouble(), o.rotation.z.toDouble())))
            jo.put("scale", o.scale.toDouble())
            if (o.parentId != null) jo.put("parentId", o.parentId)
            jo.put("visible", o.visible)
            if (o.boneId != null) jo.put("boneId", o.boneId)
            if (o.color != null) jo.put("color", o.color)
            val mesh = JSONObject()
            mesh.put("positions", JSONArray(o.mesh.positions.map { it.toDouble() }))
            mesh.put("indices", JSONArray(o.mesh.indices.toList()))
            jo.put("mesh", mesh)
            val ow = o.weights
            if (ow != null) {
                val jw = JSONObject()
                jw.put("palette", JSONArray(ow.palette))
                jw.put("idx", JSONArray(ow.idx.toList()))
                jw.put("w", JSONArray(ow.w.map { it.toDouble() }))
                jo.put("weights", jw)
            }
            arr.put(jo)
        }
        root.put("objects", arr)
        val ba = JSONArray()
        for (b in p.bones) {
            val jb = JSONObject()
            jb.put("id", b.id)
            jb.put("name", b.name)
            jb.put("nameEn", b.nameEn)
            if (b.parentId != null) jb.put("parentId", b.parentId)
            jb.put("position", JSONArray(listOf(b.position.x.toDouble(), b.position.y.toDouble(), b.position.z.toDouble())))
            b.ik?.let { ik ->
                val ji = JSONObject()
                ji.put("target", ik.targetId)
                ji.put("loops", ik.loops)
                ji.put("limit", ik.limitRad.toDouble())
                val la = JSONArray()
                for (l in ik.links) {
                    val jl = JSONObject()
                    jl.put("bone", l.boneId)
                    jl.put("knee", l.kneeLimit)
                    la.put(jl)
                }
                ji.put("links", la)
                jb.put("ik", ji)
            }
            ba.put(jb)
        }
        root.put("bones", ba)
        val ma = JSONArray()
        for (m in p.morphs) {
            val jm = JSONObject()
            jm.put("id", m.id)
            jm.put("name", m.name)
            jm.put("nameEn", m.nameEn)
            jm.put("panel", m.panel)
            jm.put("objectId", m.objectId)
            val ji = JSONArray(); for (i in m.idx) ji.put(i)
            val jd = JSONArray(); for (x in m.d) jd.put(x.toDouble())
            jm.put("idx", ji)
            jm.put("d", jd)
            if (m.isMaterial) { jm.put("isMaterial", true); jm.put("color", m.color) }
            if (m.isGroup) {
                jm.put("isGroup", true)
                val jg = JSONArray()
                for (g in m.group) { val o = JSONObject(); o.put("morph", g.morphId); o.put("rate", g.rate.toDouble()); jg.put(o) }
                jm.put("group", jg)
            }
            ma.put(jm)
        }
        root.put("morphs", ma)
        return root.toString(2)
    }

    fun fromJson(text: String): ModelProject {
        val root = JSONObject(text)
        val version = root.optInt("schemaVersion", 1)
        if (version > ModelProject.CURRENT_SCHEMA) {
            throw IllegalStateException("Projeto criado em versão mais nova do app (esquema $version).")
        }
        val objs = ArrayList<SceneObject>()
        val arr = root.optJSONArray("objects") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val jo = arr.getJSONObject(i)
            val pos = jo.getJSONArray("position")
            val m = jo.getJSONObject("mesh")
            val pa = m.getJSONArray("positions")
            val ia = m.getJSONArray("indices")
            val positions = FloatArray(pa.length()) { pa.getDouble(it).toFloat() }
            val indices = IntArray(ia.length()) { ia.getInt(it) }
            val rot = jo.optJSONArray("rotation")
            val rotation = if (rot != null && rot.length() >= 3)
                Vec3(rot.getDouble(0).toFloat(), rot.getDouble(1).toFloat(), rot.getDouble(2).toFloat())
            else Vec3(0f, 0f, 0f)
            var weights: VertexWeights? = null
            val jw = jo.optJSONObject("weights")
            if (jw != null) {
                val pal = jw.getJSONArray("palette")
                val ia2 = jw.getJSONArray("idx")
                val wa2 = jw.getJSONArray("w")
                val vw = VertexWeights(
                    List(pal.length()) { pal.getString(it) },
                    IntArray(ia2.length()) { ia2.getInt(it) },
                    FloatArray(wa2.length()) { wa2.getDouble(it).toFloat() }
                )
                // pesos que não casam com a malha são descartados (o objeto volta ao vínculo rígido)
                if (vw.idx.size == vw.w.size && vw.idx.size == (positions.size / 3) * 4) weights = vw
            }
            objs.add(
                SceneObject(
                    id = jo.getString("id"),
                    name = jo.getString("name"),
                    mesh = MeshData(positions, indices),
                    position = Vec3(pos.getDouble(0).toFloat(), pos.getDouble(1).toFloat(), pos.getDouble(2).toFloat()),
                    rotation = rotation,
                    scale = jo.optDouble("scale", 1.0).toFloat(),
                    parentId = if (jo.has("parentId") && !jo.isNull("parentId")) jo.getString("parentId") else null,
                    visible = jo.optBoolean("visible", true),
                    boneId = if (jo.has("boneId") && !jo.isNull("boneId")) jo.getString("boneId") else null,
                    weights = weights,
                    color = if (jo.has("color") && !jo.isNull("color")) jo.getInt("color") else null
                )
            )
        }
        val bones = ArrayList<Bone>()
        val bArr = root.optJSONArray("bones") ?: JSONArray()
        for (i in 0 until bArr.length()) {
            val jb = bArr.getJSONObject(i)
            val bp = jb.getJSONArray("position")
            val ikJson = jb.optJSONObject("ik")
            val ikData = if (ikJson == null) null else {
                val links = ArrayList<IkLink>()
                val la = ikJson.optJSONArray("links") ?: JSONArray()
                for (k in 0 until la.length()) {
                    val jl = la.getJSONObject(k)
                    links.add(IkLink(jl.getString("bone"), jl.optBoolean("knee", false)))
                }
                IkData(ikJson.getString("target"), ikJson.optInt("loops", 40), ikJson.optDouble("limit", 2.0).toFloat(), links)
            }
            bones.add(
                Bone(
                    id = jb.getString("id"),
                    name = jb.getString("name"),
                    nameEn = jb.optString("nameEn", ""),
                    parentId = if (jb.has("parentId") && !jb.isNull("parentId")) jb.getString("parentId") else null,
                    position = Vec3(bp.getDouble(0).toFloat(), bp.getDouble(1).toFloat(), bp.getDouble(2).toFloat()),
                    ik = ikData
                )
            )
        }
        val morphs = ArrayList<Morph>()
        val mArr = root.optJSONArray("morphs") ?: JSONArray()
        for (i in 0 until mArr.length()) {
            val jm = mArr.getJSONObject(i)
            val ji = jm.getJSONArray("idx")
            val jd = jm.getJSONArray("d")
            val n = ji.length()
            if (jd.length() != n * 3) continue // morph corrompido: ignora
            val groupItems = ArrayList<GroupItem>()
            val jg = jm.optJSONArray("group")
            if (jg != null) for (k in 0 until jg.length()) {
                val o = jg.getJSONObject(k)
                groupItems.add(GroupItem(o.getString("morph"), o.optDouble("rate", 1.0).toFloat()))
            }
            morphs.add(
                Morph(
                    id = jm.getString("id"),
                    name = jm.getString("name"),
                    nameEn = jm.optString("nameEn", ""),
                    panel = jm.optInt("panel", 4).coerceIn(1, 4),
                    objectId = jm.getString("objectId"),
                    idx = IntArray(n) { ji.getInt(it) },
                    d = FloatArray(n * 3) { jd.getDouble(it).toFloat() },
                    isGroup = jm.optBoolean("isGroup", false),
                    group = groupItems,
                    isMaterial = jm.optBoolean("isMaterial", false),
                    color = jm.optInt("color", 0)
                )
            )
        }
        return ModelProject(
            schemaVersion = ModelProject.CURRENT_SCHEMA,
            name = root.optString("name", "Projeto sem título"),
            objects = objs,
            bones = bones,
            morphs = morphs
        )
    }
}

/** Salvamento com arquivo temporário + cópia de segurança (.bak) do salvamento anterior. */
class ProjectStore(context: Context) {
    private val dir = File(context.filesDir, "projects").apply { mkdirs() }
    private val file = File(dir, "default.mmdproj.json")

    fun save(project: ModelProject) {
        val tmp = File(dir, "default.mmdproj.json.tmp")
        tmp.writeText(ProjectJson.toJson(project))
        if (file.exists()) file.copyTo(File(dir, "default.mmdproj.json.bak"), overwrite = true)
        if (!tmp.renameTo(file)) {
            tmp.copyTo(file, overwrite = true)
            tmp.delete()
        }
    }

    fun load(): ModelProject? {
        if (!file.exists()) return null
        return ProjectJson.fromJson(file.readText())
    }
}
