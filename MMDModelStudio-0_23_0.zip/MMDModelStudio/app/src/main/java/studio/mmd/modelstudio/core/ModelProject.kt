package studio.mmd.modelstudio.core

/** rotation em graus (X, Y, Z). position/rotation/scale são LOCAIS (relativos ao pai, se houver). */
data class SceneObject(
    val id: String,
    val name: String,
    val mesh: MeshData,
    val position: Vec3 = Vec3(0f, 0f, 0f),
    val rotation: Vec3 = Vec3(0f, 0f, 0f),
    val scale: Float = 1f,
    val parentId: String? = null,
    val visible: Boolean = true,
    /** Osso ao qual o objeto inteiro fica ligado (vínculo rígido, BDEF1 no PMX). null = sem vínculo. */
    val boneId: String? = null,
    /** Pesos por vértice (até 4 ossos por vértice). null = sem pesos: vale o vínculo rígido [boneId]. */
    val weights: VertexWeights? = null,
    /** Cor difusa do material (RGB empacotado 0xRRGGBB). null = padrão (azul de pré-visualização no app; cinza 0,8 no PMX). */
    val color: Int? = null
)

/** Elo de uma cadeia IK. [kneeLimit] = limita a dobra só para um lado em X (joelho/cotovelo), como nos modelos MMD padrão. */
data class IkLink(val boneId: String, val kneeLimit: Boolean)

/** Dados de IK de um osso IK: [targetId] = osso da ponta (ex.: tornozelo); [links] do mais perto da ponta ao mais longe. */
data class IkData(val targetId: String, val loops: Int, val limitRad: Float, val links: List<IkLink>)

/** Osso do esqueleto. [position] é absoluta (mundo). [name] é o nome em japonês usado no PMX. [ik] != null = osso IK. */
data class Bone(
    val id: String,
    val name: String,
    val nameEn: String,
    val parentId: String?,
    val position: Vec3,
    val ik: IkData? = null
)

/**
 * Morph de vértice: deslocamentos (no espaço LOCAL do objeto) de alguns vértices do objeto [objectId].
 * [idx] = índices dos vértices; [d] = 3 valores (dx, dy, dz) por vértice. [panel]: 1 sobrancelha, 2 olho, 3 boca, 4 outro.
 * Os índices valem para a malha como está: mudanças de topologia descartam os morphs do objeto.
 */
data class Morph(
    val id: String,
    val name: String,
    val nameEn: String,
    val panel: Int,
    val objectId: String,
    val idx: IntArray,
    val d: FloatArray,
    /** true = morph de grupo: aciona outros morphs (em [group]); não tem vértices próprios nem objeto. */
    val isGroup: Boolean = false,
    val group: List<GroupItem> = emptyList(),
    /** true = morph de material (cor): leva a cor difusa do material do objeto [objectId] até [color] (0xRRGGBB) com valor 100%. Sem vértices próprios. */
    val isMaterial: Boolean = false,
    val color: Int = 0
)

/** Membro de um morph de grupo: o morph [morphId] entra com [rate] vezes o valor do grupo. */
data class GroupItem(val morphId: String, val rate: Float)

/** Esqueletos prontos. */
object Skeletons {
    /** Humanoide básico com nomes padrão do MMD (esquerda = +X, de frente para +Z do app). Unidades: metros (~1,7 de altura). */
    fun humanoid(): List<Bone> {
        val l = ArrayList<Bone>()
        fun b(id: String, jp: String, en: String, parent: String?, x: Float, y: Float, z: Float) {
            l.add(Bone("b:$id", jp, en, parent?.let { "b:$it" }, Vec3(x, y, z)))
        }
        b("center", "センター", "Center", null, 0f, 0.85f, 0f)
        b("lower", "下半身", "Lower body", "center", 0f, 0.85f, 0f)
        b("upper", "上半身", "Upper body", "center", 0f, 0.95f, 0f)
        b("neck", "首", "Neck", "upper", 0f, 1.45f, 0f)
        b("head", "頭", "Head", "neck", 0f, 1.55f, 0f)
        for ((side, jp, sx) in listOf(Triple("L", "左", 1f), Triple("R", "右", -1f))) {
            b("shoulder$side", jp + "肩", "Shoulder_$side", "upper", 0.08f * sx, 1.40f, 0f)
            b("arm$side", jp + "腕", "Arm_$side", "shoulder$side", 0.20f * sx, 1.40f, 0f)
            b("elbow$side", jp + "ひじ", "Elbow_$side", "arm$side", 0.48f * sx, 1.40f, 0f)
            b("wrist$side", jp + "手首", "Wrist_$side", "elbow$side", 0.72f * sx, 1.40f, 0f)
            b("leg$side", jp + "足", "Leg_$side", "lower", 0.10f * sx, 0.85f, 0f)
            b("knee$side", jp + "ひざ", "Knee_$side", "leg$side", 0.10f * sx, 0.45f, 0f)
            b("ankle$side", jp + "足首", "Ankle_$side", "knee$side", 0.10f * sx, 0.08f, 0f)
        }
        return l
    }
}

/** Projeto interno editável. A exportação PMX (futura) será derivada deste modelo. */
data class ModelProject(
    val schemaVersion: Int = CURRENT_SCHEMA,
    val name: String = "Projeto sem título",
    val objects: List<SceneObject> = emptyList(),
    val bones: List<Bone> = emptyList(),
    val morphs: List<Morph> = emptyList()
) {
    companion object {
        /** 1 = posição/escala; 2 = + rotação; 3 = + pai (hierarquia) e visibilidade; 4 = + esqueleto (ossos) e vínculo objeto→osso; 5 = + pesos por vértice; 6 = + IK nos ossos; 7 = + morphs de vértice e de grupo. Versões antigas abrem normalmente. */
        const val CURRENT_SCHEMA = 7
    }
}

/** Lista em profundidade (pai antes dos filhos) com o nível de cada objeto. Pai ausente conta como raiz. */
fun flattenHierarchy(objects: List<SceneObject>): List<Pair<SceneObject, Int>> {
    val ids = objects.map { it.id }.toSet()
    val children = objects.filter { it.parentId != null && it.parentId in ids }.groupBy { it.parentId }
    val out = ArrayList<Pair<SceneObject, Int>>()
    val seen = HashSet<String>()
    fun visit(o: SceneObject, depth: Int) {
        if (!seen.add(o.id)) return
        out.add(o to depth)
        children[o.id]?.forEach { visit(it, depth + 1) }
    }
    objects.filter { it.parentId == null || it.parentId !in ids }.forEach { visit(it, 0) }
    return out
}
