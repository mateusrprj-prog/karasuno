package studio.mmd.modelstudio.render

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.ViewConfiguration
import studio.mmd.modelstudio.core.SceneObject
import kotlin.math.hypot

/**
 * Viewport 3D. 1 dedo: orbita a câmera. 2 dedos (pinça): aproxima/afasta. Toque curto: seleciona.
 * Os gestos mexem só na câmera da viewport, nunca na orientação real do modelo.
 */
@SuppressLint("ClickableViewAccessibility")
class ViewportView(context: Context) : GLSurfaceView(context) {

    private val renderer = ViewportRenderer()
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    var onPick: (String?) -> Unit
        get() = renderer.onPick
        set(value) { renderer.onPick = value }

    var onVertexPick: (Int) -> Unit
        get() = renderer.onVertexPick
        set(value) { renderer.onVertexPick = value }

    var onFacePick: (Int) -> Unit
        get() = renderer.onFacePick
        set(value) { renderer.onFacePick = value }

    var onBrushHit: (Float, Float, Float) -> Unit
        get() = renderer.onBrushHit
        set(value) { renderer.onBrushHit = value }

    /** Pincel de pesos ligado: 1 dedo pinta em vez de orbitar (a pinça continua dando zoom). */
    @Volatile var brushMode = false
    var onBrushStroke: (Boolean) -> Unit = {}
    private var brushing = false
    private var brushX = 0f
    private var brushY = 0f

    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var moved = false

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            renderer.distance = (renderer.distance / detector.scaleFactor).coerceIn(2f, 60f)
            return true
        }
    })

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 24, 0) // profundidade de 24 bits: evita chiado entre faces próximas
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    fun setScene(
        objects: List<SceneObject>, selectedId: String?, editObjectId: String?, selectedVerts: Set<Int>,
        faceMode: Boolean = false, selectedTris: Set<Int> = emptySet(),
        bones: List<studio.mmd.modelstudio.core.Bone> = emptyList(), selectedBoneId: String? = null,
        weightBoneId: String? = null
    ) {
        renderer.weightBoneId = weightBoneId
        renderer.bones = bones
        renderer.selectedBoneId = selectedBoneId
        renderer.objects = objects
        renderer.selectedId = selectedId
        renderer.editObjectId = editObjectId
        renderer.selectedVerts = selectedVerts
        renderer.faceMode = faceMode
        renderer.selectedTris = selectedTris
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x; lastY = e.y; downX = e.x; downY = e.y; moved = false
                if (brushMode) {
                    brushing = true; brushX = e.x; brushY = e.y
                    onBrushStroke(true)
                    val x = e.x; val y = e.y
                    queueEvent { renderer.pickPoint(x, y) }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (brushing) {
                    if (e.pointerCount == 1 && !scaleDetector.isInProgress && hypot(e.x - brushX, e.y - brushY) > 10f) {
                        brushX = e.x; brushY = e.y
                        val x = e.x; val y = e.y
                        queueEvent { renderer.pickPoint(x, y) }
                    }
                    lastX = e.x; lastY = e.y
                } else if (e.pointerCount == 1 && !scaleDetector.isInProgress) {
                    if (hypot(e.x - downX, e.y - downY) > slop) moved = true
                    val dx = e.x - lastX
                    val dy = e.y - lastY
                    renderer.yaw -= dx * 0.4f
                    renderer.pitch = (renderer.pitch + dy * 0.4f).coerceIn(-89f, 89f)
                    lastX = e.x; lastY = e.y
                }
            }
            MotionEvent.ACTION_POINTER_DOWN -> moved = true
            MotionEvent.ACTION_POINTER_UP -> {
                val idx = if (e.actionIndex == 0) 1 else 0
                if (idx < e.pointerCount) { lastX = e.getX(idx); lastY = e.getY(idx) }
            }
            MotionEvent.ACTION_CANCEL -> {
                if (brushing) { brushing = false; onBrushStroke(false) }
            }
            MotionEvent.ACTION_UP -> {
                if (brushing) { brushing = false; onBrushStroke(false) }
                else if (!moved) {
                    val x = e.x
                    val y = e.y
                    if (renderer.editObjectId != null && renderer.faceMode) queueEvent { renderer.pickFace(x, y) }
                    else if (renderer.editObjectId != null) queueEvent { renderer.pickVertex(x, y) }
                    else queueEvent { renderer.pick(x, y) }
                }
            }
        }
        return true
    }
}
