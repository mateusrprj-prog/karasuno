package studio.mmd.modelstudio.core

/**
 * Pré-visualização de pose (não é salva no projeto): gira ossos e deforma as malhas por "linear blend skinning",
 * do mesmo jeito que o MMD deforma um modelo com BDEF1/BDEF2/BDEF4.
 */
object Skinning {

    /** Transformação de mundo (afim) de cada osso: S_osso = S_pai ∘ T(p) · R · T(−p), com R girando em volta da junta p. */
    fun poseMatrices(bones: List<Bone>, rot: Map<String, Vec3>): Map<String, DoubleArray> {
        val byId = bones.associateBy { it.id }
        val memo = HashMap<String, DoubleArray>()
        fun get(b: Bone, depth: Int): DoubleArray {
            val cached = memo[b.id]
            if (cached != null) return cached
            val r = rot[b.id]?.let { Xform.rotation(it) } ?: Xform.identity()
            val px = b.position.x.toDouble(); val py = b.position.y.toDouble(); val pz = b.position.z.toDouble()
            val local = DoubleArray(12)
            for (i in 0..8) local[i] = r[i]
            local[9] = px - (r[0] * px + r[1] * py + r[2] * pz)
            local[10] = py - (r[3] * px + r[4] * py + r[5] * pz)
            local[11] = pz - (r[6] * px + r[7] * py + r[8] * pz)
            val parent = b.parentId?.let { byId[it] }
            val s = if (parent != null && depth < 64) Xform.compose(get(parent, depth + 1), local) else local
            memo[b.id] = s
            return s
        }
        for (b in bones) get(b, 0)
        return memo
    }

    /** Devolve (objetos deformados, ossos na posição posada). Objetos sem pesos nem osso ficam como estão. */
    fun pose(project: ModelProject, rot: Map<String, Vec3>): Pair<List<SceneObject>, List<Bone>> {
        val mats = poseMatrices(project.bones, rot)
        val byId = project.objects.associateBy { it.id }
        val fallback = project.bones.firstOrNull()?.id
        val objs = project.objects.map { o -> skinObject(o, byId, mats, fallback) ?: o }
        val tmp = DoubleArray(3)
        val bones = project.bones.map { b ->
            val m = mats[b.id]
            if (m == null) b else {
                Xform.applyTo(m, b.position.x.toDouble(), b.position.y.toDouble(), b.position.z.toDouble(), tmp)
                b.copy(position = Vec3(tmp[0].toFloat(), tmp[1].toFloat(), tmp[2].toFloat()))
            }
        }
        return Pair(objs, bones)
    }

    private fun skinObject(o: SceneObject, byId: Map<String, SceneObject>, mats: Map<String, DoubleArray>, fallback: String?): SceneObject? {
        val ow = o.weights?.takeIf { it.vertexCount == o.mesh.vertexCount }
        if (ow == null && o.boneId == null) return null
        val w = Xform.world(o, byId)
        val inv = Xform.inverse(w) ?: return null
        val rigid = mats[o.boneId ?: fallback ?: ""]
        val src = o.mesh.positions
        val n = o.mesh.vertexCount
        val dst = FloatArray(src.size)
        val wp = DoubleArray(3)
        val sp = DoubleArray(3)
        val lp = DoubleArray(3)
        for (v in 0 until n) {
            Xform.applyTo(w, src[v * 3].toDouble(), src[v * 3 + 1].toDouble(), src[v * 3 + 2].toDouble(), wp)
            var ax = 0.0; var ay = 0.0; var az = 0.0; var sum = 0.0
            if (ow != null) {
                for (k in 0 until 4) {
                    val pi = ow.idx[v * 4 + k]
                    val x = ow.w[v * 4 + k].toDouble()
                    if (pi < 0 || pi >= ow.palette.size || x <= 0.0) continue
                    val m = mats[ow.palette[pi]] ?: continue
                    Xform.applyTo(m, wp[0], wp[1], wp[2], sp)
                    ax += sp[0] * x; ay += sp[1] * x; az += sp[2] * x
                    sum += x
                }
            }
            if (sum <= 1e-9) {
                if (rigid != null) {
                    Xform.applyTo(rigid, wp[0], wp[1], wp[2], sp)
                    ax = sp[0]; ay = sp[1]; az = sp[2]
                } else {
                    ax = wp[0]; ay = wp[1]; az = wp[2]
                }
            } else {
                ax /= sum; ay /= sum; az /= sum
            }
            Xform.applyTo(inv, ax, ay, az, lp)
            dst[v * 3] = lp[0].toFloat(); dst[v * 3 + 1] = lp[1].toFloat(); dst[v * 3 + 2] = lp[2].toFloat()
        }
        return o.copy(mesh = MeshData(dst, o.mesh.indices))
    }
}
