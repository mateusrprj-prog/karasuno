package studio.mmd.modelstudio.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import studio.mmd.modelstudio.core.Bone
import studio.mmd.modelstudio.core.IkData
import studio.mmd.modelstudio.core.IkLink
import studio.mmd.modelstudio.core.MeshData
import studio.mmd.modelstudio.core.MeshResult
import studio.mmd.modelstudio.core.MeshOps
import studio.mmd.modelstudio.core.GroupItem
import studio.mmd.modelstudio.core.Morph
import studio.mmd.modelstudio.core.MorphRemap
import studio.mmd.modelstudio.core.ModelProject
import studio.mmd.modelstudio.core.PmxExporter
import studio.mmd.modelstudio.core.Primitives
import studio.mmd.modelstudio.core.Skeletons
import studio.mmd.modelstudio.core.ProjectStore
import studio.mmd.modelstudio.core.SceneObject
import studio.mmd.modelstudio.core.Shape
import studio.mmd.modelstudio.core.Skinning
import studio.mmd.modelstudio.core.Vec3
import studio.mmd.modelstudio.core.VertexWeights
import studio.mmd.modelstudio.core.Weighting
import java.util.Locale
import java.util.UUID
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/** Gravação de morph em andamento: [base] = posições dos vértices do objeto quando a gravação começou. */
class MorphRec(val objectId: String, val name: String, val base: FloatArray)

enum class ToolMode(val label: String) { MOVE("Mover"), ROTATE("Girar"), SCALE("Escala"), OBJECT("Objeto"), MODEL("Modelar"), WEIGHT("Pesos") }

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    private val store = ProjectStore(app)
    private var counter = 0

    private val undoStack = ArrayList<ModelProject>()
    private val redoStack = ArrayList<ModelProject>()

    var project by mutableStateOf(ModelProject())
        private set
    var selectedId by mutableStateOf<String?>(null)
        private set
    var status by mutableStateOf("Toque em \"+ Forma\" para criar um objeto.")
        private set
    var mode by mutableStateOf(ToolMode.MOVE)
        private set
    var stepIndex by mutableStateOf(1)
        private set
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    // ---- modo de edição de malha ----
    var editMode by mutableStateOf(false)
        private set
    var selectedVerts by mutableStateOf<Set<Int>>(emptySet())
        private set
    var additive by mutableStateOf(false)
        private set
    var selectedBoneId by mutableStateOf<String?>(null)
        private set
    private var boneStepIndex = 1
    private val boneSteps = floatArrayOf(0.02f, 0.05f, 0.1f, 0.25f)
    /** true = seleciona faces (regiões planas); false = seleciona vértices. */
    var faceMode by mutableStateOf(false)
    /** Simetria X no modo Editar: Mover/Girar/Escala de vértices também agem nos vértices espelhados (x → −x). */
    var symmetryX by mutableStateOf(false)
        private set
    var selectedTris by mutableStateOf<Set<Int>>(emptySet())
        private set

    // ---- pose de teste (não é salva) ----
    /** Rotação (graus) de cada osso na pose de teste. Vazio = sem pose. */
    var poseRot by mutableStateOf<Map<String, Vec3>>(emptyMap())
        private set
    /** Objetos e ossos como devem ser DESENHADOS: deformados pela pose na ferramenta Pesos, senão iguais ao projeto. */
    var displayObjects by mutableStateOf<List<SceneObject>>(emptyList())
        private set
    var displayBones by mutableStateOf<List<Bone>>(emptyList())
        private set
    // ---- morphs ----
    var selectedMorphId by mutableStateOf<String?>(null)
    /** Valor de pré-visualização (0..1) de cada morph; não é salvo. */
    var morphValues by mutableStateOf<Map<String, Float>>(emptyMap())
    /** Membro escolhido (↳) dentro do grupo selecionado, para mudar a taxa. */
    var selectedMemberId by mutableStateOf<String?>(null)
        private set
    var morphRecording by mutableStateOf<MorphRec?>(null)
        private set
    /** Grupo em edição: enquanto não for null, tocar num morph de vértice da lista o inclui/retira do grupo. */
    var activeGroupId by mutableStateOf<String?>(null)
    private val weightSteps = floatArrayOf(0.1f, 0.25f, 0.5f)
    // ---- pincel de pesos ----
    var brushOn by mutableStateOf(false)
        private set
    /** 0 = pintar, 1 = apagar, 2 = suavizar. */
    var brushKind by mutableStateOf(0)
        private set
    private val brushRadii = floatArrayOf(0.1f, 0.25f, 0.5f, 1.0f)
    private var brushRadiusIdx by mutableStateOf(1)
    private var strokeBase: ModelProject? = null
    private var strokeHits = 0
    private var strokeVerts = 0
    private val poseStep = 15f

    // quantidades por passo: [pequeno, médio, grande]
    private val moveSteps = floatArrayOf(0.1f, 0.5f, 1.0f)
    private val rotSteps = floatArrayOf(5f, 15f, 45f)
    private val scaleSteps = floatArrayOf(0.05f, 0.1f, 0.25f)
    private val modelSteps = floatArrayOf(0.05f, 0.1f, 0.25f)

    fun stepLabel(): String = when (mode) {
        ToolMode.MOVE -> fmt(moveSteps[stepIndex])
        ToolMode.ROTATE -> fmt(rotSteps[stepIndex]) + "°"
        ToolMode.SCALE -> fmt(scaleSteps[stepIndex])
        ToolMode.OBJECT -> "-"
        ToolMode.MODEL -> fmt(modelSteps[stepIndex])
        ToolMode.WEIGHT -> fmt(weightSteps[stepIndex])
    }

    private fun fmt(v: Float): String = String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')

    private fun commit(newProject: ModelProject) {
        undoStack.add(project)
        if (undoStack.size > 100) undoStack.removeAt(0)
        redoStack.clear()
        project = newProject
        refreshFlags()
    }

    private fun refreshFlags() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
        if (selectedBoneId != null && project.bones.none { it.id == selectedBoneId }) selectedBoneId = null
        if (selectedId != null && project.objects.none { it.id == selectedId }) {
            selectedId = null
            exitEdit()
        }
        if (editMode) {
            val vc = project.objects.firstOrNull { it.id == selectedId }?.mesh?.vertexCount ?: 0
            if (selectedVerts.any { it >= vc }) selectedVerts = selectedVerts.filter { it < vc }.toSet()
            val tc = project.objects.firstOrNull { it.id == selectedId }?.mesh?.triangleCount ?: 0
            if (selectedTris.any { it >= tc }) selectedTris = selectedTris.filter { it < tc }.toSet()
        }
        if (mode == ToolMode.WEIGHT && project.bones.isEmpty()) {
            mode = ToolMode.MOVE
            poseRot = emptyMap()
        }
        refreshDisplay()
    }

    /** Recalcula o que a viewport desenha: com pose ativa (ferramenta Pesos), as malhas deformadas; senão, o projeto. */
    private fun refreshDisplay() {
        if (mode == ToolMode.WEIGHT && poseRot.isNotEmpty()) {
            val posed = Skinning.pose(project, poseRot)
            displayObjects = posed.first
            displayBones = posed.second
        } else {
            displayObjects = applyMorphPreview(project.objects)
            displayBones = project.bones
        }
    }

    /** Soma à malha o deslocamento dos morphs com valor > 0. No modo Editar não há pré-visualização (a edição usa a malha base). */
    private fun applyMorphPreview(objs: List<SceneObject>): List<SceneObject> {
        if (editMode || morphValues.isEmpty() || project.morphs.isEmpty()) return objs
        // valor efetivo de cada morph de vértice: o próprio valor + a contribuição dos grupos acionados
        val eff = HashMap<String, Float>()
        for (m in project.morphs) {
            val v = morphValues[m.id] ?: 0f
            if (v <= 0f) continue
            if (m.isGroup) for (g in m.group) eff[g.morphId] = (eff[g.morphId] ?: 0f) + v * g.rate
            else eff[m.id] = (eff[m.id] ?: 0f) + v
        }
        val active = project.morphs.filter { !it.isGroup && (eff[it.id] ?: 0f) > 0f }
        if (active.isEmpty()) return objs
        return objs.map { o ->
            val mine = active.filter { it.objectId == o.id && !it.isMaterial }
            val mats = active.filter { it.objectId == o.id && it.isMaterial }
            var res = o
            if (mine.isNotEmpty()) {
                val pos = o.mesh.positions.copyOf()
                for (m in mine) {
                    val f = eff[m.id] ?: 0f
                    for (k in m.idx.indices) {
                        val v = m.idx[k]
                        if (v < 0 || v * 3 + 2 >= pos.size) continue
                        pos[v * 3] += m.d[k * 3] * f; pos[v * 3 + 1] += m.d[k * 3 + 1] * f; pos[v * 3 + 2] += m.d[k * 3 + 2] * f
                    }
                }
                res = res.copy(mesh = MeshData(pos, o.mesh.indices))
            }
            if (mats.isNotEmpty()) {
                var c = o.color ?: 0x8CADD9
                for (m in mats) c = lerpRgb(c, m.color, (eff[m.id] ?: 0f).coerceAtMost(1f))
                res = res.copy(color = c)
            }
            res
        }
    }

    private fun lerpRgb(a: Int, b: Int, t: Float): Int {
        fun ch(s: Int): Int {
            val x = (a shr s) and 0xFF
            val y = (b shr s) and 0xFF
            return (x + (y - x) * t).roundToInt().coerceIn(0, 255)
        }
        return (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    // ---------- morphs ----------
    fun panelLabel(p: Int): String = when (p) { 1 -> "Sobrancelha"; 2 -> "Olho"; 3 -> "Boca"; else -> "Outro" }

    /** Começa a gravar um morph no objeto selecionado: entra no modo Editar; mova vértices e toque em Concluir. */
    fun startMorph(name: String) {
        if (morphRecording != null) { status = "Já existe uma gravação em andamento."; return }
        val obj = project.objects.firstOrNull { it.id == selectedId } ?: run { status = "Selecione um objeto para criar o morph."; return }
        val n = name.trim()
        if (n.isEmpty()) { status = "O nome do morph não pode ficar vazio."; return }
        if (project.morphs.any { it.name == n }) { status = "Já existe um morph com o nome $n."; return }
        morphValues = emptyMap()
        morphRecording = MorphRec(obj.id, n, obj.mesh.positions.copyOf())
        if (!editMode) toggleEdit()
        refreshDisplay()
        status = "Gravando \"$n\": selecione vértices e use Mover/Girar/Escala. Depois toque em Concluir."
    }

    fun finishMorph() {
        val rec = morphRecording ?: return
        val obj = project.objects.firstOrNull { it.id == rec.objectId }
        if (obj == null || obj.mesh.vertexCount * 3 != rec.base.size) {
            morphRecording = null
            status = "Gravação cancelada: a malha do objeto mudou."
            return
        }
        val idx = ArrayList<Int>()
        val d = ArrayList<Float>()
        val p = obj.mesh.positions
        for (v in 0 until obj.mesh.vertexCount) {
            val dx = p[v * 3] - rec.base[v * 3]; val dy = p[v * 3 + 1] - rec.base[v * 3 + 1]; val dz = p[v * 3 + 2] - rec.base[v * 3 + 2]
            if (dx * dx + dy * dy + dz * dz > 1e-10f) { idx.add(v); d.add(dx); d.add(dy); d.add(dz) }
        }
        if (idx.isEmpty()) { status = "Nenhum vértice foi movido: mova alguns vértices antes de concluir (ou Cancelar)."; return }
        val morph = Morph("m:" + UUID.randomUUID().toString().take(8), rec.name, rec.name, 4, obj.id, idx.toIntArray(), d.toFloatArray())
        // a malha volta ao estado base (o morph guarda só a diferença), tudo num único passo de Desfazer
        val restored = obj.copy(mesh = MeshData(rec.base, obj.mesh.indices))
        morphRecording = null
        commit(project.copy(objects = project.objects.map { if (it.id == obj.id) restored else it }, morphs = project.morphs + morph))
        selectedMorphId = morph.id
        status = "Morph \"${morph.name}\" gravado: ${idx.size} vértice(s). Saia do modo Editar e use 50% / 100% para ver."
    }

    /** Cria um morph de grupo vazio e entra na edição dele: toque nos morphs de vértice da lista para incluí-los. */
    fun createGroup(name: String) {
        val n = name.trim()
        if (n.isEmpty()) { status = "O nome do grupo não pode ficar vazio."; return }
        if (project.morphs.any { it.name == n }) { status = "Já existe um morph com o nome $n."; return }
        val g = Morph("m:" + UUID.randomUUID().toString().take(8), n, n, 4, "", IntArray(0), FloatArray(0), true, emptyList())
        commit(project.copy(morphs = project.morphs + g))
        selectedMorphId = g.id
        activeGroupId = g.id
        status = "Grupo \"$n\" criado. Toque nos morphs de vértice da lista para incluí-los ou retirá-los; depois toque em Pronto."
    }

    fun toggleGroupEdit() {
        val m = project.morphs.firstOrNull { it.id == selectedMorphId }
        if (activeGroupId != null) { activeGroupId = null; status = "Edição do grupo concluída."; return }
        if (m == null || !m.isGroup) { status = "Selecione um morph de grupo."; return }
        activeGroupId = m.id
        status = "Editando o grupo \"${m.name}\": toque nos morphs de vértice para incluir/retirar."
    }

    fun toggleGroupMember(morphId: String) {
        val g = project.morphs.firstOrNull { it.id == activeGroupId } ?: run { activeGroupId = null; return }
        val target = project.morphs.firstOrNull { it.id == morphId } ?: return
        if (target.isGroup) { status = "Um grupo não pode conter outro grupo."; return }
        val has = g.group.any { it.morphId == morphId }
        val items = if (has) g.group.filter { it.morphId != morphId } else g.group + GroupItem(morphId, 1f)
        commit(project.copy(morphs = project.morphs.map { if (it.id == g.id) it.copy(group = items) else it }))
        status = "\"${target.name}\" ${if (has) "retirado de" else "incluído em"} \"${g.name}\" (${items.size} morph(s) no grupo)."
    }

    /** Cria um morph de material: a cor do material do objeto vai até [rgb] com 100%. Aparece no preview e no PMX (tipo 8). */
    fun createColorMorph(name: String, objectId: String, rgb: Int) {
        val n = name.trim()
        if (n.isEmpty()) { status = "Escreva o nome do morph de cor antes de escolher a cor."; return }
        if (project.morphs.any { it.name == n }) { status = "Já existe um morph com o nome $n."; return }
        val obj = project.objects.firstOrNull { it.id == objectId } ?: run { status = "Selecione um objeto."; return }
        val m = Morph("m:" + UUID.randomUUID().toString().take(8), n, n, 4, obj.id, IntArray(0), FloatArray(0), false, emptyList(), true, rgb)
        commit(project.copy(morphs = project.morphs + m))
        selectedMorphId = m.id
        status = "Morph de cor \"$n\" criado em ${obj.name}. Desmarque o objeto e use 50% / 100% para ver."
    }

    /** Muda o valor de pré-visualização do morph selecionado em [delta] (0..1), de 10 em 10%. */
    fun stepMorphValue(delta: Float) {
        val id = selectedMorphId ?: run { status = "Selecione um morph na lista."; return }
        val cur = morphValues[id] ?: 0f
        setMorphValue(((cur + delta) * 100f).roundToInt().coerceIn(0, 100) / 100f)
    }

    /** Muda a taxa do membro escolhido no grupo selecionado (0 a 2, de 0,25 em 0,25). */
    fun changeMemberRate(delta: Float) {
        val g = project.morphs.firstOrNull { it.id == selectedMorphId && it.isGroup } ?: run { status = "Selecione um grupo."; return }
        val mid = selectedMemberId ?: run { status = "Toque num membro do grupo (linha ↳) para escolhê-lo."; return }
        val item = g.group.firstOrNull { it.morphId == mid } ?: run { status = "Esse morph não é membro do grupo."; return }
        val r = (((item.rate + delta) * 100f).roundToInt() / 100f).coerceIn(0f, 2f)
        commit(project.copy(morphs = project.morphs.map { x ->
            if (x.id == g.id) x.copy(group = x.group.map { gi -> if (gi.morphId == mid) gi.copy(rate = r) else gi }) else x
        }))
        status = "Taxa do membro: $r."
    }

    fun cancelMorph() {
        val rec = morphRecording ?: return
        morphRecording = null
        val obj = project.objects.firstOrNull { it.id == rec.objectId }
        if (obj != null && obj.mesh.vertexCount * 3 == rec.base.size && !obj.mesh.positions.contentEquals(rec.base)) {
            commit(project.copy(objects = project.objects.map { if (it.id == obj.id) it.copy(mesh = MeshData(rec.base, obj.mesh.indices)) else it }))
        }
        status = "Gravação cancelada."
    }

    fun setMorphValue(value: Float) {
        val id = selectedMorphId ?: run { status = "Selecione um morph na lista."; return }
        morphValues = if (value <= 0f) morphValues - id else morphValues + (id to value)
        refreshDisplay()
        status = if (editMode) "Saia do modo Editar para ver a pré-visualização do morph." else "Pré-visualização: ${(value * 100).roundToInt()}%."
    }

    fun deleteMorph() {
        val m = project.morphs.firstOrNull { it.id == selectedMorphId } ?: run { status = "Selecione um morph na lista."; return }
        morphValues = morphValues - m.id
        if (activeGroupId == m.id) activeGroupId = null
        commit(project.copy(morphs = project.morphs.filter { it.id != m.id }.map { if (it.isGroup) it.copy(group = it.group.filter { g -> g.morphId != m.id }) else it }))
        selectedMorphId = null
        status = "Morph \"${m.name}\" excluído."
    }

    /** Renomeia o morph selecionado (nome usado no PMX); recusa nome vazio ou repetido. */
    fun renameMorph(id: String, name: String) {
        val n = name.trim()
        if (n.isEmpty()) { status = "O nome do morph não pode ficar vazio."; return }
        if (project.morphs.any { it.id != id && it.name == n }) { status = "Já existe um morph com o nome $n."; return }
        commit(project.copy(morphs = project.morphs.map { if (it.id == id) it.copy(name = n, nameEn = n) else it }))
        status = "Morph renomeado para $n."
    }

    fun cycleMorphPanel() {
        val m = project.morphs.firstOrNull { it.id == selectedMorphId } ?: run { status = "Selecione um morph na lista."; return }
        val np = m.panel % 4 + 1
        commit(project.copy(morphs = project.morphs.map { if (it.id == m.id) it.copy(panel = np) else it }))
        status = "Grupo de \"${m.name}\": ${panelLabel(np)}."
    }

    /**
     * Morphs depois de uma operação de malha: se os vértices não mudaram, ficam iguais; se mudaram (Extrudir, Inset,
     * Subdividir, Apagar, Limpar), os morphs de vértice do objeto são REMAPEADOS ([MorphRemap]): vértice novo copia o
     * deslocamento do antigo mais próximo (ponto médio de aresta = média dos dois). Morph que fica sem vértices é descartado
     * (e retirado dos grupos).
     */
    private fun morphsAfter(obj: SceneObject, newMesh: MeshData): List<Morph> {
        if (newMesh.vertexCount == obj.mesh.vertexCount && newMesh.positions.contentEquals(obj.mesh.positions)) return project.morphs
        val remapped = project.morphs.mapNotNull { m ->
            if (m.isGroup || m.isMaterial || m.objectId != obj.id) m
            else MorphRemap.remap(obj.mesh.positions, m, newMesh.positions)
        }
        val alive = remapped.map { it.id }.toSet()
        return remapped.map { m -> if (m.isGroup) m.copy(group = m.group.filter { g -> g.morphId in alive }) else m }
    }

    private fun morphNote(obj: SceneObject, newMesh: MeshData, after: List<Morph>): String {
        val before = project.morphs.count { !it.isGroup && !it.isMaterial && it.objectId == obj.id }
        if (before == 0) return ""
        if (newMesh.vertexCount == obj.mesh.vertexCount && newMesh.positions.contentEquals(obj.mesh.positions)) return ""
        val kept = after.count { !it.isGroup && !it.isMaterial && it.objectId == obj.id }
        val lost = before - kept
        return (if (kept > 0) " $kept morph(s) remapeado(s) (vértice novo copia o vizinho; ponto médio = média; confira o preview)." else "") +
            (if (lost > 0) " $lost morph(s) descartado(s): ficaram sem vértices." else "")
    }


    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.add(project)
        project = undoStack.removeAt(undoStack.size - 1)
        refreshFlags()
        status = "Desfeito."
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.add(project)
        project = redoStack.removeAt(redoStack.size - 1)
        refreshFlags()
        status = "Refeito."
    }

    fun selectMode(m: ToolMode) {
        if (m == ToolMode.WEIGHT && project.bones.isEmpty()) {
            status = "Crie o esqueleto primeiro: aba Objeto → Esqueleto → Humanoide."
            return
        }
        if (m != ToolMode.WEIGHT && poseRot.isNotEmpty()) poseRot = emptyMap()
        mode = m
        if (m == ToolMode.WEIGHT) status = "Pesos: escolha um osso na lista. Cores no objeto: azul 0% → vermelho 100%."
        refreshDisplay()
    }

    fun cycleStep() { stepIndex = (stepIndex + 1) % 3 }

    fun addShape(shape: Shape) {
        if (editMode) { status = "Saia do modo de edição para criar objetos."; return }
        counter++
        val i = project.objects.size
        val y = if (shape == Shape.PLANE) 0f else 0.5f
        val obj = SceneObject(
            id = UUID.randomUUID().toString(),
            name = "${shape.label} $counter",
            mesh = Primitives.create(shape),
            position = Vec3((i % 5) * 2.5f - 5f, y, (i / 5) * 2.5f)
        )
        commit(project.copy(objects = project.objects + obj))
        selectedId = obj.id
        status = "${obj.name} criado."
    }

    /** Duplica o objeto selecionado (sem os filhos e sem os morphs), deslocado 0,5 em X. */
    fun duplicateSelected() {
        if (editMode) { status = "Saia do modo de edição para duplicar objetos."; return }
        val o = project.objects.firstOrNull { it.id == selectedId } ?: run { status = "Selecione um objeto para duplicar."; return }
        val copy = o.copy(
            id = UUID.randomUUID().toString(),
            name = o.name + " cópia",
            position = o.position.copy(x = o.position.x + 0.5f)
        )
        commit(project.copy(objects = project.objects + copy))
        selectedId = copy.id
        status = "${o.name} duplicado (morphs não são copiados)."
    }

    /** Osso do lado oposto (…L ↔ …R) se existir; senão o próprio. */
    private fun mirrorBoneId(id: String?): String? {
        if (id == null) return null
        val alt = when {
            id.endsWith("L") -> id.dropLast(1) + "R"
            id.endsWith("R") -> id.dropLast(1) + "L"
            else -> return id
        }
        return if (project.bones.any { it.id == alt }) alt else id
    }

    /**
     * Cria uma cópia ESPELHADA do objeto selecionado no plano YZ do mundo (x → −x): malha com X invertido e faces viradas,
     * posição X e rotações Y/Z invertidas, vínculo rígido e pesos trocados para os ossos do outro lado (L ↔ R). Não copia morphs.
     * Vale para objeto sem pai girado/escalado (com pai, o espelho pode sair errado).
     */
    fun mirrorSelected() {
        if (editMode) { status = "Saia do modo de edição para espelhar objetos."; return }
        val o = project.objects.firstOrNull { it.id == selectedId } ?: run { status = "Selecione um objeto para espelhar."; return }
        val pos = o.mesh.positions.copyOf()
        for (i in 0 until pos.size / 3) pos[i * 3] = -pos[i * 3]
        val idx = o.mesh.indices.copyOf()
        var t = 0
        while (t + 2 < idx.size) { val tmp = idx[t + 1]; idx[t + 1] = idx[t + 2]; idx[t + 2] = tmp; t += 3 }
        val copy = o.copy(
            id = UUID.randomUUID().toString(),
            name = o.name + " (espelho)",
            mesh = MeshData(pos, idx),
            position = o.position.copy(x = -o.position.x),
            rotation = Vec3(o.rotation.x, -o.rotation.y, -o.rotation.z),
            boneId = mirrorBoneId(o.boneId),
            weights = o.weights?.let { w ->
                if (w.vertexCount != o.mesh.vertexCount) null
                else Weighting.mirror(w, w.vertexCount, (0 until w.vertexCount).associateWith { it }) { mirrorBoneId(it) ?: it }.weights
            }
        )
        commit(project.copy(objects = project.objects + copy))
        selectedId = copy.id
        status = "${o.name} espelhado em X." + (if (o.parentId != null) " Atenção: o objeto tem pai; confira a posição." else "") +
            (if (o.weights != null) " Pesos copiados com ossos L/R trocados (confira no Pesos)." else "")
    }

    fun toggleSymmetry() {
        symmetryX = !symmetryX
        status = if (symmetryX) "Simetria X ligada: Mover/Girar/Escala dos vértices também agem nos vértices espelhados (x → −x)."
            else "Simetria X desligada."
    }

    /** Para cada vértice de [sel], o vértice na posição espelhada (−x, y, z), se existir (precisão de 0,001). */
    private fun mirrorPartners(pos: FloatArray, sel: List<Int>): Map<Int, Int> {
        fun q(v: Float): Int = Math.round(v * 1000f)
        val key = HashMap<Triple<Int, Int, Int>, Int>()
        for (i in 0 until pos.size / 3) key[Triple(q(pos[i * 3]), q(pos[i * 3 + 1]), q(pos[i * 3 + 2]))] = i
        val out = HashMap<Int, Int>()
        for (i in sel) {
            val j = key[Triple(q(-pos[i * 3]), q(pos[i * 3 + 1]), q(pos[i * 3 + 2]))]
            if (j != null && j != i) out[i] = j
        }
        return out
    }

    fun descendantsOf(id: String): Set<String> {
        val result = HashSet<String>()
        val queue = ArrayDeque<String>()
        queue.add(id)
        while (queue.isNotEmpty()) {
            val cur = queue.removeFirst()
            for (o in project.objects) {
                if (o.parentId == cur && result.add(o.id)) queue.add(o.id)
            }
        }
        return result
    }

    /** Exclui o objeto e todos os seus filhos (desfazer recupera). */
    fun deleteSelected() {
        if (editMode) { status = "Saia do modo de edição para excluir objetos."; return }
        val id = selectedId
        if (id == null) {
            status = "Nada selecionado."
            return
        }
        val name = project.objects.firstOrNull { it.id == id }?.name ?: "Objeto"
        val gone = descendantsOf(id) + id
        commit(project.copy(objects = project.objects.filter { it.id !in gone }, morphs = project.morphs.filter { it.objectId !in gone }))
        selectedId = null
        status = if (gone.size > 1) "$name e ${gone.size - 1} filho(s) excluídos." else "$name excluído."
    }

    fun rename(id: String, newName: String) {
        val n = newName.trim()
        if (n.isEmpty()) { status = "O nome não pode ficar vazio."; return }
        commit(project.copy(objects = project.objects.map { if (it.id == id) it.copy(name = n) else it }))
        status = "Renomeado para $n."
    }

    /** Define o pai mantendo os valores LOCAIS do filho (ele pode "pular" de lugar). */
    fun setParent(id: String, parentId: String?) {
        if (parentId != null && (parentId == id || parentId in descendantsOf(id))) {
            status = "Não dá para usar o próprio objeto ou um filho dele como pai."
            return
        }
        val obj = project.objects.firstOrNull { it.id == id } ?: return
        if (obj.parentId == parentId) return
        commit(project.copy(objects = project.objects.map { if (it.id == id) it.copy(parentId = parentId) else it }))
        val pn = project.objects.firstOrNull { it.id == parentId }?.name
        status = if (pn == null) "${obj.name} solto na cena." else "${obj.name} agora é filho de $pn."
    }

    /** Define a cor do material do objeto ([rgb] = 0xRRGGBB; null = padrão). Entra no Desfazer/Refazer e vai para o PMX. */
    fun setColor(id: String, rgb: Int?) {
        val obj = project.objects.firstOrNull { it.id == id } ?: return
        commit(project.copy(objects = project.objects.map { if (it.id == id) it.copy(color = rgb) else it }))
        status = if (rgb == null) "${obj.name}: cor padrão." else "${obj.name}: cor alterada (o objeto selecionado continua laranja; desmarque para ver)."
    }

    fun toggleVisible(id: String) {
        val obj = project.objects.firstOrNull { it.id == id } ?: return
        commit(project.copy(objects = project.objects.map { if (it.id == id) it.copy(visible = !it.visible) else it }))
        status = if (obj.visible) "${obj.name} oculto." else "${obj.name} visível."
    }

    fun select(id: String?) {
        if (editMode && id != selectedId) exitEdit()
        selectedId = id
        status = if (id == null) "Seleção limpa." else
            "Selecionado: ${project.objects.firstOrNull { it.id == id }?.name ?: "?"}"
    }

    // ---------------- modo de edição ----------------
    private fun exitEdit() {
        editMode = false
        selectedVerts = emptySet()
        selectedTris = emptySet()
        faceMode = false
        if (mode == ToolMode.MODEL) mode = ToolMode.MOVE
        refreshDisplay()
    }

    fun toggleEdit() {
        if (editMode) {
            exitEdit()
            status = "Saiu do modo de edição."
            return
        }
        val obj = project.objects.firstOrNull { it.id == selectedId }
        if (obj == null) { status = "Selecione um objeto para editar."; return }
        editMode = true
        selectedVerts = emptySet()
        selectedTris = emptySet()
        faceMode = false
        refreshDisplay()
        status = "Edição de ${obj.name}: ${obj.mesh.vertexCount} vértices. Toque nos vértices."
    }

    fun toggleAdditive() {
        additive = !additive
        status = if (additive) "Seleção múltipla: cada toque soma/remove um vértice." else "Seleção simples: um vértice por vez."
    }

    fun pickVertex(idx: Int) {
        if (!editMode) return
        selectedVerts = if (idx < 0) {
            if (additive) selectedVerts else emptySet()
        } else if (additive) {
            if (idx in selectedVerts) selectedVerts - idx else selectedVerts + idx
        } else {
            setOf(idx)
        }
        status = "${selectedVerts.size} vértice(s) selecionado(s)."
    }

    /** Alterna entre selecionar vértices e faces. Face → vértice converte a seleção; vértice → face limpa. */
    fun toggleFaceMode() {
        if (!editMode) return
        val obj = project.objects.firstOrNull { it.id == selectedId } ?: return
        if (faceMode) {
            selectedVerts = MeshOps.vertsOfTris(obj.mesh, selectedTris)
            selectedTris = emptySet()
            faceMode = false
            status = "Modo vértice."
        } else {
            selectedVerts = emptySet()
            faceMode = true
            status = "Modo face: toque numa face para selecioná-la."
        }
    }

    /** [tri] = triângulo tocado (ou -1). Seleciona a região plana inteira. */
    fun pickFace(tri: Int) {
        if (!editMode || !faceMode) return
        val obj = project.objects.firstOrNull { it.id == selectedId } ?: return
        if (tri < 0) {
            if (!additive) selectedTris = emptySet()
        } else {
            val region = MeshOps.faceRegion(obj.mesh, tri)
            selectedTris = if (additive) {
                if (tri in selectedTris) selectedTris - region else selectedTris + region
            } else region
        }
        status = "${selectedTris.size} triângulo(s) selecionado(s)."
    }

    private fun editedObject(): SceneObject? = project.objects.firstOrNull { it.id == selectedId }

    /** Limpeza automática depois de extrudir/inset (remove paredes internas sobrepostas), mantendo a nota. */
    private fun tidy(r: MeshResult): MeshResult {
        val c = MeshOps.cleanup(r.mesh, r.selection)
        return MeshResult(c.mesh, c.selection, r.note)
    }

    fun subdivideMesh() {
        val obj = editedObject() ?: return
        val r = MeshOps.subdivide(obj.mesh, selectedTris)
            ?: run { status = "Malha grande demais para subdividir (limite 60000 triângulos)."; return }
        applyMeshResult(obj, r, "Subdividido: ${obj.mesh.triangleCount} → ${r.mesh.triangleCount} triângulos (${if (selectedTris.isEmpty()) "malha inteira" else "só a seleção"}).")
    }

    fun cleanMesh() {
        val obj = editedObject() ?: return
        val r = MeshOps.cleanup(obj.mesh, selectedTris)
        val dv = obj.mesh.vertexCount - r.mesh.vertexCount
        val dt = obj.mesh.triangleCount - r.mesh.triangleCount
        if (dv == 0 && dt == 0) { status = "Malha já está limpa."; return }
        applyMeshResult(obj, r, "Limpeza: $dt triângulo(s) e $dv vértice(s) removidos.")
    }

    /** Recusa a operação se ela criar faces sobrepostas no mesmo plano (chiado), a menos que a malha já estivesse assim. */
    private fun applySafe(obj: SceneObject, r: MeshResult, label: String) {
        if (!MeshOps.hasOverlap(obj.mesh) && MeshOps.hasOverlap(r.mesh)) {
            status = "Recusado: criaria faces sobrepostas no mesmo plano (chiado). Tente outra distância ou faça Inset antes."
            return
        }
        applyMeshResult(obj, r, label)
    }

    /**
     * Pesos depois de uma operação de malha: se os vértices não mudaram, ficam iguais; se mudaram (Extrudir, Inset,
     * Subdividir, Apagar, Limpar), são REMAPEADOS: cada vértice novo copia os pesos do vértice antigo mais próximo.
     */
    private fun keepWeights(old: SceneObject, newMesh: MeshData): VertexWeights? {
        val w = old.weights ?: return null
        if (w.vertexCount == newMesh.vertexCount && old.mesh.positions.contentEquals(newMesh.positions)) return w
        return Weighting.remap(old.mesh.positions, w, newMesh.positions)
    }

    /** Texto para a barra de status quando os pesos foram remapeados (ou perdidos). */
    private fun weightNote(old: SceneObject, kept: VertexWeights?): String {
        val w = old.weights ?: return ""
        if (kept === w) return ""
        return if (kept == null) " Pesos perdidos: refaça com Pesos → Auto."
        else " Pesos remapeados (vértices novos copiam o vizinho mais próximo; confira com Suavizar)."
    }

    private fun applyMeshResult(obj: SceneObject, r: MeshResult, label: String) {
        val kept = keepWeights(obj, r.mesh)
        val mo = morphsAfter(obj, r.mesh)
        val note = morphNote(obj, r.mesh, mo)
        commit(project.copy(objects = project.objects.map { if (it.id == obj.id) it.copy(mesh = r.mesh, weights = kept) else it }, morphs = mo))
        selectedTris = r.selection
        status = label + (r.note?.let { " $it" } ?: "") + weightNote(obj, kept) + note
    }

    /** sign +1 = para fora, -1 = para dentro. Distância = passo atual. */
    fun extrudeFaces(sign: Int) {
        val obj = editedObject() ?: return
        if (!faceMode) { status = "Mude para Face (botão Vértice/Face) e selecione uma face."; return }
        if (selectedTris.isEmpty()) { status = "Toque numa face para selecioná-la."; return }
        val d = sign * modelSteps[stepIndex]
        val r = MeshOps.extrude(obj.mesh, selectedTris, d) ?: run { status = "Recusado: sem espaço, ou a face vai até a quina do objeto (faça Inset antes de afundar)."; return }
        applySafe(obj, tidy(r), "Extrudido ${if (sign > 0) "+" else "-"}${fmt(modelSteps[stepIndex])}.")
    }

    fun insetFaces() {
        val obj = editedObject() ?: return
        if (!faceMode) { status = "Mude para Face (botão Vértice/Face) e selecione uma face."; return }
        if (selectedTris.isEmpty()) { status = "Toque numa face para selecioná-la."; return }
        val r = MeshOps.inset(obj.mesh, selectedTris, modelSteps[stepIndex])
            ?: run { status = "Inset não aplicável (sem borda ou nada selecionado)."; return }
        applySafe(obj, tidy(r), "Inset ${fmt(modelSteps[stepIndex])}.")
    }

    fun deleteFaces() {
        val obj = editedObject() ?: return
        if (!faceMode) { status = "Mude para Face (botão Vértice/Face) e selecione uma face."; return }
        if (selectedTris.isEmpty()) { status = "Toque numa face para selecioná-la."; return }
        val m = MeshOps.deleteTris(obj.mesh, selectedTris)
            ?: run { status = "Não dá para apagar todas as faces; use Excluir no modo objeto."; return }
        val n = selectedTris.size
        val kept = keepWeights(obj, m)
        val mo = morphsAfter(obj, m)
        val note = morphNote(obj, m, mo)
        commit(project.copy(objects = project.objects.map { if (it.id == obj.id) it.copy(mesh = m, weights = kept) else it }, morphs = mo))
        selectedTris = emptySet()
        status = "$n triângulo(s) apagado(s)." + weightNote(obj, kept) + note
    }

    fun selectAllVerts() {
        if (faceMode) {
            val tc = editedObject()?.mesh?.triangleCount ?: return
            selectedTris = (0 until tc).toSet(); status = "Todas as faces selecionadas."; return
        }
        val vc = project.objects.firstOrNull { it.id == selectedId }?.mesh?.vertexCount ?: return
        selectedVerts = (0 until vc).toSet()
        status = "${selectedVerts.size} vértice(s) selecionado(s)."
    }

    fun clearVerts() {
        if (faceMode) { selectedTris = emptySet(); status = "Nenhuma face selecionada."; return }
        selectedVerts = emptySet()
        status = "Nenhum vértice selecionado."
    }

    fun invertVerts() {
        if (faceMode) {
            val tc = editedObject()?.mesh?.triangleCount ?: return
            selectedTris = (0 until tc).filter { it !in selectedTris }.toSet(); status = "Seleção de faces invertida."; return
        }
        val vc = project.objects.firstOrNull { it.id == selectedId }?.mesh?.vertexCount ?: return
        selectedVerts = (0 until vc).filter { it !in selectedVerts }.toSet()
        status = "${selectedVerts.size} vértice(s) selecionado(s)."
    }

    /** axis: 0=X, 1=Y, 2=Z (ignorado em Escala). sign: +1 ou -1. */
    fun nudge(axis: Int, sign: Int) {
        val id = selectedId
        val obj = project.objects.firstOrNull { it.id == id }
        if (obj == null) {
            status = "Selecione um objeto primeiro."
            return
        }
        if (editMode) {
            nudgeVertices(obj, axis, sign)
            return
        }
        val updated = when (mode) {
            ToolMode.MOVE -> obj.copy(position = add(obj.position, axis, sign * moveSteps[stepIndex]))
            ToolMode.ROTATE -> obj.copy(rotation = add(obj.rotation, axis, sign * rotSteps[stepIndex]))
            ToolMode.SCALE -> obj.copy(scale = (obj.scale + sign * scaleSteps[stepIndex]).coerceIn(0.1f, 20f))
            ToolMode.OBJECT, ToolMode.MODEL, ToolMode.WEIGHT -> { status = "Escolha Mover, Girar ou Escala."; return }
        }
        commit(project.copy(objects = project.objects.map { if (it.id == obj.id) updated else it }))
        status = "${obj.name}: ${mode.label} ${if (sign > 0) "+" else "-"}${stepLabel()}"
    }

    /** Mover/Girar/Escalar vértices selecionados, nos eixos LOCAIS do objeto; girar e escalar usam o centro da seleção. */
    private fun nudgeVertices(obj: SceneObject, axis: Int, sign: Int) {
        if (mode == ToolMode.OBJECT || mode == ToolMode.MODEL || mode == ToolMode.WEIGHT) { status = "Escolha Mover, Girar ou Escala."; return }
        val sel = (if (faceMode) MeshOps.vertsOfTris(obj.mesh, selectedTris) else selectedVerts).filter { it < obj.mesh.vertexCount }
        if (sel.isEmpty()) { status = if (faceMode) "Toque numa face para selecioná-la." else "Toque nos vértices para selecioná-los."; return }
        val pos = obj.mesh.positions.copyOf()
        var cx = 0f; var cy = 0f; var cz = 0f
        for (i in sel) { cx += pos[i * 3]; cy += pos[i * 3 + 1]; cz += pos[i * 3 + 2] }
        cx /= sel.size; cy /= sel.size; cz /= sel.size
        when (mode) {
            ToolMode.MOVE -> {
                val d = sign * moveSteps[stepIndex]
                for (i in sel) pos[i * 3 + axis] += d
            }
            ToolMode.SCALE -> {
                val f = (1f + sign * scaleSteps[stepIndex]).coerceAtLeast(0.05f)
                for (i in sel) {
                    pos[i * 3] = cx + (pos[i * 3] - cx) * f
                    pos[i * 3 + 1] = cy + (pos[i * 3 + 1] - cy) * f
                    pos[i * 3 + 2] = cz + (pos[i * 3 + 2] - cz) * f
                }
            }
            ToolMode.ROTATE -> {
                val a = Math.toRadians((sign * rotSteps[stepIndex]).toDouble())
                val c = cos(a).toFloat(); val s = sin(a).toFloat()
                for (i in sel) {
                    val rx = pos[i * 3] - cx; val ry = pos[i * 3 + 1] - cy; val rz = pos[i * 3 + 2] - cz
                    var nx = rx; var ny = ry; var nz = rz
                    when (axis) {
                        0 -> { ny = ry * c - rz * s; nz = ry * s + rz * c }
                        1 -> { nx = rx * c + rz * s; nz = -rx * s + rz * c }
                        else -> { nx = rx * c - ry * s; ny = rx * s + ry * c }
                    }
                    pos[i * 3] = cx + nx; pos[i * 3 + 1] = cy + ny; pos[i * 3 + 2] = cz + nz
                }
            }
            ToolMode.OBJECT, ToolMode.MODEL, ToolMode.WEIGHT -> return
        }
        var symNote = ""
        if (symmetryX) {
            // vértices espelhados (que não estão na seleção) recebem a operação espelhada: centro (−cx, cy, cz)
            val selSet = sel.toHashSet()
            val ps = mirrorPartners(obj.mesh.positions, sel).values.filter { it !in selSet }.distinct()
            when (mode) {
                ToolMode.MOVE -> {
                    val d = sign * moveSteps[stepIndex] * (if (axis == 0) -1f else 1f)
                    for (j in ps) pos[j * 3 + axis] += d
                }
                ToolMode.SCALE -> {
                    val f = (1f + sign * scaleSteps[stepIndex]).coerceAtLeast(0.05f)
                    val mx = -cx
                    for (j in ps) {
                        pos[j * 3] = mx + (pos[j * 3] - mx) * f
                        pos[j * 3 + 1] = cy + (pos[j * 3 + 1] - cy) * f
                        pos[j * 3 + 2] = cz + (pos[j * 3 + 2] - cz) * f
                    }
                }
                ToolMode.ROTATE -> {
                    val a = Math.toRadians((sign * rotSteps[stepIndex]).toDouble()) * (if (axis == 0) 1.0 else -1.0)
                    val c = cos(a).toFloat(); val s = sin(a).toFloat()
                    val mx = -cx
                    for (j in ps) {
                        val rx = pos[j * 3] - mx; val ry = pos[j * 3 + 1] - cy; val rz = pos[j * 3 + 2] - cz
                        var nx = rx; var ny = ry; var nz = rz
                        when (axis) {
                            0 -> { ny = ry * c - rz * s; nz = ry * s + rz * c }
                            1 -> { nx = rx * c + rz * s; nz = -rx * s + rz * c }
                            else -> { nx = rx * c - ry * s; ny = rx * s + ry * c }
                        }
                        pos[j * 3] = mx + nx; pos[j * 3 + 1] = cy + ny; pos[j * 3 + 2] = cz + nz
                    }
                }
                else -> {}
            }
            symNote = if (ps.isEmpty()) " (simetria X: nenhum vértice espelhado encontrado)" else " (simetria X: +${ps.size} espelhado(s))"
        }
        val updated = obj.copy(mesh = MeshData(pos, obj.mesh.indices))
        commit(project.copy(objects = project.objects.map { if (it.id == obj.id) updated else it }))
        status = "${sel.size} vértice(s)${if (faceMode) " das faces" else ""}: ${mode.label} ${if (sign > 0) "+" else "-"}${stepLabel()}" + symNote
    }

    private fun add(v: Vec3, axis: Int, d: Float): Vec3 = when (axis) {
        0 -> v.copy(x = v.x + d)
        1 -> v.copy(y = v.y + d)
        else -> v.copy(z = v.z + d)
    }

    fun save() {
        val snapshot = project
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { store.save(snapshot) } }
            status = result.fold(
                onSuccess = { "Projeto salvo (${snapshot.objects.size} objetos)." },
                onFailure = { "Erro ao salvar: ${it.message}" }
            )
        }
    }

    /** Exporta todos os objetos visíveis para um arquivo PMX 2.0 escolhido pelo usuário. */
    fun exportPmx(uri: android.net.Uri) {
        val snapshot = project
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val r = PmxExporter.export(snapshot)
                    if (r.report.vertices > 0) {
                        val stream = getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
                            ?: throw IllegalStateException("não foi possível abrir o arquivo de saída")
                        stream.use { it.write(r.data) }
                    }
                    r.report
                }
            }
            status = result.fold(
                onSuccess = { rep ->
                    if (rep.vertices == 0) "Nada exportado: crie um objeto visível com faces."
                    else "PMX exportado: ${rep.vertices} vértices, ${rep.triangles} triângulos, ${rep.materials} material(is), ${rep.bytes} bytes." +
                        " ${rep.bones} osso(s)." +
                        (if (rep.weighted > 0) " ${rep.weighted} vértice(s) com pesos." else "") +
                        (if (rep.warnings.isEmpty()) "" else " Avisos: " + rep.warnings.joinToString(" ")) +
                        (if (rep.morphs > 0) " ${rep.morphs} morph(s)." else "") +
                        " Sem texturas ou física."
                },
                onFailure = { "Erro ao exportar PMX: ${it.message}" }
            )
        }
    }

    // ---------- esqueleto ----------
    fun boneStepLabel(): String = fmt(boneSteps[boneStepIndex])
    fun cycleBoneStep() { boneStepIndex = (boneStepIndex + 1) % boneSteps.size }

    fun addHumanoidSkeleton() {
        val skeleton = Skeletons.humanoid()
        val ids = skeleton.map { it.id }.toSet()
        // objetos ligados a ossos que não existem mais no novo esqueleto ficam sem vínculo; pesos desses ossos somem
        val objs = project.objects.map { stripBones(it, ids) }
        commit(project.copy(objects = objs, bones = skeleton))
        selectedBoneId = skeleton.first().id
        status = "Esqueleto humanoide criado (${skeleton.size} ossos). Ligue cada objeto a um osso."
    }

    fun selectBone(id: String?) { selectedBoneId = id }

    /** Tira do objeto o vínculo e os pesos de ossos que não estão em [valid]. */
    private fun stripBones(o: SceneObject, valid: Set<String>): SceneObject {
        val newBone = if (o.boneId != null && o.boneId !in valid) null else o.boneId
        val w = o.weights
        val newWeights = if (w == null || valid.containsAll(w.palette)) w else Weighting.retain(w, valid)
        return if (newBone == o.boneId && newWeights === w) o else o.copy(boneId = newBone, weights = newWeights)
    }

    fun addBone() {
        val parent = project.bones.firstOrNull { it.id == selectedBoneId }
        val n = project.bones.size + 1
        val pos = if (parent != null) Vec3(parent.position.x, parent.position.y + 0.1f, parent.position.z) else Vec3(0f, 0.85f, 0f)
        val bone = Bone("b:" + UUID.randomUUID().toString().take(8), "Osso$n", "Bone$n", parent?.id, pos)
        commit(project.copy(bones = project.bones + bone))
        selectedBoneId = bone.id
        status = "Osso ${bone.name} criado."
    }

    fun deleteBone() {
        val b = project.bones.firstOrNull { it.id == selectedBoneId } ?: run { status = "Selecione um osso."; return }
        var bones = project.bones.filter { it.id != b.id }.map { if (it.parentId == b.id) it.copy(parentId = b.parentId) else it }
        // um IK que usava este osso (como ponta ou elo) deixa de existir
        val ikGone = bones.filter { o -> o.ik != null && (o.ik.targetId == b.id || o.ik.links.any { it.boneId == b.id }) }.map { it.id }.toSet()
        if (ikGone.isNotEmpty()) bones = bones.filter { it.id !in ikGone }
        val validIds = bones.map { it.id }.toSet()
        val objs = project.objects.map { stripBones(it, validIds) }
        commit(project.copy(bones = bones, objects = objs))
        selectedBoneId = null
        status = "Osso ${b.name} excluído (filhos sobem para o pai; objetos ligados ficaram sem vínculo)."
    }

    /**
     * Cria um osso IK para o osso selecionado (a ponta, ex.: tornozelo ou pulso). A cadeia são o pai (joelho/cotovelo) e o avô
     * (perna/braço) da ponta. O osso IK nasce na posição da ponta, filho do osso raiz. Mova o osso IK para ajustar; no MMD ele
     * puxa a cadeia. Obs.: o IK ainda NÃO é calculado no app (a pose de teste só gira ossos comuns).
     */
    fun createIk() {
        val t = project.bones.firstOrNull { it.id == selectedBoneId } ?: run { status = "Selecione o osso da ponta (ex.: tornozelo)."; return }
        if (t.ik != null) { status = "Este osso já é um IK."; return }
        if (project.bones.any { it.ik?.targetId == t.id }) { status = "Este osso já tem IK."; return }
        val byId = project.bones.associateBy { it.id }
        val p1 = t.parentId?.let { byId[it] }
        val p2 = p1?.parentId?.let { byId[it] }
        if (p1 == null || p2 == null) { status = "A ponta precisa de pai e avô (ex.: tornozelo → joelho → perna)."; return }
        val root = project.bones.firstOrNull { it.parentId == null && it.ik == null } ?: run { status = "O esqueleto precisa de um osso raiz."; return }
        var jp = if (t.name.endsWith("足首")) t.name.dropLast(1) + "ＩＫ" else t.name + "ＩＫ"
        if (project.bones.any { it.name == jp }) jp += "2"
        val en = (if (t.nameEn.isEmpty()) t.name else t.nameEn) + "_IK"
        val knee = p1.name.contains("ひざ") || p1.name.contains("ひじ") || p1.nameEn.startsWith("Knee") || p1.nameEn.startsWith("Elbow")
        val ik = IkData(t.id, 40, 2.0f, listOf(IkLink(p1.id, knee), IkLink(p2.id, false)))
        val bone = Bone("b:ik_" + UUID.randomUUID().toString().take(8), jp, en, root.id, t.position, ik)
        commit(project.copy(bones = project.bones + bone))
        selectedBoneId = bone.id
        status = "IK criado: $jp (ponta ${t.name}, cadeia ${p1.name} → ${p2.name}). No MMD o osso IK puxa a cadeia."
    }

    /** Renomeia o osso: [jp] é o nome usado no PMX (japonês no MMD); [en] é o nome em inglês (pode ficar vazio). */
    fun renameBone(id: String, jp: String, en: String) {
        val j = jp.trim()
        if (j.isEmpty()) { status = "O nome do osso não pode ficar vazio."; return }
        if (project.bones.any { it.id != id && it.name == j }) { status = "Já existe um osso com o nome $j."; return }
        commit(project.copy(bones = project.bones.map { if (it.id == id) it.copy(name = j, nameEn = en.trim()) else it }))
        status = "Osso renomeado para $j."
    }

    fun nudgeBone(axis: Int, dir: Int) {
        val id = selectedBoneId ?: run { status = "Selecione um osso."; return }
        val d = boneSteps[boneStepIndex] * dir
        commit(project.copy(bones = project.bones.map {
            if (it.id != id) it else it.copy(position = when (axis) {
                0 -> it.position.copy(x = it.position.x + d)
                1 -> it.position.copy(y = it.position.y + d)
                else -> it.position.copy(z = it.position.z + d)
            })
        }))
        status = "Osso movido ${if (dir > 0) "+" else "-"}${fmt(boneSteps[boneStepIndex])}."
    }

    fun bindObjectToBone(bind: Boolean) {
        val o = project.objects.firstOrNull { it.id == selectedId } ?: run { status = "Selecione um objeto na viewport ou na Hierarquia."; return }
        if (bind) {
            val b = project.bones.firstOrNull { it.id == selectedBoneId } ?: run { status = "Selecione um osso."; return }
            commit(project.copy(objects = project.objects.map { if (it.id == o.id) it.copy(boneId = b.id) else it }))
            status = "${o.name} ligado ao osso ${b.name}."
        } else {
            commit(project.copy(objects = project.objects.map { if (it.id == o.id) it.copy(boneId = null) else it }))
            status = "${o.name} sem vínculo."
        }
    }

    // ---------- pesos e pose de teste ----------
    private fun boneName(id: String): String = project.bones.firstOrNull { it.id == id }?.name ?: "?"

    /** Vértices que as ferramentas de peso usam: a seleção atual (vértices, ou os vértices das faces) no modo de edição; senão vazio. */
    private fun weightVerts(obj: SceneObject): Set<Int> {
        if (!editMode) return emptySet()
        val sel = if (faceMode) MeshOps.vertsOfTris(obj.mesh, selectedTris) else selectedVerts
        return sel.filter { it >= 0 && it < obj.mesh.vertexCount }.toSet()
    }

    private fun setWeights(obj: SceneObject, w: VertexWeights?, msg: String) {
        commit(project.copy(objects = project.objects.map { if (it.id == obj.id) it.copy(weights = w) else it }))
        status = msg
    }

    /** Texto do painel Pesos: pesos do vértice selecionado ou um resumo do objeto. */
    fun weightInfo(): String {
        val obj = project.objects.firstOrNull { it.id == selectedId } ?: return "Selecione um objeto (viewport ou Hierarquia)."
        val w = obj.weights
        if (w == null || w.vertexCount != obj.mesh.vertexCount) {
            val rigid = obj.boneId?.let { " Hoje ele segue inteiro o osso ${boneName(it)}." } ?: ""
            return "${obj.name}: sem pesos.$rigid Use Auto."
        }
        if (editMode && !faceMode && selectedVerts.size == 1) {
            val v = selectedVerts.first()
            val inf = Weighting.influences(w, v)
            val txt = if (inf.isEmpty()) "sem peso" else inf.joinToString(", ") { "${boneName(it.first)} ${(it.second * 100f).roundToInt()}%" }
            return "Vértice $v: $txt"
        }
        return "${obj.name}: ${Weighting.countWeighted(w)} de ${obj.mesh.vertexCount} vértices com pesos."
    }

    /** Pesos automáticos pela distância aos ossos: nos vértices selecionados (modo de edição) ou no objeto inteiro. */
    fun weightAuto() {
        if (project.bones.isEmpty()) { status = "Crie o esqueleto primeiro (aba Objeto → Esqueleto)."; return }
        val obj = editedObject() ?: run { status = "Selecione um objeto."; return }
        val sel = weightVerts(obj)
        val world = Weighting.worldPositions(obj, project.objects.associateBy { it.id })
        val w = Weighting.auto(world, project.bones, obj.weights, if (sel.isEmpty()) null else sel)
        val what = if (sel.isEmpty()) "objeto inteiro (${obj.mesh.vertexCount} vértices)" else "${sel.size} vértice(s)"
        setWeights(obj, w, "Pesos automáticos em $what. Gire ossos na pose de teste para conferir.")
    }

    private fun weightBone(): Bone? {
        val b = project.bones.firstOrNull { it.id == selectedBoneId }
        if (b == null) status = "Escolha um osso na lista do painel Pesos."
        return b
    }

    private fun weightSelection(obj: SceneObject): Set<Int>? {
        val sel = weightVerts(obj)
        if (sel.isEmpty()) {
            status = if (!editMode) "Entre em Editar e selecione vértices (ou faces) para pintar." else "Selecione vértices (ou faces) para pintar."
            return null
        }
        return sel
    }

    /** 100% do osso escolhido nos vértices selecionados. */
    fun weightAssign() {
        val obj = editedObject() ?: run { status = "Selecione um objeto."; return }
        val bone = weightBone() ?: return
        val sel = weightSelection(obj) ?: return
        val r = Weighting.assign(obj.weights, obj.mesh.vertexCount, sel, bone.id)
        setWeights(obj, r.weights, "${r.changed} vértice(s): 100% no osso ${bone.name}.")
    }

    /** sign +1 / −1: soma ou tira (passo) de peso do osso escolhido; os outros ossos do vértice compensam. */
    fun weightAdjust(sign: Int) {
        val obj = editedObject() ?: run { status = "Selecione um objeto."; return }
        val bone = weightBone() ?: return
        val sel = weightSelection(obj) ?: return
        val d = sign * weightSteps[stepIndex]
        val r = Weighting.adjust(obj.weights, obj.mesh.vertexCount, sel, bone.id, d)
        if (r.changed == 0) { status = "Nada mudou: o vértice só tem esse osso (ou já está no limite)."; return }
        setWeights(obj, r.weights, "${r.changed} vértice(s): ${if (sign > 0) "+" else "−"}${(weightSteps[stepIndex] * 100f).roundToInt()}% no osso ${bone.name}.")
    }

    /** Média dos pesos com os vizinhos, nos vértices selecionados. */
    fun weightSmooth() {
        val obj = editedObject() ?: run { status = "Selecione um objeto."; return }
        val sel = weightSelection(obj) ?: return
        if (obj.weights == null) { status = "Sem pesos para suavizar: use Auto primeiro."; return }
        val r = Weighting.smooth(obj.weights, obj.mesh, sel)
        setWeights(obj, r.weights, "Suavizado em ${r.changed} vértice(s).")
    }

    /** Zera os pesos dos vértices selecionados; sem seleção, zera o objeto inteiro (volta ao vínculo rígido). */
    /**
     * Espelha pesos em X dentro do objeto: com vértices selecionados (modo Editar), eles são a origem; sem seleção, a origem é o lado
     * esquerdo (x > 0). O vértice na posição (−x, y, z) recebe os pesos com os ossos L ↔ R trocados.
     */
    fun weightMirror() {
        val obj = editedObject() ?: run { status = "Selecione um objeto."; return }
        val w = obj.weights
        if (w == null || w.vertexCount != obj.mesh.vertexCount) { status = "Sem pesos para espelhar: use Auto primeiro."; return }
        val pos = obj.mesh.positions
        var src = weightVerts(obj).toList()
        val fromSel = src.isNotEmpty()
        if (!fromSel) src = (0 until obj.mesh.vertexCount).filter { pos[it * 3] > 0.0005f }
        val partners = mirrorPartners(pos, src)
        if (partners.isEmpty()) { status = "Nenhum par espelhado encontrado (a malha precisa ser simétrica em X)."; return }
        val r = Weighting.mirror(w, obj.mesh.vertexCount, partners) { mirrorBoneId(it) ?: it }
        setWeights(obj, r.weights, "Pesos espelhados em ${r.changed} vértice(s) (${if (fromSel) "da seleção" else "do lado x > 0"}, ossos L ↔ R trocados).")
    }

    fun weightClear() {
        val obj = editedObject() ?: run { status = "Selecione um objeto."; return }
        if (obj.weights == null) { status = "O objeto já está sem pesos."; return }
        val sel = weightVerts(obj)
        if (sel.isEmpty()) { setWeights(obj, null, "Pesos de ${obj.name} zerados."); return }
        val r = Weighting.clear(obj.weights, obj.mesh.vertexCount, sel)
        setWeights(obj, r.weights, "Pesos zerados em ${r.changed} vértice(s).")
    }

    // ---------- pincel de pesos ----------
    /** O pincel só age na ferramenta Pesos, fora do modo Editar, com objeto e osso escolhidos e sem pose de teste. */
    val brushActive: Boolean
        get() = brushOn && mode == ToolMode.WEIGHT && !editMode && selectedId != null && selectedBoneId != null && poseRot.isEmpty()

    fun brushRadiusLabel(): String = fmt(brushRadii[brushRadiusIdx])

    fun toggleBrush() {
        brushOn = !brushOn
        status = if (brushOn) "Pincel ligado: arraste 1 dedo sobre o objeto para pintar o osso escolhido (pinça = zoom). Desligue para girar a câmera."
        else "Pincel desligado: 1 dedo gira a câmera."
    }

    fun cycleBrushKind() {
        brushKind = (brushKind + 1) % 3
        status = when (brushKind) {
            0 -> "Pincel pinta o peso do osso escolhido."
            1 -> "Pincel apaga o peso do osso escolhido."
            else -> "Pincel suaviza os pesos (média com os vizinhos)."
        }
    }

    fun brushKindLabel(): String = when (brushKind) { 0 -> "Pintar"; 1 -> "Apagar"; else -> "Suavizar" }

    fun cycleBrushRadius() {
        brushRadiusIdx = (brushRadiusIdx + 1) % brushRadii.size
        status = "Raio do pincel: ${brushRadiusLabel()} (unidades do objeto; a intensidade é o Passo)."
    }

    /** Começo (true) ou fim (false) de uma pincelada: a pincelada inteira vira UM passo de Desfazer. */
    fun brushStroke(start: Boolean) {
        if (start) {
            strokeBase = if (brushActive) project else null
            strokeHits = 0
            strokeVerts = 0
            return
        }
        val base = strokeBase ?: return
        strokeBase = null
        if (project !== base) {
            undoStack.add(base)
            if (undoStack.size > 100) undoStack.removeAt(0)
            redoStack.clear()
            refreshFlags()
            status = "Pincelada: $strokeHits toque(s), $strokeVerts vértice(s) alterado(s) (soma). Desfazer desfaz a pincelada inteira."
        } else if (strokeHits > 0) {
            status = "Pincel: nada mudou (peso já no limite, ou o osso não tem outro osso para ceder; use Auto antes)."
        }
    }

    /** Ponto de contato do pincel no espaço local do objeto selecionado. */
    fun brushHit(x: Float, y: Float, z: Float) {
        if (strokeBase == null || !brushActive) return
        val obj = project.objects.firstOrNull { it.id == selectedId } ?: return
        val bone = project.bones.firstOrNull { it.id == selectedBoneId } ?: return
        if (obj.weights != null && obj.weights.vertexCount != obj.mesh.vertexCount) return
        strokeHits++
        val d = (if (brushKind == 1) -1f else 1f) * weightSteps[stepIndex]
        val r = if (brushKind == 2) Weighting.brushSmooth(obj.weights, obj.mesh, x, y, z, brushRadii[brushRadiusIdx])
            else Weighting.brush(obj.weights, obj.mesh.positions, bone.id, x, y, z, brushRadii[brushRadiusIdx], d)
        if (r.changed == 0) return
        strokeVerts += r.changed
        project = project.copy(objects = project.objects.map { if (it.id == obj.id) it.copy(weights = r.weights) else it })
        refreshDisplay()
    }

    fun poseLabel(): String {
        val id = selectedBoneId ?: return "Escolha um osso."
        val r = poseRot[id] ?: Vec3(0f, 0f, 0f)
        return "${boneName(id)}: X ${r.x.roundToInt()}°  Y ${r.y.roundToInt()}°  Z ${r.z.roundToInt()}°"
    }

    /** Gira o osso escolhido na pose de teste (15° por toque). Não altera o projeto. */
    fun poseBone(axis: Int, dir: Int) {
        val id = selectedBoneId ?: run { status = "Escolha um osso na lista."; return }
        val cur = poseRot[id] ?: Vec3(0f, 0f, 0f)
        val next = add(cur, axis, dir * poseStep)
        val map = HashMap<String, Vec3>(poseRot)
        if (next.x == 0f && next.y == 0f && next.z == 0f) {
            map.remove(id)
        } else {
            map[id] = next
        }
        poseRot = map
        refreshDisplay()
        status = "Pose de teste: ${poseLabel()}"
    }

    fun resetPose() {
        poseRot = emptyMap()
        refreshDisplay()
        status = "Pose de teste zerada."
    }

    fun load() {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { store.load() } }
            result.fold(
                onSuccess = { loaded ->
                    if (loaded == null) {
                        status = "Nenhum projeto salvo ainda."
                    } else {
                        undoStack.clear()
                        redoStack.clear()
                        morphRecording = null
                        morphValues = emptyMap()
                        selectedMemberId = null
                        selectedMorphId = null
                        activeGroupId = null
                        exitEdit()
                        poseRot = emptyMap()
                        project = loaded
                        selectedId = null
                        selectedBoneId = null
                        counter = loaded.objects.size
                        refreshFlags()
                        status = "Projeto aberto (${loaded.objects.size} objetos)."
                    }
                },
                onFailure = { status = "Erro ao abrir: ${it.message}" }
            )
        }
    }
}
