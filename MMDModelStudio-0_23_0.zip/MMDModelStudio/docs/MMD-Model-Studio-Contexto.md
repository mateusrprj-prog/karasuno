# MMD Model Studio --- Documento de Contexto do Projeto

> **Documento-base de visão, requisitos, arquitetura, prioridades e
> continuidade.**
>
> **Regra obrigatória de manutenção:** este arquivo deve ser atualizado
> e entregue novamente em formato `.md` a cada atualização relevante do
> aplicativo. Nenhuma atualização deve ser considerada documentada
> apenas em mensagens de conversa, commits ou arquivos de código.

------------------------------------------------------------------------

## 1. Identidade do projeto

-   **Nome provisório:** MMD Model Studio
-   **Plataforma principal:** Android
-   **Ambiente de desenvolvimento e teste do usuário:** Android, sem
    computador
-   **Categoria:** modelador 3D e editor de personagens especializado em
    MMD/PMX
-   **Formato principal de saída:** PMX
-   **Público-alvo inicial:** pessoas que querem criar personagens MMD,
    inclusive iniciantes sem experiência em modelagem 3D
-   **Projeto relacionado:** MMD Studio, aplicativo separado destinado
    principalmente à animação e utilização dos modelos

O nome é provisório e pode mudar futuramente. A finalidade central não
deve mudar sem uma decisão explícita: criar um aplicativo Android capaz
de produzir personagens MMD completos, editáveis e compatíveis, não
apenas visualizar, converter ou animar modelos existentes.

## 2. Visão e objetivo principal

Desenvolver um aplicativo Android que permita **criar personagens MMD do
zero**, com qualidade e recursos comparáveis aos encontrados em modelos
PMX bem construídos e compartilhados pela comunidade MMD.

O aplicativo deverá oferecer um fluxo completo de criação:

1.  Criar ou iniciar a geometria do personagem.
2.  Modelar corpo, cabeça, rosto, cabelo, roupas, calçados e acessórios.
3.  Organizar a malha, suas partes e seus materiais.
4.  Criar e editar UVs e texturas.
5.  Construir o esqueleto e sua hierarquia.
6.  Configurar IK e ossos auxiliares.
7.  Fazer weight painting e corrigir deformações.
8.  Criar morphs faciais e corporais.
9.  Configurar materiais e recursos específicos do MMD.
10. Configurar física de cabelos, roupas, saias e acessórios.
11. Organizar os controles e quadros de exibição.
12. Validar e exportar um arquivo PMX utilizável no MMD original.

**Não é suficiente** criar uma malha bonita, adicionar um esqueleto
genérico e exportar um GLB. O resultado desejado é um modelo PMX
estruturado corretamente, com os recursos próprios do ecossistema MMD.

O aplicativo deve permitir tanto criação manual quanto assistência
automática. A automação deve acelerar o trabalho, nunca retirar do
usuário a possibilidade de inspecionar, corrigir e configurar os dados
manualmente.

## 3. Contexto importante do usuário

-   O usuário ainda **não tem conhecimento de modelagem 3D**.
-   Aprender modelagem é um objetivo futuro, não uma exigência para
    começar a desenvolver o aplicativo.
-   O aplicativo deverá ser planejado para que uma pessoa iniciante
    consiga aprender gradualmente, com ferramentas claras, explicações
    contextuais, exemplos e ações reversíveis.
-   Não presumir que o usuário conheça termos como vértice, aresta,
    face, topologia, UV, rigging, peso, morph, IK, rigid body ou joint.
-   O usuário trabalha e testa projetos pelo Android. Não se deve
    pressupor acesso a Windows, macOS, Linux desktop, Blender desktop ou
    PMX Editor desktop.
-   O projeto deve ser construído em etapas pequenas, testáveis e
    funcionais.
-   Não apresentar uma interface cheia de botões sem implementação real.
-   Evitar exigir que o usuário modele tudo manualmente desde o primeiro
    dia. Futuramente, incluir primitivas, formas-base, modelos de
    referência, ferramentas guiadas e assistentes de criação.

## 4. O que o aplicativo deve ser --- e o que não deve ser

### Deve ser

-   Um modelador 3D para criação de personagens.
-   Um editor de dados e estruturas específicas de MMD.
-   Um ambiente para rigging, morphs, materiais e física.
-   Uma ferramenta de criação do zero, além de importação e edição de
    modelos existentes.
-   Um aplicativo utilizável em telas sensíveis ao toque.
-   Um projeto que salve dados editáveis, não somente o resultado
    exportado.
-   Um aplicativo que valide os arquivos produzidos e informe problemas
    de forma compreensível.

### Não deve ser

-   Apenas um visualizador PMX.
-   Apenas um conversor GLB/FBX/OBJ para PMX.
-   Apenas um editor de poses ou animações.
-   Apenas uma interface visual que simula ferramentas ainda não
    implementadas.
-   Um aplicativo centrado exclusivamente em escultura digital:
    modelagem poligonal, topologia, rigging, morphs e recursos MMD
    também são essenciais.
-   Uma cópia literal da interface de desktop do Blender ou PMX Editor.
    A experiência deve ser redesenhada para Android.

## 5. Referência de qualidade

A meta de qualidade é permitir a criação de personagens comparáveis, em
estrutura e acabamento técnico, aos bons modelos MMD encontrados na
comunidade:

-   Personagens humanoides estilizados/anime.
-   Rostos com geometria adequada e expressões variadas.
-   Olhos, boca, sobrancelhas e cabelo organizados de maneira editável.
-   Cabelos divididos em mechas ou partes que possam receber ossos e
    física.
-   Roupas e acessórios separados quando isso facilitar edição e
    simulação.
-   Topologia que permita deformações adequadas.
-   Texturas e materiais organizados.
-   Esqueleto completo e coerente.
-   Weight painting corrigível manualmente.
-   Morphs faciais, corporais e de materiais.
-   Física configurável por peça.
-   Exportação PMX validada.

A qualidade visual depende de modelagem, topologia, texturas, materiais
e conhecimento artístico. O aplicativo deve fornecer ferramentas
capazes, mas não prometer que um botão automático produzirá sempre um
personagem profissional.

## 6. Sistemas funcionais previstos

### 6.1. Motor 3D e viewport

É a fundação do aplicativo.

Requisitos: - Renderizar malhas 3D com câmera orbitável. - Gestos de
toque para orbitar, aproximar, afastar e deslocar a câmera. - Selecionar
objetos e componentes da malha. - Modos de visualização: sólido,
material, wireframe e, quando viável, inspeção de normais. - Grade,
eixos, gizmos e referências visuais. - Seleção de objetos por toque e
por lista/hierarquia. - Transformações de mover, girar e escalar. -
Controles adequados para telas pequenas. - Desempenho aceitável em
aparelhos Android de recursos variados. - Possibilidade de ocultar,
bloquear e isolar objetos.

A câmera do viewport não pode ser confundida com a transformação do
personagem. Girar a visualização não deve alterar a orientação real do
modelo.

### 6.2. Modelagem poligonal

Ferramentas necessárias: - Criar primitivas. - Criar objetos e malhas. -
Modo de objeto e modo de edição. - Seleção de vértices, arestas e
faces. - Mover, girar e escalar componentes. - Extrusão. - Inset. -
Bevel. - Subdivisão. - Mesclar e separar geometrias. - Duplicar e
espelhar. - Extrair/separar partes. - Preencher e apagar faces. -
Ajustar normais. - Ferramentas de simetria. - Histórico de
desfazer/refazer. - Operações com seleção múltipla.

As ferramentas devem funcionar de verdade na geometria. A interface deve
explicar o efeito das operações para iniciantes.

### 6.3. Escultura digital

Ferramentas planejadas: - Draw. - Smooth. - Grab. - Inflate. - Pinch. -
Flatten. - Crease. - Máscaras. - Simetria. - Controle de raio e
intensidade. - Níveis de subdivisão, se a arquitetura suportar. -
Conversão ou retopologia para uma malha utilizável em rigging.

A escultura é complementar. Não substitui a necessidade de uma boa malha
deformável.

### 6.4. Organização de objetos e peças

O usuário deve conseguir selecionar e editar partes separadamente.

Estrutura sugerida: - Corpo. - Cabeça. - Olhos. - Boca. - Cabelo por
grupos/mechas. - Roupas. - Sapatos. - Acessórios. - Outros objetos.

Requisitos: - Hierarquia de objetos. - Renomear, agrupar, ocultar e
bloquear. - Isolar uma peça. - Selecionar por lista. - Selecionar partes
na viewport. - Definir relações entre objetos. - Separar e unir objetos
quando apropriado. - Manter nomes e organização ao salvar e exportar.

O reconhecimento automático de partes pode ser adicionado futuramente,
mas não deve ser tratado como infalível. Deve existir sempre uma forma
manual de corrigir a classificação.

### 6.5. Topologia e retopologia

Requisitos: - Exibir wireframe. - Inspecionar densidade e distribuição
de polígonos. - Ferramentas de fluxo de arestas. - Simetria. -
Ferramentas para loops e cortes, conforme viabilidade. - Inspeção de
regiões de articulação: ombros, cotovelos, punhos, quadril, joelhos,
tornozelos e rosto. - Detecção de problemas comuns, como faces
degeneradas, normais inconsistentes e geometria duplicada. - Ferramentas
de retopologia em etapas futuras.

A topologia deve ser tratada como requisito central para deformação,
especialmente em rostos e articulações.

### 6.6. UV e texturas

Requisitos: - Criar e editar coordenadas UV. - Visualizar ilhas UV. -
Desdobrar (unwrap). - Ajustar, mover, girar e escalar ilhas. - Detectar
sobreposição quando possível. - Importar imagens como texturas. - Pintar
texturas em uma etapa futura. - Gerenciar arquivos de imagem do
projeto. - Visualizar materiais com textura. - Preservar caminhos e
referências de textura ao salvar/exportar.

### 6.7. Materiais e aparência MMD

Requisitos: - Criar e editar materiais. - Cor difusa. - Cor especular e
intensidade. - Ambiente/ambient, conforme o formato. - Transparência. -
Texturas. - Sphere Maps e modos compatíveis. - Toon textures. -
Configuração de contorno/edge. - Ordem e atribuição de materiais às
faces. - Pré-visualização aproximada do resultado MMD.

A aparência no viewport próprio deve ser comparada com a interpretação
do MMD original. Não assumir que um material que parece correto no
aplicativo será idêntico no MMD.

### 6.8. Rigging e esqueleto

Requisitos: - Criar ossos manualmente. - Criar hierarquia e
parentagem. - Definir posição, orientação e nome dos ossos. - Criar
estrutura humanoide inicial. - Ossos para coluna, quadril, pescoço e
cabeça. - Braços, antebraços, mãos e dedos. - Pernas, joelhos,
tornozelos e pés. - Ossos auxiliares para cabelo, roupa e acessórios. -
Espelhamento de ossos. - Ferramentas para reorganizar e renomear. -
Testar movimentos no viewport. - Definir propriedades específicas de
ossos PMX. - Criar e configurar IK.

O sistema automático de rigging deve ser assistido: gerar uma proposta,
permitir inspeção e oferecer correção manual. Deve suportar personagens
humanoides primeiro; outros tipos de rig podem vir depois.

### 6.9. Weight Painting

Requisitos: - Visualizar influência dos ossos por cores. - Selecionar o
osso que será pintado. - Pintar, apagar, suavizar e substituir pesos. -
Espelhar pesos. - Normalizar pesos. - Limitar influências conforme as
regras do formato. - Testar deformações em poses. - Inspecionar regiões
problemáticas. - Corrigir manualmente resultados automáticos.

O sistema precisa preservar os pesos corretamente na exportação PMX. Não
basta exibir uma pintura visual sem alterar os dados de influência da
malha.

### 6.10. Morph Editor

O Morph Editor é uma das áreas mais importantes do aplicativo.

Tipos a considerar: - Vertex Morph. - Bone Morph. - UV Morph e variações
suportadas. - Material Morph. - Group Morph. - Flip Morph, conforme
suporte do formato e compatibilidade.

Usos esperados: - Piscar. - Olhos fechados. - Olhos semicerrados. -
Sorriso. - Tristeza. - Raiva. - Surpresa. - Boca aberta e fechada. -
Formatos de boca/fonemas. - Sobrancelhas. - Bochechas e outras
deformações. - Mudanças de materiais. - Combinações de morphs.

Requisitos: - Criar morph a partir da malha base. - Registrar alterações
de vértices ou demais dados pertinentes. - Ajustar intensidade. -
Pré-visualizar. - Renomear e organizar. - Combinar morphs. - Testar
combinações conflitantes. - Definir categorias e quadros de exibição. -
Validar referências e índices antes da exportação.

O aplicativo deve explicar que morphs não são apenas imagens de
expressões: são dados estruturados associados à geometria, ossos, UVs,
materiais ou outros morphs.

### 6.11. Física MMD

Requisitos: - Criar rigid bodies. - Criar joints. - Configurar grupos de
colisão e máscaras. - Ajustar forma, tamanho, posição e rotação. -
Ajustar massa e parâmetros físicos aplicáveis. - Vincular física aos
ossos. - Pré-visualizar simulação. - Configurar cabelos por
mechas/grupos. - Configurar saias por painéis/partes. - Configurar
roupas e acessórios. - Permitir seleção individual de cada peça. -
Copiar configurações entre partes, com possibilidade de ajuste
individual.

A física deve ser configurável por personagem e por peça. Não aplicar
uma configuração global indiscriminadamente a todos os modelos.

### 6.12. Gerenciador PMX

Deve permitir editar e validar os dados próprios do formato: -
Informações e nomes do modelo. - Comentários e créditos. - Vértices e
índices. - Faces. - Materiais. - Texturas. - Ossos. - IK. - Morphs. -
Display Frames. - Rigid Bodies. - Joints. - Propriedades e referências
internas.

Deve haver uma representação interna consistente dos dados, separada da
interface. O formato PMX não deve ser manipulado por alterações
improvisadas espalhadas por diferentes telas.

### 6.13. Importação, exportação e validação

Formatos de entrada desejáveis: - PMX. - PMD, se viável. - OBJ. - FBX. -
GLB/GLTF.

Formato prioritário de saída: - PMX 2.0.

Formato posterior: - PMX 2.1, depois que a base 2.0 estiver testada.

A exportação deve: - Preservar os dados suportados. - Validar índices,
referências e hierarquias. - Verificar materiais e caminhos de
textura. - Verificar ossos e pesos. - Verificar morphs e seus
elementos. - Verificar rigid bodies e joints. - Avisar sobre recursos
não suportados. - Gerar relatório de erros e avisos. - Evitar afirmar
que o arquivo é compatível sem testes reais.

Critério essencial: abrir e testar os arquivos exportados no MMD
original e, quando aplicável, em ferramentas de referência. O
visualizador interno não é prova suficiente de compatibilidade.

------------------------------------------------------------------------

## 7. Experiência para iniciantes e aprendizado futuro

Como o usuário ainda não sabe modelagem, a experiência deve ensinar sem
exigir conhecimento prévio.

Recursos didáticos futuros: - Modo iniciante e modo avançado. -
Explicação curta ao selecionar uma ferramenta. - Dicas contextuais. -
Passo a passo para criar uma cabeça, corpo, cabelo e roupa. -
Demonstração visual de vértices, arestas e faces. - Exemplos de
topologia adequada e inadequada. - Guia de UV. - Guia de rigging
humanoide. - Guia de weight painting. - Guia de criação de morphs. -
Guia de física para cabelo e saia. - Projetos de treinamento. -
Desfazer/refazer confiável. - Avisos que expliquem o problema e como
corrigi-lo.

O usuário poderá aprender modelagem enquanto o aplicativo evolui. Não é
necessário dominar modelagem para iniciar a implementação do motor e das
ferramentas básicas.

## 8. Arquitetura técnica --- proposta inicial, não decisão imutável

A arquitetura deve ser avaliada por protótipos no Android real. Não
escolher tecnologias apenas por parecerem modernas.

Possíveis componentes: - **Interface:** Kotlin + Jetpack Compose. -
**Renderização 3D:** avaliar Filament, OpenGL ES ou Vulkan conforme
compatibilidade, desempenho e necessidades de edição. - **Geometria e
operações de malha:** avaliar C++/NDK para operações intensivas e
estruturas de dados apropriadas. - **Física:** avaliar Bullet ou outra
biblioteca compatível com Android e com os requisitos de simulação. -
**Formato PMX:** implementar ou adaptar um parser/exportador com testes
e documentação do formato. - **Persistência:** formato de projeto
próprio, versionado e recuperável. - **Arquivos:** gerenciar texturas e
recursos locais de forma confiável.

### Princípios de arquitetura

1.  Separar interface, dados do modelo, geometria, renderização, física
    e serialização.
2.  Não fazer da viewport a fonte única dos dados do projeto.
3.  Manter um modelo de dados interno consistente.
4.  Permitir salvar e reabrir projetos sem perda.
5.  Versionar o formato interno de projeto.
6.  Criar testes automatizados para parser, exportador e operações
    críticas.
7.  Projetar operações de geometria para malhas grandes sem bloquear a
    interface.
8.  Considerar memória, bateria, aquecimento e limitações de GPU de
    celulares.
9.  Ter recuperação após falhas e salvamento seguro.
10. Não assumir que todas as bibliotecas desktop funcionam no Android.

### Formato de projeto interno

O projeto deve ter um formato editável próprio, contendo: - Geometria e
objetos. - Hierarquia. - Materiais e referências de texturas. - UVs. -
Esqueleto. - Pesos. - Morphs. - Física. - Configurações do projeto. -
Versão do esquema.

A exportação PMX deve ser uma operação derivada desse projeto interno.
Assim, o usuário poderá continuar editando o personagem sem depender de
reimportar o arquivo exportado.

------------------------------------------------------------------------

## 9. Integração futura com o MMD Studio

O MMD Model Studio e o MMD Studio são projetos distintos, com
responsabilidades diferentes.

### MMD Model Studio

Criação e preparação de personagens: - Modelagem. - Materiais. -
Rigging. - Weight painting. - Morphs. - Física. - Exportação PMX.

### MMD Studio

Utilização dos personagens: - Importação de modelos. - Animação. -
Poses. - Timeline. - Câmeras. - Cenários. - Simulação e ajustes de
física durante a animação.

A integração principal será por arquivos PMX compatíveis. VMD/VPD e
outros formatos podem ser considerados conforme as necessidades do MMD
Studio.

Não acoplar os dois aplicativos de forma que um deixe de funcionar sem o
outro.

------------------------------------------------------------------------

## 10. Plano de desenvolvimento por prioridades

A ordem abaixo é uma proposta de implementação. Cada etapa deve ser
concluída e testada antes de avançar. Não criar todos os painéis de uma
vez.

### Fase 0 --- Pesquisa técnica e prova de viabilidade

1.  Estudar a estrutura do PMX 2.0 e os requisitos de compatibilidade.
2.  Avaliar bibliotecas de renderização no Android.
3.  Criar um protótipo mínimo de viewport.
4.  Testar leitura de uma malha simples.
5.  Testar salvamento e recuperação de projeto.
6.  Confirmar que a arquitetura escolhida funciona no dispositivo
    Android de teste.

**Critério de conclusão:** protótipo Android abre, renderiza, seleciona
e salva uma malha simples.

### Fase 1 --- Fundação do editor

1.  Projeto interno editável.
2.  Viewport 3D.
3.  Câmera e gestos.
4.  Seleção de objetos.
5.  Hierarquia.
6.  Transformações.
7.  Desfazer/refazer.
8.  Salvamento e abertura.

**Critério de conclusão:** usuário cria/abre uma cena, transforma
objetos, organiza a hierarquia e reabre o projeto sem perder dados.

### Fase 2 --- Modelagem básica

1.  Primitivas.
2.  Modo de objeto.
3.  Modo de edição.
4.  Vértices, arestas e faces.
5.  Extrusão.
6.  Inset.
7.  Bevel.
8.  Separar e unir.
9.  Simetria.
10. Normais e inspeção de malha.

**Critério de conclusão:** usuário consegue construir e editar uma malha
simples, sem depender de importação.

### Fase 3 --- Preparação de personagem

1.  Organização de partes.
2.  Ferramentas de escultura iniciais.
3.  Topologia e inspeção.
4.  UV básico.
5.  Materiais.
6.  Texturas.
7.  Ferramentas de referência e proporção.

**Critério de conclusão:** personagem simples composto por partes
organizadas, com material e textura.

### Fase 4 --- Estrutura PMX e exportação inicial

1.  Modelo de dados PMX.
2.  Leitura de arquivo PMX.
3.  Escrita de PMX 2.0.
4.  Materiais e texturas.
5.  Validação estrutural.
6.  Testes no MMD original.

**Critério de conclusão:** exportar e abrir um modelo simples no MMD
original. Recursos não implementados devem ser explicitamente
sinalizados.

### Fase 5 --- Rigging e pesos

1.  Criação manual de ossos.
2.  Hierarquia.
3.  Rig humanoide assistido.
4.  IK.
5.  Weight painting.
6.  Espelhamento e normalização.
7.  Testes de deformação.
8.  Exportação e validação.

**Critério de conclusão:** personagem humanoide simples pode ser posado
e deformado adequadamente, e o rig é preservado no PMX.

### Fase 6 --- Morph Editor

1.  Estrutura de morphs.
2.  Vertex Morph.
3.  Pré-visualização e intensidade.
4.  Morphs faciais.
5.  Group Morph.
6.  Bone Morph.
7.  Material Morph.
8.  UV Morph e demais tipos planejados.
9.  Organização em Display Frames.
10. Testes de compatibilidade.

**Critério de conclusão:** modelo exportado contém morphs funcionais que
podem ser acionados no MMD.

### Fase 7 --- Física MMD

1.  Rigid Bodies.
2.  Joints.
3.  Grupos de colisão.
4.  Vinculação a ossos.
5.  Ferramentas de cabelo.
6.  Ferramentas de saia e roupa.
7.  Simulação.
8.  Validação no MMD.

**Critério de conclusão:** uma peça simples de cabelo ou roupa possui
física configurável e funciona no MMD original.

### Fase 8 --- Recursos avançados e qualidade

1.  Retopologia mais avançada.
2.  Pintura de textura.
3.  Ferramentas avançadas de materiais.
4.  Assistente de criação de personagem.
5.  Detecção e classificação assistida de partes.
6.  Automação de rigging e pesos.
7.  Bibliotecas de presets editáveis.
8.  Otimização de desempenho.
9.  Melhorias de acessibilidade e tutoriais.

### Fase 9 --- Integração e acabamento

1.  Testes com modelos complexos.
2.  Testes com muitos morphs e ossos.
3.  Testes de física.
4.  Compatibilidade com MMD Studio.
5.  Exportação confiável.
6.  Relatórios de validação.
7.  Documentação de uso.
8.  Preparação de versões estáveis.

------------------------------------------------------------------------

## 11. Regras de qualidade e desenvolvimento

-   Não declarar uma função concluída se ela apenas tiver interface
    visual.
-   Não substituir uma implementação funcional por um mockup sem avisar.
-   Não remover recursos existentes sem avaliar impacto e documentar a
    decisão.
-   Corrigir regressões antes de adicionar novas funções.
-   Testar em dispositivo Android real sempre que possível.
-   Priorizar estabilidade e integridade dos projetos.
-   Manter operações de desfazer/refazer para ações destrutivas.
-   Avisar quando uma operação puder alterar muitos vértices ou dados.
-   Não descartar dados desconhecidos de PMX silenciosamente durante
    importação/exportação.
-   Registrar recursos ainda não suportados.
-   Evitar prometer compatibilidade total antes de testar no MMD
    original.
-   Manter nomes, índices e referências consistentes.
-   Fazer backups ou salvamento atômico dos projetos.
-   Preferir ferramentas pequenas e completas a grandes conjuntos de
    controles incompletos.

## 12. Testes obrigatórios

Cada sistema deve ter testes apropriados.

### Geometria

-   Criar e editar malhas.
-   Operações de extrusão, inset, separação e união.
-   Normais e índices.
-   Malhas vazias ou inválidas.

### Projeto interno

-   Salvar e reabrir.
-   Preservar hierarquia, materiais e referências.
-   Recuperar projeto após interrupção.
-   Migrar versões antigas do projeto.

### PMX

-   Importar arquivos de referência.
-   Exportar modelos simples e complexos.
-   Verificar índices e referências.
-   Verificar materiais, ossos, morphs e física.
-   Abrir os arquivos no MMD original.
-   Registrar diferenças de interpretação.

### Rigging e morphs

-   Testar deformações.
-   Testar IK.
-   Testar combinações de morphs.
-   Verificar se morphs não apontam para elementos incorretos.
-   Confirmar que a exportação preserva os dados.

### Física

-   Testar estabilidade da simulação.
-   Verificar grupos de colisão.
-   Verificar joints e vínculos.
-   Comparar comportamento no aplicativo e no MMD.

------------------------------------------------------------------------

## 13. Riscos e limitações conhecidos

1.  Criar um modelador 3D completo é um projeto grande e de longo prazo.
2.  O desenvolvimento no Android impõe limitações de tela, memória, GPU,
    aquecimento e ferramentas de compilação.
3.  PMX possui detalhes específicos que não são preservados por uma
    conversão genérica de GLB/FBX.
4.  Um rig automático pode precisar de correção manual.
5.  Weight painting de qualidade exige inspeção e testes.
6.  Morphs faciais de boa qualidade dependem de geometria apropriada.
7.  Física MMD exige configuração cuidadosa de rigid bodies, joints e
    colisões.
8.  A aparência do viewport pode diferir do MMD original.
9.  Bibliotecas externas precisam ter licença e compatibilidade
    verificadas.
10. O projeto não deve depender de serviços online para operações
    essenciais; funcionamento offline é uma meta importante.

------------------------------------------------------------------------

## 14. Decisões ainda em aberto

Estas decisões devem ser tomadas com protótipos, não por suposição:

-   Motor de renderização definitivo.
-   Linguagem e divisão entre Kotlin e C++.
-   Biblioteca de física.
-   Formato exato do projeto interno.
-   Estratégia de escultura e retopologia.
-   Importação de FBX e GLB.
-   Suporte a PMD.
-   Momento de implementação de PMX 2.1.
-   Estratégia de pintura de texturas.
-   Limites de polígonos e tamanho de projetos.
-   Distribuição de recursos entre versões gratuitas e futuras versões,
    se aplicável.

Não tratar propostas técnicas iniciais como decisões definitivas até
serem validadas no Android.

------------------------------------------------------------------------

## 15. Modelo de interface e usabilidade

A interface deve ser mobile-first.

Estrutura possível: - Viewport central. - Barra inferior contextual. -
Painel de propriedades recolhível. - Hierarquia de objetos acessível. -
Seletor de modos: Modelagem, Escultura, Materiais, Rigging, Pesos,
Morphs e Física. - Ferramentas com alvos de toque adequados. - Gestos
configuráveis. - Opção de desfazer/refazer visível. - Ajuda
contextual. - Controles importantes não devem ficar escondidos em menus
profundos.

Evitar reproduzir uma interface desktop comprimida. A tela deve
priorizar a tarefa atual e apresentar controles específicos do modo
selecionado.

------------------------------------------------------------------------

## 16. Como trabalhar com outras IAs e colaboradores

Este documento é a fonte principal de contexto do projeto.

Qualquer IA ou colaborador que receber este arquivo deve:

1.  Ler o documento inteiro antes de propor alterações.
2.  Respeitar o objetivo de criar modelos PMX completos do zero no
    Android.
3.  Considerar que o usuário é iniciante em modelagem.
4.  Não presumir que existe PC disponível.
5.  Não reduzir o projeto a conversão de modelos prontos.
6.  Não implementar apenas telas decorativas.
7.  Trabalhar de acordo com as prioridades e critérios de conclusão.
8.  Informar claramente o que foi realmente implementado, o que foi
    testado e o que continua pendente.
9.  Atualizar este documento depois de cada atualização relevante.
10. Entregar o arquivo `.md` atualizado junto com os demais arquivos da
    atualização.

Se uma decisão nova contradisser este documento, registrar a mudança na
seção de histórico e explicar o motivo. Não apagar decisões anteriores
importantes sem deixar registro.

------------------------------------------------------------------------

## 17. Regra obrigatória: atualizar e entregar o MD em toda atualização

**Esta regra é permanente e obrigatória.**

A cada atualização do aplicativo, seja pequena ou grande, deve ser
entregue uma nova versão atualizada deste documento Markdown.

A atualização do MD deve incluir, quando aplicável:

-   Nova versão do aplicativo.
-   Data da atualização.
-   Funcionalidades adicionadas.
-   Funcionalidades modificadas.
-   Correções realizadas.
-   Problemas conhecidos.
-   Testes executados e seus resultados.
-   Recursos que ainda são apenas protótipos.
-   Recursos planejados que continuam pendentes.
-   Mudanças de arquitetura.
-   Decisões técnicas tomadas.
-   Próximas prioridades em ordem.
-   Compatibilidade PMX efetivamente testada.

Não basta dizer que o MD foi atualizado: **o arquivo atualizado precisa
ser anexado/entregue ao usuário em cada atualização**.

Não substituir o contexto inteiro por uma lista curta de novidades.
Preservar este documento como base, atualizar as seções relevantes e
manter o histórico.

### Modelo de registro de atualização

Para cada versão, adicionar uma entrada:

``` text
## Histórico de atualizações

### Versão X.Y — AAAA-MM-DD
- Adicionado:
- Alterado:
- Corrigido:
- Testado:
- Ainda pendente:
- Próximas prioridades:
```

Se ainda não houver versão de aplicativo, registrar como
`Documento inicial / pré-desenvolvimento`.

------------------------------------------------------------------------

## 18. Estado inicial do projeto

**Estado:** planejamento / pré-desenvolvimento. *(Atualizado em 2026-11-22: base Android em evolução, versão atual 0.23.0 — ver seção 23.)*

Ainda não há uma implementação funcional confirmada do MMD Model Studio.

### Já definido

-   O aplicativo será voltado à criação de personagens MMD/PMX do zero.
-   A plataforma-alvo é Android.
-   O usuário não dispõe de PC para o fluxo de desenvolvimento e uso.
-   O usuário é iniciante em modelagem e pretende aprender no futuro.
-   O aplicativo deverá ensinar gradualmente e oferecer ferramentas
    acessíveis.
-   O objetivo é alcançar modelos completos, com malha, materiais,
    rigging, pesos, morphs e física.
-   O formato PMX é central.
-   O MMD Studio será um projeto separado que poderá consumir os modelos
    criados.
-   O MD atualizado deve ser entregue a cada atualização do aplicativo.

### Próximas prioridades imediatas

1.  Investigar e validar a renderização 3D no Android.
2.  Definir a estrutura de dados de geometria e objetos.
3.  Criar um protótipo de viewport funcional.
4.  Implementar seleção e transformações.
5.  Implementar salvamento e abertura de um projeto interno.
6.  Só então iniciar as ferramentas de modelagem poligonal.

### Não considerar implementado

Todos os sistemas descritos neste documento são requisitos ou planos,
salvo quando uma atualização futura registrar explicitamente sua
implementação e seus testes.

------------------------------------------------------------------------

## 19. Histórico do documento

### Documento inicial --- 2026-11-20

-   Criado o contexto-base do MMD Model Studio.
-   Definido o objetivo de criar personagens PMX completos do zero no
    Android.
-   Registrado que o usuário ainda é iniciante em modelagem e deverá
    poder aprender gradualmente.
-   Definidos os sistemas previstos, prioridades, critérios de qualidade
    e integração futura com MMD Studio.
-   Estabelecida a regra permanente de entregar o `.md` atualizado em
    toda atualização do aplicativo.
-   Estado do projeto: planejamento / pré-desenvolvimento.


---

## 20. Ambiente obrigatório de desenvolvimento: GitHub, build.yml e POCO X7 Pro

Esta seção é uma restrição operacional do projeto, não uma sugestão.

### Dispositivo e ferramentas

- O usuário utilizará **somente um POCO X7 Pro** para acompanhar, editar, enviar e testar o projeto.
- O fluxo de desenvolvimento deverá utilizar **GitHub** e **GitHub Actions**.
- O workflow de compilação deverá se chamar `build.yml`.
- Não exigir computador ou etapas que dependam de Windows, macOS ou Linux desktop.
- Não orientar o usuário a abrir o projeto no Blender desktop, Android Studio desktop, VS Code desktop ou PMX Editor desktop.
- Toda entrega compilável deverá permitir que o usuário obtenha o APK pelos artifacts do GitHub Actions e teste no POCO X7 Pro.

### Contrato obrigatório do workflow `build.yml`

**O primeiro `build.yml` deve ser entregue fora do ZIP do projeto**, como arquivo separado, para que o usuário consiga adicioná-lo diretamente ao repositório GitHub antes de enviar o ZIP com o código-fonte. Não colocar o único exemplar do workflow dentro do ZIP inicial, pois isso impediria o fluxo de bootstrap esperado.

Depois que o repositório estiver criado, o workflow poderá também ser incluído no código-fonte/ZIP nas atualizações seguintes, mas a primeira entrega precisa conter o arquivo `build.yml` separado e pronto para ser colocado no local correto do repositório (normalmente `.github/workflows/build.yml`).

O workflow deve ser genérico quanto ao nome do arquivo ZIP de entrada.

Regras:
1. **Nunca codificar um nome específico de ZIP** como `app.zip`, `source.zip`, `project.zip`, `MMDModelStudio.zip` ou semelhante.
2. Localizar os arquivos de entrada pela extensão `.zip`, sem diferenciar letras maiúsculas/minúsculas na extensão quando possível.
3. Procurar no diretório de entrada definido pelo próprio workflow/repositório, e não em um nome presumido.
4. Se não encontrar ZIP, encerrar com mensagem clara indicando onde o arquivo deveria ser colocado.
5. Se encontrar mais de um ZIP candidato, não escolher aleatoriamente: informar os arquivos encontrados e solicitar/usar um critério explícito de seleção. Se o workflow oferecer um input para caminho do ZIP, esse input deve aceitar qualquer nome.
6. Extrair o ZIP escolhido para um diretório de trabalho limpo.
7. Detectar a raiz real do projeto extraído, inclusive quando o ZIP contém uma pasta superior com nome arbitrário.
8. Validar a presença dos arquivos necessários à compilação antes de iniciar o Gradle.
9. Compilar e publicar o APK como artifact do workflow.
10. Exibir mensagens de erro úteis, sem ocultar a causa da falha.

O workflow não deve presumir que a pasta interna do ZIP tem um nome fixo. Deve identificar a raiz do projeto pelos arquivos de configuração do Gradle e pela estrutura do projeto Android.

### Entrega e teste

- A primeira entrega deverá fornecer o arquivo `build.yml` separadamente, fora do ZIP inicial, pronto para ser adicionado ao repositório GitHub em `.github/workflows/build.yml`.
- Cada atualização posterior deverá incluir o código-fonte atualizado e manter o workflow `build.yml` funcional; se o workflow for alterado, entregar também a versão atualizada do arquivo separadamente para fácil substituição no GitHub.
- Quando houver APK compilado, publicá-lo como artifact do GitHub Actions.
- Informar o resultado real da compilação: sucesso ou falha.
- Não afirmar que o APK foi testado no POCO X7 Pro se apenas foi compilado.
- Diferenciar claramente: compilado, instalado, iniciado e testado funcionalmente.
- Registrar no MD os testes efetivamente realizados no dispositivo.

---

## 21. Instrução de execução imediata para qualquer IA que receber este MD

**Ao ler este documento, a IA deverá começar a construir a base do aplicativo imediatamente.**

Não deve responder apenas com uma análise do documento, uma lista de sugestões, um novo planejamento ou perguntas sobre qual etapa iniciar. O planejamento principal já está definido aqui.

A primeira tarefa é entregar uma **base real e compilável do MMD Model Studio**, com:
- Estrutura inicial de aplicativo Android.
- Identidade/nome provisório MMD Model Studio.
- Tela principal inicial, organizada para futura viewport 3D.
- Arquitetura inicial separando interface e núcleo do projeto.
- Estrutura preparada para receber o motor 3D e o modelo de dados.
- Salvamento ou estrutura inicial de projeto, se viável nessa primeira base.
- Repositório/arquivos preparados para compilação por GitHub Actions.
- Workflow `build.yml` que aceite ZIP de qualquer nome, conforme o contrato da seção 20.
- Instruções curtas para o usuário enviar o ZIP pelo GitHub e baixar o APK no POCO X7 Pro.

A IA deverá tomar decisões técnicas razoáveis sem bloquear o início por perguntas não essenciais. Se uma escolha importante depender de teste, criar um protótipo pequeno e registrar a decisão como provisória.

### O que significa “fazer a base”

A primeira entrega não precisa conter modelagem avançada, rigging, morphs ou física. Porém, precisa ser um aplicativo Android verdadeiro, com projeto organizado e compilável, e não somente mockups, imagens, telas conceituais ou código ilustrativo.

A IA deve:
1. Examinar o ambiente/repositório fornecido.
2. Criar ou atualizar os arquivos do projeto.
3. Criar o `build.yml`.
4. Garantir que o workflow não dependa do nome do ZIP.
5. Fazer uma revisão dos arquivos e da configuração.
6. Entregar os arquivos atualizados e o MD atualizado.
7. Informar exatamente como executar o workflow pelo GitHub e obter o APK.
8. Registrar o que foi implementado, o que compilou e o que ainda não foi testado.

Se a IA não tiver acesso direto ao repositório ou não puder executar uma ação no GitHub, deverá entregar os arquivos completos necessários e instruções específicas para o usuário aplicá-los pelo celular, sem alegar que fez alterações remotas.

---

## 22. Histórico de atualizações do contexto

### Complemento operacional — 2026-11-20
- Especificado que o desenvolvimento e os testes serão feitos exclusivamente pelo Android, tendo o POCO X7 Pro como dispositivo principal.
- Definido GitHub + GitHub Actions como fluxo de versionamento e compilação.
- Definido `build.yml` como workflow de compilação.
- Tornado obrigatório que o workflow localize ZIPs pela extensão e não por um nome de arquivo fixo.
- Registrada a instrução para qualquer IA que receber o MD iniciar imediatamente a construção de uma base Android real e compilável, em vez de apenas discutir o planejamento.


### Complemento — bootstrap do primeiro workflow (2026-11-20)
- Definido que o primeiro `build.yml` deve ser entregue fora do ZIP inicial, como arquivo separado, para ser adicionado manualmente ao repositório GitHub antes do envio do ZIP com o código-fonte.
- Local esperado no repositório: `.github/workflows/build.yml`.
- Nas atualizações seguintes, se o workflow mudar, entregar também sua versão atualizada separadamente, além de mantê-lo no projeto quando aplicável.


### Versão 0.1.0 — 2026-11-20
- Adicionado: projeto Android real (Kotlin + Jetpack Compose + OpenGL ES 2.0): viewport 3D com grade e eixos, câmera orbital por toque (1 dedo gira, pinça faz zoom), criação de cubo, seleção por toque, exclusão, salvamento e abertura de projeto interno (JSON versionado, esquema 1, salvamento via arquivo temporário + cópia .bak). `build.yml` genérico entregue separado do ZIP.
- Alterado: nada (primeira base).
- Corrigido: nada.
- Testado: **nada ainda em dispositivo.** O código foi escrito e revisado, mas NÃO foi compilado nem instalado no ambiente em que foi gerado (sem rede/Gradle). O YAML do `build.yml` e o XML do manifesto foram validados sintaticamente.
- Ainda pendente: compilar no GitHub Actions, instalar e testar no POCO X7 Pro; todas as fases 1 a 9 do plano (seção 10), exceto o esboço da Fase 0 descrito na seção 23.
- Próximas prioridades: (1) confirmar compilação e execução no POCO X7 Pro; (2) transformações (mover/girar/escalar) e hierarquia; (3) desfazer/refazer; (4) modo de edição de malha.


### Versão 0.2.0 — 2026-11-20
- Adicionado: transformações do objeto selecionado (Mover, Girar, Escala) por botões de eixo com passo ajustável (pequeno/médio/grande); desfazer/refazer (até 100 níveis) para criar, excluir e transformar; lista de objetos na viewport para selecionar por nome; rotação no modelo de dados e no renderizador; esquema de projeto 2 (projetos do esquema 1 abrem com rotação zero).
- Alterado: interface compacta (cabeçalho virou texto sobreposto na viewport; barra inferior com 3 linhas) para sobrar mais área 3D em tela deitada. `build.yml`: quando houver mais de um ZIP, usa o de commit mais recente (critério explícito, registrado no log) e falha se houver empate.
- Corrigido: nada reportado. Risco conhecido do 0.1.0 (ZIPs antigos travarem o workflow) tratado no `build.yml`.
- Testado: v0.1.0 confirmada pelo usuário (print): compilou, instalou, iniciou, renderizou grade, eixos e cubo, e a seleção apareceu na barra de status. Salvar/Abrir, Excluir e gestos de câmera ainda não confirmados. **v0.2.0 não foi compilada nem testada.**
- Ainda pendente: hierarquia real (pai/filho), renomear, mover por arrastar na viewport/gizmo, modo de edição de malha, todo o resto do plano.
- Próximas prioridades: (1) confirmar 0.2.0 no POCO X7 Pro; (2) hierarquia e renomear; (3) modo de edição (vértices/arestas/faces); (4) extrusão e inset.


### Versão 0.2.1 — 2026-11-20
- Adicionado: nada.
- Alterado: nada funcional.
- Corrigido: a 0.2.0 falhou na compilação (GitHub Actions, `compileDebugKotlin`): conflito de assinatura JVM entre o setter automático da propriedade `mode` e a função `setMode` em `EditorViewModel`. Função renomeada para `selectMode`.
- Testado: nenhum teste novo. 0.2.1 ainda não compilada nem testada.
- Ainda pendente: igual à 0.2.0.
- Próximas prioridades: (1) confirmar compilação e uso no POCO X7 Pro; (2) hierarquia e renomear; (3) modo de edição de malha.


### Versão 0.3.0 — 2026-11-20
- Adicionado: hierarquia pai/filho (definir pai por lista, soltar do pai, indentação na lista "Hierarquia"); renomear objeto; ocultar/mostrar objeto; ferramenta "Objeto" na barra de baixo; matrizes de mundo hierárquicas no renderizador (filhos acompanham o pai) e na seleção por toque; esquema de projeto 3 (pai e visibilidade; projetos dos esquemas 1 e 2 abrem normalmente).
- Alterado: excluir um objeto agora exclui também seus filhos (desfazer recupera). Lista de objetos virou "Hierarquia".
- Corrigido: nada novo.
- Testado: v0.2.1 confirmada pelo usuário (print): compilou, instalou e iniciou; Girar aplicou rotação ao cubo; botões Desfazer/Refazer com estados corretos; lista de objetos e modos visíveis. Mover, Escala, Salvar/Abrir, Excluir e gestos de câmera ainda não confirmados explicitamente. **v0.3.0 não foi compilada nem testada.**
- Ainda pendente: ao definir um pai, os valores locais do filho são mantidos (o objeto pode "pular" de lugar; preservar a posição de mundo fica para depois); bloquear e isolar objeto; arrastar na viewport/gizmo; modo de edição de malha.
- Próximas prioridades: (1) confirmar 0.3.0 no POCO X7 Pro; (2) modo de edição de malha (vértices/arestas/faces); (3) extrusão e inset; (4) mover por arrastar na viewport.


### Versão 0.4.0 — 2026-11-20
- Adicionado: novas formas (Esfera, Cilindro, Plano) além do Cubo, escolhidas em "+ Forma"; **modo de edição de malha** (botão "Editar"): mostra arestas e vértices do objeto, seleção de vértices por toque (simples ou múltipla), ferramentas "Seleção" (Tudo, Nenhum, Inverter, Múltipla sim/não) e Mover/Girar/Escala aplicados aos vértices selecionados (eixos locais do objeto; Girar e Escala usam o centro da seleção). Edições de vértice entram no Desfazer/Refazer e são salvas no projeto (as posições já eram gravadas por inteiro, sem mudança de esquema; continua o esquema 3).
- Alterado: botão "+ Cubo" virou "+ Forma". Em modo de edição ficam desativados "+ Forma" e "Excluir". Sair da seleção do objeto sai do modo de edição. Arestas desenhadas = bordas e quinas (diagonais de triangulação entre faces coplanares ficam ocultas). Vértices são desenhados sobre as faces (visíveis mesmo atrás).
- Corrigido: nada novo.
- Testado: v0.3.0 confirmada pelo usuário (print): compilou, instalou e iniciou; hierarquia exibida com Cubo 2 como filho de Cubo 1 (indentação); dois cubos na viewport; rotação aplicada (status "Girar -15°"). Mover, Escala, Objeto (renomear/ocultar), Salvar/Abrir e Excluir ainda não confirmados. **v0.4.0 não foi compilada nem testada.** *(Atualizado na 0.5.0: ver entrada da 0.5.0 — a 0.4.0 foi compilada, instalada e aprovada pelo usuário.)*
- Ainda pendente: malha ainda é de **triângulos** (seleção de aresta e face, extrusão, inset e bevel ainda não existem); seleção de vértice sem considerar oclusão (pega o mais próximo do toque, mesmo atrás); mover vértices por arrastar; simetria; bloquear/isolar objeto; ao definir pai, valores locais são mantidos.
- Próximas prioridades: (1) confirmar 0.4.0 no POCO X7 Pro; (2) seleção de faces e arestas; (3) extrusão e inset; (4) mover por arrastar/gizmo; (5) simetria.


### Versão 0.5.0 — 2026-11-21
- Adicionado: **seleção de faces** no modo de edição (botão Vértice/Face em "Seleção" e em "Modelar"); toque numa face seleciona a região plana inteira (triângulos vizinhos e coplanares, ex.: a face quadrada do cubo) e a destaca em laranja translúcido; "Múltipla", Tudo, Nenhum e Inverter também valem para faces. Nova ferramenta **"Modelar"** (só aparece no modo de edição): **Extrudir +/−** (distância = Passo: 0,05 / 0,1 / 0,25; negativo faz um rebaixo para dentro), **Inset** (encolhe a face criando um anel em volta, com limite automático para não inverter faces pequenas) e **Apagar face** (remove triângulos e vértices sem uso; recusa apagar tudo). Mover/Girar/Escala passam a atuar nos vértices das faces selecionadas. Novo arquivo `core/MeshOps.kt` (operações de malha puras, sem Android).
- Alterado: ao trocar Face → Vértice, a seleção de faces vira seleção dos seus vértices; Vértice → Face limpa a seleção. Sair do modo de edição volta para modo Vértice. Versão do app 0.5.0 (versionCode 6). Esquema de projeto continua 3 (extrusão e inset apenas geram nova lista de posições/índices). `build.yml` não mudou.
- Corrigido: nada novo.
- Testado: **v0.4.0 compilada, instalada e aprovada pelo usuário no POCO X7 Pro** (print: esfera com vértices editados, cilindro, hierarquia, botões Mover/Girar/Escala/Objeto/Editar/Passo). A lógica de extrusão foi conferida fora do app com um espelho em Python: depois de extrudir a face de cima de um cubo (+0,5 e −0,3) a malha continua fechada, sem arestas soltas, e o volume sai correto (1,0 → 1,5 e 0,7). **O código Kotlin da 0.5.0 não foi compilado no ambiente de geração** (sem Kotlin/rede) *(atualizado na 0.6.0: o usuário compilou e instalou no POCO X7 Pro e enviou print e vídeo; ver 0.6.0)*.
- Ainda pendente: a malha continua de **triângulos**; em superfícies curvas (esfera, lado do cilindro) cada "face" é um único triângulo, porque só triângulos exatamente coplanares são agrupados; seleção de arestas; bevel, subdivisão, simetria, mesclar/separar; seleção de face sem checar oclusão além do triângulo mais próximo do raio (usa o mais próximo, correto para faces visíveis); mover por arrastar/gizmo; seleção de vértice ignora oclusão; ao definir pai os valores locais são mantidos; bloquear/isolar objeto; sem testes automatizados ainda.
- Próximas prioridades: (1) confirmar compilação e uso da 0.5.0 no POCO X7 Pro (extrudir, inset e apagar num cubo; salvar e reabrir); (2) seleção de arestas e corte em loop; (3) bevel e simetria; (4) decidir estrutura de polígonos (quads) para a malha; (5) mover por arrastar/gizmo.


### Versão 0.6.0 — 2026-11-21
- Adicionado: **Limpar** (solda vértices na mesma posição, remove triângulos degenerados, duplicados e paredes internas sobrepostas) e **Subdividir** (todos os triângulos da malha em 4, pontos médios compartilhados, sem rachaduras; a seleção de faces acompanha os filhos; limite 60000 triângulos) na ferramenta "Modelar".
- Alterado: Extrudir e Inset passam a rodar a limpeza automaticamente, e a seleção é remapeada. Versão 0.6.0 (versionCode 7). Esquema de projeto continua 3. `build.yml` não mudou.
- Corrigido: **chiado/cintilação (z-fighting) no cubo** visto no vídeo do usuário. Causa provável (hipótese, reproduzida fora do app): extrudir + e depois extrudir − na mesma face deixava dois conjuntos de paredes sobrepostas no mesmo plano. Reproduzido em script Python: extrudir +0,3 e −0,3 dava 28 triângulos; com a limpeza volta aos 12 do cubo original (8 vértices, malha fechada, volume 1,0). Se o chiado continuar no aparelho, a causa é outra e precisa de nova investigação.
- Testado: **v0.5.0 compilada, instalada e iniciada no POCO X7 Pro** (print: esfera com duas extrusões longas visíveis, ou seja, Extrudir funciona; vídeo: cubo com chiado nas faces após várias operações). Inset, Apagar face e Salvar/Abrir com malhas editadas não foram confirmados explicitamente. Verificação da limpeza: só o script Python acima. **O código Kotlin da 0.6.0 não foi compilado no ambiente de geração** *(atualizado na 0.7.0: o usuário compilou e testou no POCO X7 Pro; ver 0.7.0)*.
- Ainda pendente: igual à 0.5.0 (malha de triângulos, sem arestas/bevel/simetria/gizmo etc.). Subdividir não suaviza (só adiciona geometria plana); subdividir afeta a malha inteira, não só a seleção. Limpeza solda vértices coincidentes de propósito separados (não há esse caso hoje).
- Próximas prioridades: (1) confirmar 0.6.0 no POCO X7 Pro (extrudir + e − seguidos não deve mais chiar; Subdividir; Limpar); (2) seleção de arestas e corte em loop; (3) bevel e simetria; (4) decidir quads/polígonos; (5) mover por arrastar/gizmo.


### Versão 0.7.0 — 2026-11-21
- Adicionado: **limite de extrusão**: Extrudir (para dentro ou para fora) agora lança um raio de cada vértice da face e não deixa a face chegar a menos de 0,02 de outra parte da malha; se não houver espaço, a operação é recusada com a mensagem "Sem espaço…". Profundidade da tela de 24 bits.
- Alterado: plano próximo da câmera 0,1 → 0,3 e distante 200 → 100 (mais precisão de profundidade). Versão 0.7.0 (versionCode 8). Esquema de projeto continua 3. `build.yml` não mudou.
- Corrigido: **chiado persistente (z-fighting)** visto nos dois vídeos. Causa identificada pelo vídeo da 0.6.0: o usuário cavou o cubo com Extrudir − várias vezes (passos de 0,1) até passar da espessura de 1,0; o fundo do buraco coincidia com a face de trás do cubo (duas faces no mesmo plano). A limpeza da 0.6.0 só tratava duplicatas exatas, não esse caso. Hipótese secundária: o buffer de profundidade padrão do GLSurfaceView costuma ser de 16 bits.
- Testado (vídeo do usuário, 0.6.0 no POCO X7 Pro): modo Face, Extrudir + e −, Subdividir (88 → 352 → 1408 → … até 10688 triângulos), Desfazer e Refazer funcionam. Não apareceram no vídeo: Inset, Apagar face, Limpar, Salvar/Abrir com malha editada. O chiado ainda aparecia (causa acima). Verificação do limite: script Python (raio do topo do cubo para baixo: 1,0; para cima: nenhum). **O código Kotlin da 0.7.0 não foi compilado no ambiente de geração** *(atualizado na 0.8.0: o usuário compilou e testou; ver 0.8.0)*.
- Ainda pendente: Subdividir afeta a malha inteira e cresce rápido (cada toque ×4; o limite é 60000 triângulos); sem subdivisão só da seleção; sem seleção de arestas, bevel, simetria, quads, gizmo. O limite de extrusão não cobre Mover/Escala de vértices (que ainda podem atravessar partes da malha) nem o Inset.
- Próximas prioridades: (1) confirmar 0.7.0 no POCO X7 Pro (cavar o cubo com Extrudir − deve parar a 0,02 do fundo, sem chiado); (2) testar Inset, Apagar face, Limpar e Salvar/Abrir; (3) subdividir só a seleção; (4) seleção de arestas e corte em loop; (5) bevel, simetria e decisão sobre quads.


### Versão 0.8.0 — 2026-11-21
- Adicionado: **rede de segurança contra chiado**: depois de Extrudir ou Inset o app procura triângulos coplanares que se sobrepõem em área (`MeshOps.hasOverlap`, agrupando por plano) e **recusa a operação** se ela criaria sobreposição numa malha que estava limpa. Planos com triângulos demais (mais de ~630 no mesmo plano, ex.: face muito subdividida) não são checados, para não travar o app. **Regra da quina**: Extrudir − numa face que vai até a quina de 90° do objeto é recusado ("faça Inset antes de afundar").
- Alterado: mensagens de recusa mais claras. Versão 0.8.0 (versionCode 9). Esquema de projeto continua 3. `build.yml` não mudou.
- Corrigido: **chiado persistente na 0.7.0**. Causa real, reproduzida em simulação: afundar (Extrudir −) uma face inteira do cubo faz as paredes do rebaixo caírem exatamente no plano das faces laterais vizinhas, e duas faces no mesmo plano chiam. Uma única operação já bastava. A hipótese da 0.7.0 (fundo do buraco na face de trás) era só um dos casos; o limite de 0,02 e o buffer de 24 bits ficam, mas não eram a causa principal. Em simulação com 150 sequências aleatórias de Extrudir, Inset, Apagar, Subdividir e Limpar, antes ~27 geravam sobreposição (a primeira só com um Extrudir −); com a regra da quina e a rede de segurança: 0.
- Testado (prints do usuário, 0.7.0 no POCO X7 Pro): Apagar face funciona (2 triângulos apagados deixaram o cubo oco, limpo, sem chiado); seleção de vértice no modo Vértice; Mover de objeto; botões da ferramenta Modelar visíveis. Os prints mostraram quadros aninhados com bordas serrilhadas e uma faixa muito longa (provável prisma extrudido várias vezes para fora). Não foram vistos: Inset isolado, Limpar, Salvar/Abrir com malha editada. **O código Kotlin da 0.8.0 não foi compilado no ambiente de geração**; a lógica foi validada pelo simulador em Python *(atualizado na 0.9.0: o usuário compilou e testou a 0.8.0 em vídeo; ver 0.9.0)*.
- Ainda pendente: o Inset em regiões em L ou finas ainda pode produzir sobreposição (agora é recusado, não corrigido); Mover/Escala de vértices não passam pela checagem; Subdividir afeta a malha inteira e cresce ×4; sem seleção de arestas, bevel, simetria, quads, gizmo.
- Próximas prioridades: (1) confirmar 0.8.0 no POCO X7 Pro (Extrudir − numa face inteira deve ser recusado; Inset e depois Extrudir − deve funcionar sem chiado); (2) testar Limpar e Salvar/Abrir; (3) subdividir só a seleção; (4) seleção de arestas e corte em loop; (5) bevel, simetria e decisão sobre quads.


### Versão 0.9.0 — 2026-11-21
- Adicionado: **Subdividir só a seleção**: com faces selecionadas, cada triângulo selecionado vira 4; triângulos vizinhos que dividem uma aresta cortada são divididos em 2, 3 ou 4 partes, sem rachaduras; a seleção continua nos filhos. Sem nenhuma face selecionada (ou em modo Vértice), continua subdividindo a malha inteira. A mensagem de status informa "só a seleção" ou "malha inteira".
- Alterado: versão 0.9.0 (versionCode 10). Esquema de projeto continua 3. `build.yml` não mudou.
- Corrigido: nada novo (a 0.8.0 não apresentou defeitos no teste do usuário).
- Testado (vídeo do usuário, 0.8.0 no POCO X7 Pro, 2026-11-21): modo Face e seleção de faces; **Inset funciona** (vários Insets aninhados, sem chiado); **Extrudir − numa face inteira foi recusado** com a mensagem "Recusado: sem espaço, ou a face vai até a quina do objeto (faça Inset antes de afundar)", como projetado; a rede de segurança recusou uma operação ("Recusado: criaria faces sobrepostas no mesmo plano"); Extrudir + (0,1) e Extrudir − depois do Inset ("Limitado para não encostar em outra parte da malha") funcionam; **sem chiado** nos quadros do vídeo. Print: dois objetos (Cubo 1 com Insets e Cilindro 2 com quatro braços extrudidos para fora) e Mover de objeto. Verificação da subdivisão parcial: simulador em Python (malha fechada e volume 1,0 em 4 seleções). **O código Kotlin da 0.9.0 não foi compilado no ambiente de geração** *(atualizado na 0.10.0: o usuário compilou e testou a 0.9.0 em vídeo; ver 0.10.0)*.
- Ainda pendente: Limpar e Salvar/Abrir com malha editada nunca foram confirmados pelo usuário; Inset em regiões em L ou finas pode ser recusado; Mover/Escala de vértices não passam pela checagem de sobreposição; sem seleção de arestas, bevel, simetria, quads, mover por arrastar/gizmo.
- Próximas prioridades: (1) confirmar 0.9.0 no POCO X7 Pro (subdividir uma face só e conferir que o resto do cubo continua sem rachaduras; **testar Salvar e Abrir com a malha editada**); (2) seleção de arestas e corte em loop; (3) bevel e simetria; (4) decisão sobre quads; (5) mover por arrastar/gizmo.


### Versão 0.10.0 — 2026-11-21
- Adicionado: **primeira exportação PMX 2.0** (botão "PMX" na linha de cima; abre o seletor de arquivos do Android e grava `modelo.pmx` onde o usuário escolher). Novo `core/PmxExporter.kt` (Kotlin puro). Escreve: cabeçalho PMX 2.0 (UTF-16LE, índices de 4 bytes), vértices (BDEF1 no osso 0), faces, 0 texturas, **1 material por objeto visível** (difusa cinza clara, dupla face, toon interno 01), **1 osso "センター"/"Center"**, 0 morphs, quadros de exibição "Root" e "表情", 0 corpos rígidos, 0 juntas. A hierarquia, posição, rotação e escala de cada objeto são aplicadas nos vértices (mundo). Normais com vinco de 45° (cubo fica com arestas duras, curvas ficam suaves; vértices são duplicados onde necessário). Objetos ocultos ou sem faces são pulados com aviso. A mensagem de status informa vértices, triângulos, materiais, bytes e avisos.
- Conversão de coordenadas (provisória): app destro Y-para-cima → PMX canhoto: nega Z (posição e normal) mantendo a ordem dos índices. **Escala: 1 unidade do app = 12 unidades do MMD** (1 unidade ≈ 1 m, personagem de ~20). Valores a conferir no MMD.
- Alterado: versão 0.10.0 (versionCode 11). Esquema de projeto continua 3. `build.yml` não mudou.
- Corrigido: nada novo.
- Testado (vídeos do usuário, 0.9.0 no POCO X7 Pro, 2026-11-21): **Salvar e Abrir funcionam** (Extrudir +0,1 → "Projeto salvo (1 objetos)" → "Projeto aberto (1 objetos)", cubo de volta); **Subdividir só a seleção funciona** ("12 → 22 triângulos (só a seleção)", igual ao simulador); modo Vértice mostra os vértices novos. Verificação do PMX: espelho do exportador em Python + leitor PMX independente escrito a partir da especificação: o arquivo de um cubo (24 vértices, 12 triângulos, 1 material, 1 osso, 2 quadros) foi lido até o último byte, sem sobra e com todas as contagens consistentes. **O código Kotlin da 0.10.0 não foi compilado no ambiente de geração, e o PMX não foi aberto no MMD original nem no MMD Studio** *(atualizado na 0.11.0: o usuário compilou, exportou e abriu o PMX no MMD Studio; ver 0.11.0)*.
- Compatibilidade PMX efetivamente testada: **nenhuma em programa real** (só leitura estrutural em Python). Não há leitor/importador PMX no app.
- Ainda pendente: texturas e UV reais (todos os UV são 0,0), ossos de personagem, pesos, IK, morphs, física; nomes de material em japonês/inglês iguais ao nome do objeto; sem opção de escala nem de cor do material; sem validação interna do arquivo exportado.
- Próximas prioridades: (1) **abrir o `modelo.pmx` exportado no MMD Studio / MMD original e registrar o resultado** (tamanho, orientação das faces, normais, escala); (2) conforme o resultado, corrigir escala, orientação ou normais; (3) seleção de arestas e corte em loop; (4) bevel e simetria; (5) decisão sobre quads; (6) mover por arrastar/gizmo; (7) materiais editáveis e UV básico.


### Versão 0.11.0 — 2026-11-21
- Adicionado: **esqueleto e vínculo rígido** (início da Fase 5). Novo modelo de dados `Bone` (id, nome japonês, nome inglês, pai, posição absoluta) em `ModelProject.bones`; `SceneObject.boneId` liga o objeto inteiro a um osso. **Esquema de projeto 4** (projetos dos esquemas 1 a 3 abrem normalmente, sem ossos). Esqueleto pronto **"Humanoide"** (`Skeletons.humanoid()`, 19 ossos com nomes padrão do MMD: センター, 下半身, 上半身, 首, 頭, 左/右 肩, 腕, ひじ, 手首, 足, ひざ, 足首; esquerda = +X). **Painel "Esqueleto"** (aba Objeto → botão "Esqueleto"; painel flutuante que não bloqueia a viewport): criar o humanoide, "+ Osso" (filho do osso selecionado), "Excluir" (filhos sobem para o pai e objetos ligados ficam sem vínculo), mover o osso selecionado em X/Y/Z com Passo próprio (0,02/0,05/0,1/0,25), "Ligar ao osso"/"Desligar" para o objeto selecionado, lista de ossos com hierarquia. Os ossos aparecem no viewport por cima da malha (linhas e juntas verdes, osso selecionado laranja). Tudo entra no Desfazer/Refazer e é salvo no projeto.
- Alterado: **o PMX agora exporta os ossos do projeto** (sem esqueleto: continua o osso único センター). Cada objeto fica inteiro no osso a que está ligado (BDEF1); objeto sem vínculo vai para o primeiro osso, com aviso. Ossos raiz giram e movem (0x001E); os demais só giram (0x001A); ponta do osso aponta para o primeiro filho. Quadros de exibição: "Root" (osso 0), "表情" (vazio) e "ボーン" (demais ossos). A mensagem de status passa a informar o número de ossos. Texto de status do canto superior esquerdo não cobre mais a Hierarquia. Versão 0.11.0 (versionCode 12). `build.yml` não mudou.
- Corrigido: sobreposição do texto de status com o painel Hierarquia (visível nos vídeos da 0.10.0).
- Testado (vídeos do usuário, 0.10.0 no POCO X7 Pro e no MMD Studio, 2026-11-21): **exportação PMX funciona** ("PMX exportado: 332 vértices, 220 triângulos, 1 material(is), 16808 bytes" para o cubo com Insets); **o MMD Studio importou o PMX** ("Projeto 4") e mostrou o cubo com os Insets, do lado certo (faces frontais corretas), com sombreamento plano e arestas duras; a escala não foi medida no vídeo. Verificação do formato com esqueleto: espelho do exportador em Python + leitor PMX independente: arquivo com 24 vértices, 12 triângulos, 19 ossos e 3 quadros lido até o último byte, parentes válidos. **O código Kotlin da 0.11.0 não foi compilado no ambiente de geração.** *(Atualizado na 0.12.0: o usuário informou que a 0.11.0 foi testada e aprovada no POCO X7 Pro; ver 0.12.0.)*
- Compatibilidade PMX efetivamente testada: **cubo sem esqueleto (0.10.0) importado no MMD Studio**, visualização correta. Ainda não testado: no MMD original; modelo com ossos; posar os ossos; escala exata.
- Ainda pendente: pesos por vértice (hoje o objeto inteiro segue um osso, ou seja, rig rígido: vale para peças como cabeça, tronco e membros separados, mas não deforma uma malha única); IK; renomear ossos; mover ossos arrastando no viewport; espelhar ossos; propriedades de osso PMX (camada, visibilidade); morphs; física; texturas e UV; seleção de arestas; bevel; simetria; quads.
- Próximas prioridades: (1) confirmar 0.11.0 no POCO X7 Pro (criar o humanoide, ligar uma esfera à cabeça e um cilindro ao braço, exportar) e **abrir o PMX no MMD Studio e posar os ossos** (a peça ligada deve seguir o osso); (2) pesos por vértice (weight painting básico); (3) IK de pernas e braços; (4) morphs; (5) seleção de arestas, bevel, simetria; (6) materiais editáveis e UV.


### Versão 0.12.0 — 2026-11-21
- Adicionado: **pesos por vértice** (continuação da Fase 5). Cada vértice pode ter até 4 ossos com pesos que somam 1 (`SceneObject.weights`; novo arquivo `core/Weights.kt`: `VertexWeights` e `Weighting`). **Esquema de projeto 5** (os pesos são salvos; projetos dos esquemas 1 a 4 abrem normalmente, sem pesos). Nova ferramenta **"Pesos"** na barra (aparece quando existe esqueleto) com painel flutuante: lista de ossos para escolher o osso ativo, leitura dos pesos do vértice selecionado (ou resumo do objeto), **mapa de cores** do osso ativo sobre o objeto selecionado (azul 0% → ciano → verde → amarelo → vermelho 100%) e pose de teste. Botões: **Auto** (proposta automática pela distância aos ossos: cada osso vale como o segmento osso→primeiro filho; ossos folha usam a continuação do osso pai; os 4 ossos mais próximos recebem peso 1/(d²+0,0025)^1,5; influências abaixo de 5% são descartadas; o osso "センター", raiz de movimento, fica de fora), **100%** (todo o peso no osso ativo), **+Peso / −Peso** (soma ou tira 10/25/50% conforme o Passo; os outros ossos do vértice compensam na mesma proporção), **Suavizar** (média com os vizinhos, uma passada) e **Zerar**. No modo de edição agem nos vértices selecionados (ou nos vértices das faces selecionadas); Auto sem seleção, e fora do modo de edição, age no objeto inteiro. **Pose de teste** (`core/Skinning.kt`, não é salva no projeto): girar o osso ativo em X/Y/Z de 15° em 15° e ver a malha deformar por "linear blend skinning" (a mesma regra do MMD para BDEF); os ossos aparecem na posição posada; objetos só com vínculo rígido também seguem o osso; "Zerar pose". Sair da ferramenta Pesos zera a pose.
- Alterado: **o PMX exporta os pesos**: vértice com 1 osso = BDEF1, 2 ossos = BDEF2, 3 ou 4 = BDEF4 (vagas sobrando repetem o 1º osso com peso 0). Vértice sem peso em objeto com pesos vai para o osso do objeto (ou o 1º osso) com aviso; a mensagem de status informa quantos vértices exportados têm pesos. **Operações que mudam os vértices (Extrudir, Inset, Subdividir, Apagar face, Limpar quando mexe em vértices) descartam os pesos do objeto**, com aviso na barra de status (os índices dos vértices mudam; remapear fica para depois); Mover/Girar/Escala de vértices mantêm os pesos. Excluir um osso, ou recriar o humanoide, remove dos pesos os ossos que deixaram de existir. A linha de ferramentas usa fonte 11 (cabe mais um botão). O shader ganhou cor por vértice (usada só no mapa de pesos). Versão 0.12.0 (versionCode 13). `build.yml` não mudou.
- Corrigido: nada novo.
- Testado: **v0.11.0 testada e aprovada pelo usuário** (informado ao pedir a 0.12.0; o vídeo enviado junto era uma gravação de tela da conversa anterior, então os detalhes dos testes não foram vistos nesta sessão). Verificação da 0.12.0 fora do app, em espelho Python da lógica (24 checagens, todas passaram): pesos automáticos sempre com 1 a 4 influências somando 1; ombro/braço/antebraço dominados pelos ossos certos; pose identidade não move nada (também com objeto girado/escalado); girar o cotovelo 90° leva a ponta do antebraço para a posição esperada e não mexe no braço; osso filho acompanha o pai; objeto rígido gira em torno da junta; +25% e −25% se desfazem; −100% remove o osso e renormaliza; vértice de um osso só não muda com −Peso. Leitor de BDEF1/BDEF2/BDEF4 escrito a partir da especificação PMX leu os três tipos sem sobra de bytes. **O código Kotlin da 0.12.0 não foi compilado no ambiente de geração** (sem Kotlin/rede).
- Compatibilidade PMX efetivamente testada: igual à 0.11.0 (cubo sem esqueleto importado no MMD Studio). **BDEF2/BDEF4 ainda não foram abertos no MMD Studio nem no MMD original.**
- Ainda pendente: pintar pesos arrastando o dedo (pincel) — hoje é por seleção + botões; remapear pesos quando a malha muda; SDEF; salvar a pose ou exportá-la (VPD/VMD); girar ossos arrastando; IK; renomear ossos; morphs; física; texturas e UV; seleção de arestas; bevel; simetria; quads.
- Próximas prioridades: (1) confirmar 0.12.0 no POCO X7 Pro: criar o humanoide, criar um cilindro, esticar e subdividir até ter vários anéis, escolher **Pesos → Auto**, girar um osso na pose de teste e conferir a deformação; exportar o PMX e **posar no MMD Studio**; (2) IK de pernas e braços; (3) morphs (Fase 6); (4) pincel de pesos e remapeamento após editar a malha; (5) seleção de arestas, bevel, simetria; (6) materiais editáveis e UV.


### Versão 0.13.0 — 2026-11-21
- Adicionado: **remapeamento de pesos**. Extrudir, Inset, Subdividir, Apagar face e Limpar **não descartam mais os pesos**: cada vértice novo copia os pesos do vértice antigo mais próximo (posição local do objeto; vértice que não se moveu copia o seu próprio). Nova função `Weighting.remap` (grade espacial, rápida em malhas grandes). **Renomear osso** (painel Esqueleto → "Renomear"): nome do PMX (japonês no MMD) e nome em inglês; recusa nome vazio e nome repetido.
- Alterado: a mensagem de status informa "Pesos remapeados (vértices novos copiam o vizinho mais próximo; confira com Suavizar)". Se o remapeamento falhar, aparece "Pesos perdidos: refaça com Pesos → Auto". Versão 0.13.0 (versionCode 14). Esquema de projeto continua 5. `build.yml` não mudou.
- Corrigido: nada novo (a 0.12.0 ainda não tinha relato de teste do usuário ao gerar a 0.13.0).
- Testado: **nada em dispositivo.** A busca do vizinho mais próximo (grade com casca de anéis) foi reproduzida em Python e comparada com força bruta: 0 divergências em 30 conjuntos aleatórios (até 400 vértices, incluindo pontos fora da caixa dos vértices antigos). **O código Kotlin da 0.13.0 não foi compilado no ambiente de geração**, e a 0.12.0 também continua sem confirmação do usuário (compilação, pesos Auto, pose de teste, PMX com BDEF2/4 no MMD Studio).
- Ainda pendente: o remapeamento é de vizinho mais próximo (sem interpolar): em Subdividir, o ponto do meio de uma aresta copia um dos dois extremos, então use Suavizar se a transição ficar áspera; pincel de pesos por arrastar; SDEF; salvar/exportar pose; girar ossos arrastando; IK; morphs; física; texturas e UV; seleção de arestas; bevel; simetria; quads. Renomear osso não altera os ossos já exportados (exporte de novo).
- Próximas prioridades: (1) **confirmar a 0.12.0 e a 0.13.0 no POCO X7 Pro** (Pesos → Auto; depois Subdividir e conferir que a cor dos pesos continua; Renomear osso; exportar PMX e posar no MMD Studio); (2) IK de pernas e braços; (3) morphs (Fase 6); (4) pincel de pesos; (5) seleção de arestas, bevel, simetria; (6) materiais editáveis e UV.


### Versão 0.14.0 — 2026-11-21
- Adicionado: **IK no esqueleto e no PMX** (Fase 5, item 4). Novos dados `IkData`/`IkLink` em `Bone.ik` (osso da ponta, repetições, ângulo limite, elos). **Esquema de projeto 6** (IK é salvo; projetos 1 a 5 abrem normalmente). Painel Esqueleto: botão **"Criar IK"** para o osso selecionado como ponta (ex.: tornozelo ou pulso): cria o osso IK na posição da ponta, filho do osso raiz, com nome "…ＩＫ" (ex.: 左足首 → 左足ＩＫ) e cadeia = pai + avô da ponta (joelho/cotovelo → perna/braço), 40 repetições, ângulo limite 2,0 rad. Se o pai da ponta é joelho/cotovelo, esse elo recebe o limite de dobra padrão do MMD (X de −180° a −0,5°). O painel mostra "IK de … (N elos)" / "tem IK" / "sem IK".
- Alterado: o PMX escreve os ossos IK **por último** com a flag IK (0x003E) e o bloco IK (alvo, repetições, ângulo, elos, limites). **Ossos IK não recebem pesos** (Auto os ignora; ficam fora da lista da ferramenta Pesos). Excluir um osso que é ponta ou elo de um IK exclui também esse IK. Versão 0.14.0 (versionCode 15). `build.yml` não mudou.
- Corrigido: nada novo.
- Testado: **nada em dispositivo e nenhum leitor externo.** Conferência apenas por revisão do código e da ordem dos campos do bloco IK da especificação PMX 2.0. **O código Kotlin da 0.14.0 não foi compilado no ambiente de geração.** As 0.12.0 e 0.13.0 também continuam sem relato de teste do usuário.
- Compatibilidade PMX efetivamente testada: igual à 0.11.0 (cubo sem esqueleto no MMD Studio). **IK nunca foi aberto em nenhum programa.**
- Ainda pendente: o IK **não é resolvido no app** (a pose de teste só gira ossos comuns; para ver o IK funcionar é preciso abrir o PMX no MMD Studio/MMD e mover o osso IK); sem IK de dedos nem do "つま先ＩＫ"; sem editar repetições, ângulo e limites por elo na interface; sem renomear em lote; pincel de pesos; morphs; física; texturas e UV; seleção de arestas; bevel; simetria; quads.
- Próximas prioridades: (1) **confirmar 0.12.0, 0.13.0 e 0.14.0 no POCO X7 Pro**; (2) abrir o PMX com IK no MMD Studio e mover o osso IK; (3) morphs (Fase 6); (4) pincel de pesos; (5) seleção de arestas, bevel, simetria; (6) materiais editáveis e UV.


### Versão 0.15.0 — 2026-11-21
- Adicionado: **morphs de vértice** (início da Fase 6). Novo tipo `Morph` (nome, nome em inglês, grupo, objeto, índices dos vértices e deslocamentos locais) em `ModelProject.morphs`; **esquema de projeto 7** (salvo no projeto; projetos 1 a 6 abrem sem morphs). Botão **"Morphs"** na linha de cima abre um painel flutuante: **Novo morph** (pede o nome) começa a **gravar** no objeto selecionado e liga o modo Editar; você move/gira/escala vértices; **Concluir** guarda só a diferença (vértices que se moveram) e devolve a malha ao estado base, tudo num único passo de Desfazer; **Cancelar** devolve a malha. Lista de morphs (nome · objeto · valor); com um morph selecionado: **0% / 50% / 100%** pré-visualiza a deformação na viewport (fora do modo Editar), **Grupo** alterna Sobrancelha/Olho/Boca/Outro, **Excluir**. Nomes de morph não podem repetir.
- Alterado: **o PMX exporta os morphs** (tipo vértice; deslocamento local → mundo na escala 12, Z invertido; aplicado a todas as cópias do vértice que o exportador duplica por causa das normais) e os lista no quadro de exibição "表情". A mensagem de exportação informa o número de morphs. Extrudir, Inset, Subdividir, Apagar face e Limpar **descartam os morphs do objeto** quando mudam os vértices (índices mudam), com aviso; Mover/Girar/Escala de vértices não descartam. Excluir um objeto exclui seus morphs. O título da tela agora mostra a versão correta (estava "v0.12.0" desde a 0.12.0). Versão 0.15.0 (versionCode 16). `build.yml` não mudou.
- Corrigido: título da tela com versão desatualizada.
- Testado: **nada em dispositivo e nenhum leitor externo.** Revisão de código e de campos do registro de morph da especificação PMX 2.0 (nome, nome inglês, grupo, tipo 1 = vértice, contagem, índice + vec3). **O código Kotlin da 0.15.0 não foi compilado no ambiente de geração.** As 0.12.0, 0.13.0 e 0.14.0 também continuam sem relato de teste do usuário.
- Compatibilidade PMX efetivamente testada: igual à 0.11.0 (cubo sem esqueleto no MMD Studio). **Morphs nunca foram abertos em nenhum programa.**
- Ainda pendente: só **morph de vértice** (sem Group, Bone, Material ou UV); sem controle de intensidade além de 0/50/100% no preview; sem combinar morphs no preview em tempo real além de somar valores; sem renomear morph; sem remapear morphs depois de mudar a malha (são descartados); gravação sem pincel/simetria (útil só em malhas com vértices suficientes: Subdividir ANTES de gravar); morphs faciais de qualidade pedem boa topologia; seleção de arestas; bevel; simetria; quads; pincel de pesos; física; texturas e UV.
- Próximas prioridades: (1) **confirmar 0.12.0 a 0.15.0 no POCO X7 Pro**; (2) abrir o PMX com morph no MMD Studio e acionar o morph; (3) Group Morph; (4) remapear morphs ao mudar a malha; (5) pincel de pesos; (6) seleção de arestas, bevel, simetria; (7) materiais editáveis e UV.


### Versão 0.16.0 — 2026-11-22
- Adicionado: **Group Morph** (morph de grupo, Fase 6 item 5). No painel Morphs: **Novo grupo** (pede o nome) cria um grupo vazio e entra na edição dele; enquanto a edição está ativa, tocar num morph de vértice da lista o **inclui ou retira** do grupo (marcas "✓"/"+" na lista); **Pronto** sai da edição; **Editar grupo** reabre um grupo selecionado. Grupo aparece como "[Grupo] nome · N morph(s)". Os botões 0% / 50% / 100% do grupo pré-visualizam **a soma dos morphs membros** (cada um com taxa 1,0 vezes o valor do grupo). Novos dados `GroupItem` e `Morph.isGroup/group`; **esquema de projeto continua 7** (campos novos opcionais; projetos da 0.15.0 abrem normalmente).
- Alterado: o PMX exporta os morphs de vértice primeiro e depois os de grupo (tipo 0, lista de índice + taxa); membros que não foram exportados são omitidos. Excluir um morph de vértice o retira dos grupos. Um grupo não pode conter outro grupo. Versão 0.16.0 (versionCode 17). `build.yml` não mudou.
- Corrigido: nada novo.
- Testado: **nada em dispositivo e nenhum leitor externo.** Revisão de código e dos campos do registro de morph de grupo da especificação PMX 2.0 (tipo 0: índice do morph + taxa). **O código Kotlin da 0.16.0 não foi compilado no ambiente de geração.** As 0.12.0 a 0.15.0 também continuam sem relato de teste do usuário.
- Compatibilidade PMX efetivamente testada: igual à 0.11.0 (cubo sem esqueleto no MMD Studio). **Morphs (vértice e grupo) nunca foram abertos em nenhum programa.**
- Ainda pendente: taxa fixa 1,0 por membro (sem editar); sem Bone/Material/UV/Flip Morph; sem renomear morph; morphs de vértice são descartados quando a malha muda (sem remapeamento); pincel de pesos; seleção de arestas; bevel; simetria; quads; física; texturas e UV.
- Próximas prioridades: (1) **confirmar 0.12.0 a 0.16.0 no POCO X7 Pro**; (2) abrir o PMX com morphs no MMD Studio e acionar vértice e grupo; (3) remapear morphs ao mudar a malha; (4) Material Morph; (5) pincel de pesos; (6) seleção de arestas, bevel, simetria; (7) materiais editáveis e UV.


### Versão 0.17.0 — 2026-11-22
- Adicionado: **remapeamento de morphs de vértice** (novo `core/MorphRemap.kt`). Extrudir, Inset, Subdividir, Apagar face e Limpar **não descartam mais os morphs do objeto**: cada vértice novo procura o vértice antigo mais próximo (espaço local do objeto). Se coincide com um antigo, copia o deslocamento dele; se fica exatamente no meio de dois ou mais antigos (ponto médio de aresta da Subdivisão), usa a **média** dos deslocamentos (interpolação linear); senão copia o do mais próximo. Vértice sem deslocamento sai da lista; morph que fica sem nenhum vértice é descartado e retirado dos grupos. **Renomear morph** (painel Morphs → \"Renomear\"; recusa nome vazio ou repetido; vale também para grupos).
- Alterado: a mensagem de status informa \"N morph(s) remapeado(s)\" (e quantos foram descartados por ficar sem vértices). A busca por vizinho mais próximo é uma cópia da usada nos pesos (`Weighting.remap` não foi tocada). Versão 0.17.0 (versionCode 18). Esquema de projeto continua 7. `build.yml` não mudou.
- Corrigido: nada novo.
- Testado: **nada em dispositivo.** Espelho do algoritmo em Python comparado com força bruta: 0 divergências em 20 grades com pontos médios de aresta (o ponto médio dá exatamente a média dos dois extremos) e 30 conjuntos aleatórios (até 300 vértices, incluindo pontos fora da caixa dos vértices antigos). **O código Kotlin da 0.17.0 não foi compilado no ambiente de geração** (sem Kotlin/rede). As 0.12.0 a 0.16.0 também continuam sem relato de teste do usuário.
- Compatibilidade PMX efetivamente testada: igual à 0.11.0 (cubo sem esqueleto no MMD Studio). **Morphs (vértice e grupo) nunca foram abertos em nenhum programa.**
- Ainda pendente: o remapeamento não interpola em pontos que não são ponto médio (Inset e Extrudir copiam o vizinho mais próximo); só morph de vértice e de grupo (sem Bone/Material/UV/Flip Morph); taxa fixa 1,0 por membro de grupo; sem editar o nome em inglês do morph; pincel de pesos; seleção de arestas; bevel; simetria; quads; física; texturas e UV.
- Próximas prioridades: (1) **confirmar 0.12.0 a 0.17.0 no POCO X7 Pro** (Subdividir um objeto com morph gravado e conferir que o preview continua certo); (2) abrir o PMX com morphs no MMD Studio e acionar vértice e grupo; (3) Material Morph; (4) pincel de pesos; (5) seleção de arestas, bevel, simetria; (6) materiais editáveis e UV.


### Versão 0.18.0 — 2026-11-22
- Adicionado: **cor do material por objeto**. Botão \"Cor\" na aba Objeto abre uma paleta de 12 opções (Padrão, Branco, Pele, Cinza, Preto, Vermelho, Laranja, Amarelo, Verde, Azul, Roxo, Rosa). Novo campo opcional `SceneObject.color` (RGB 0xRRGGBB; null = padrão). A cor aparece no viewport nos objetos não selecionados (o selecionado continua laranja) e **é gravada na cor difusa do material no PMX**; sem cor definida continua o cinza 0,8 de antes. Entra no Desfazer/Refazer e é salva no projeto (campo opcional; **esquema continua 7**, projetos antigos abrem sem cor).
- Alterado: o objeto sem cor continua azul de pré-visualização no app. Versão 0.18.0 (versionCode 19). `build.yml` não mudou.
- Corrigido: nada novo.
- Testado: **nada em dispositivo.** Revisão de código apenas (JSON, desempacotamento RGB → float 0..1 no PMX e no renderer). **O código Kotlin da 0.18.0 não foi compilado no ambiente de geração.** As 0.12.0 a 0.17.0 também continuam sem relato de teste do usuário.
- Compatibilidade PMX efetivamente testada: igual à 0.11.0. **A cor do material no PMX nunca foi aberta em nenhum programa.**
- Ainda pendente: cor livre (hex/seletor), especular/ambiente/contorno editáveis, texturas e UV, **Material Morph** (agora possível, pois há cor editável), transparência; todo o resto do plano.
- Próximas prioridades: (1) **confirmar 0.12.0 a 0.18.0 no POCO X7 Pro**; (2) abrir o PMX no MMD Studio e conferir a cor; (3) Material Morph; (4) pincel de pesos; (5) seleção de arestas, bevel, simetria; (6) UV e texturas.


### Versão 0.19.0 — 2026-11-22
Atualização dupla (duas entregas em uma): **A) Material Morph (cor)** e **B) controle fino de intensidade e taxa de grupo**.
- Adicionado (A): **morph de material** (Fase 6, item 7), versão de cor. No painel Morphs, o botão \"Cor\" pede um nome e uma cor alvo (paleta de 11 cores) e cria um morph ligado ao objeto selecionado: com 100% a cor do material do objeto vai até a cor alvo; 50% fica no meio. Aparece na lista como \"[Cor] nome · objeto\". Pré-visualização no viewport (desmarque o objeto para ver a cor; o selecionado fica laranja). Pode entrar em morph de grupo como qualquer morph de vértice. Novos campos opcionais `Morph.isMaterial` e `Morph.color`; **esquema continua 7**.
- Adicionado (B): botões **−10% / +10%** no preview de qualquer morph (antes só 0/50/100%). **Taxa por membro de grupo**: com um grupo selecionado (fora da edição) aparecem as linhas \"↳ membro × taxa\"; toque num membro e use \"Taxa −\" / \"Taxa +\" (de 0,25 em 0,25, entre 0 e 2). A taxa vale no preview e é exportada no PMX.
- Alterado: o PMX exporta, nesta ordem, morphs de vértice, morphs de material (tipo 8, **modo soma**: difusa += cor alvo − cor base do material; base = cor do objeto ou o cinza 0,8 padrão; um material por objeto visível) e morphs de grupo. Os morphs de material não são afetados por Extrudir/Inset/Subdividir/Apagar/Limpar (não têm vértices). Excluir o objeto exclui seus morphs de cor. Versão 0.19.0 (versionCode 20). `build.yml` não mudou.
- Corrigido: nada novo.
- Testado: **nada em dispositivo e nenhum leitor externo.** Conferência apenas por revisão do código e da ordem dos campos do registro de morph de material da especificação PMX 2.0 (índice do material, modo, difusa RGBA, especular RGB + intensidade, ambiente RGB, contorno RGBA + tamanho, coeficientes de textura, esfera e toon: 28 floats). **O código Kotlin da 0.19.0 não foi compilado no ambiente de geração.** As 0.12.0 a 0.18.0 também continuam sem relato de teste do usuário.
- Compatibilidade PMX efetivamente testada: igual à 0.11.0. **Morphs de material nunca foram abertos em nenhum programa** (o MMD original costuma mostrar só o que o MMD Studio/MMD suportam de morph de material; confirmar).
- Ainda pendente: morph de material só de cor difusa (sem opacidade, especular, ambiente, contorno, textura); sem Bone/UV/Flip Morph; sem editar o nome em inglês; pincel de pesos; seleção de arestas; bevel; simetria; quads; física; texturas e UV.
- Próximas prioridades: (1) **confirmar 0.12.0 a 0.19.0 no POCO X7 Pro**; (2) abrir o PMX no MMD Studio, acionar morph de vértice, de cor e de grupo; (3) pincel de pesos; (4) seleção de arestas, bevel, simetria; (5) UV e texturas; (6) Bone Morph.


### Versão 0.20.0 — 2026-11-22
- Adicionado: **Duplicar** e **Espelhar X** objeto (aba Objeto, botões novos). Duplicar cria uma cópia do objeto selecionado (nome \"… cópia\", deslocada 0,5 em X; mantém cor, pai, osso e pesos; não copia filhos nem morphs). **Espelhar X** cria uma cópia espelhada no plano YZ do mundo: malha com X invertido **e faces viradas** (para as normais continuarem para fora), posição X e rotações Y/Z invertidas, vínculo rígido trocado para o osso do lado oposto (ids terminados em L/R, ex.: braço esquerdo → direito), cor mantida; **não copia pesos nem morphs** (use Pesos → Auto na cópia). Os dois entram no Desfazer/Refazer e são salvos. Não funcionam no modo Editar.
- Alterado: nada nos dados do projeto (**esquema continua 7**).
- Testado: **nada em dispositivo.** Conferência em Python: espelhar sem virar as faces inverte o sinal do volume (−1,0) e virando as faces volta a +1,0 num cubo. **Código Kotlin não compilado no ambiente de geração.**
- Ainda pendente: espelhar com pai girado/escalado (pode sair errado; o app avisa), espelhar pesos e morphs, espelho em torno de outro plano, espelhar ossos.

### Versão 0.21.0 — 2026-11-22
- Adicionado: **Simetria X no modo Editar** (botão \"Simetria X: sim/não\" na linha da ferramenta Seleção). Ligada, **Mover / Girar / Escala** dos vértices selecionados (ou das faces selecionadas) também agem nos vértices espelhados em X (posição (−x, y, z), precisão de 0,001): Mover em X move o par ao contrário, em Y/Z move igual; Escala usa o centro espelhado; Girar em torno de X gira igual e em torno de Y/Z gira ao contrário, com o centro espelhado. Vértices que já estão na seleção, ou sobre o plano x = 0, não são duplicados. A barra de status informa quantos vértices espelhados foram movidos (ou \"nenhum encontrado\"). Pesos e morphs mantêm os índices.
- Alterado: versão 0.21.0 (versionCode 22). Esquema de projeto continua 7. `build.yml` não mudou.
- Corrigido: nada novo.
- Testado: **nada em dispositivo.** Espelho do algoritmo em Python (busca do par por chave de posição + Mover/Escala/Girar espelhados) em 200 sorteios: o par ficou exatamente simétrico à seleção em todos (0 divergências). **O código Kotlin das 0.20.0 e 0.21.0 não foi compilado no ambiente de geração.** As 0.12.0 a 0.19.0 também continuam sem relato de teste do usuário.
- Compatibilidade PMX efetivamente testada: igual à 0.11.0 (cubo sem esqueleto no MMD Studio).
- Ainda pendente: simetria só em X, só em Mover/Girar/Escala (não em Extrudir, Inset, Subdividir nem pesos); precisa de malha realmente simétrica (vértices sem par não são espelhados); vértices duplicados na mesma posição contam como um só; pincel de pesos; seleção de arestas; bevel; quads; física; texturas e UV; Bone Morph.
- Próximas prioridades: (1) **confirmar 0.12.0 a 0.21.0 no POCO X7 Pro**; (2) abrir o PMX no MMD Studio e acionar morphs; (3) pincel de pesos; (4) seleção de arestas e bevel; (5) UV e texturas; (6) Bone Morph.


### Versão 0.22.0 — 2026-11-22
- Adicionado: **pincel de pesos** (Fase 5, item 5 — weight painting por arrastar). Na ferramenta **Pesos**, fora do modo Editar, com um objeto selecionado: botão **"Pincel: sim/não"**; ligado, **1 dedo arrasta e pinta** o osso escolhido na lista do painel Pesos (a pinça continua dando zoom; para girar a câmera, desligue o pincel). **Pintar/Apagar** alterna entre somar e tirar peso; **Raio** alterna 0,1 / 0,25 / 0,5 / 1,0 (unidades locais do objeto). A intensidade por toque é o **Passo** (10/25/50%) com **queda linear** do centro (100% do passo) até a borda (0). O mapa de cores atualiza durante a pincelada. A pincelada inteira (do dedo descer ao subir) é **um único passo de Desfazer**. Novo `Weighting.brush` e `adjustOne` em `core/Weights.kt` (`adjust` agora usa `adjustOne`, mesma regra de antes); novo `ViewportRenderer.pickPoint` (raio contra o objeto selecionado, devolve o ponto de contato local).
- Alterado: versão 0.22.0 (versionCode 23). Esquema de projeto continua 7. `build.yml` não mudou.
- Corrigido: nada novo.
- Testado: **nada em dispositivo.** Espelho do algoritmo em Python (300 sorteios, 1056 alterações com queda linear, +/−): todo vértice continuou com pesos não negativos somando 1 (0 falhas). **O código Kotlin das 0.20.0 a 0.22.0 não foi compilado no ambiente de geração** (sem Kotlin/rede). As 0.12.0 a 0.19.0 também continuam sem relato de teste do usuário.
- Compatibilidade PMX efetivamente testada: igual à 0.11.0 (cubo sem esqueleto no MMD Studio). O pincel só altera pesos já exportados como antes (BDEF1/2/4).
- Ainda pendente: o pincel só pinta (soma/tira) — sem Suavizar por pincel; vértice sem nenhum outro osso vira 100% do osso pintado (rode **Auto** antes para transições suaves); o pincel só age sem pose de teste ativa e fora do modo Editar; o raio é em unidades locais (objeto escalado muda o tamanho aparente); o ponto de contato é o triângulo mais próximo (não ignora oclusão por outros objetos); pinta vértices, não faces, então malhas pouco subdivididas pintam "em blocos"; sem espelhar pesos; SDEF; salvar/exportar pose; IK não resolvido no app; Bone/UV/Flip Morph; seleção de arestas; bevel; quads; física; texturas e UV.
- Próximas prioridades: (1) **confirmar 0.12.0 a 0.22.0 no POCO X7 Pro** (esqueleto → cilindro subdividido → Pesos → Auto → Pincel → pinte um osso e gire na pose de teste); (2) abrir o PMX no MMD Studio e posar/acionar morphs; (3) espelhar pesos; (4) seleção de arestas e bevel; (5) UV e texturas; (6) Bone Morph.


### Versão 0.23.0 — 2026-11-22
Atualização dupla: **A) Espelhar pesos** e **B) Pincel de suavizar**.
- Adicionado (A): botão **"Espelhar"** (modo Editar) / **"Espelhar pesos"** (fora do Editar) na ferramenta Pesos. O vértice na posição (−x, y, z) recebe os pesos do vértice de origem com os ossos **L ↔ R trocados** (ids terminados em L/R; osso sem par fica igual). Origem: os vértices selecionados (Editar) ou, sem seleção, o lado x > 0. Precisa de malha simétrica em X (precisão 0,001); informa quantos vértices foram espelhados. **Espelhar X (objeto)** agora **copia os pesos** da malha original com ossos trocados (antes não copiava).
- Adicionado (B): o botão do pincel agora alterna **Pintar → Apagar → Suavizar**. Suavizar faz uma passada de média com os vizinhos nos vértices dentro do raio a cada toque (`Weighting.brushSmooth`, reusa `smooth`).
- Alterado: versão 0.23.0 (versionCode 24). Novos `Weighting.mirror`, `swapped` e `brushSmooth`. Esquema de projeto continua 7. `build.yml` não mudou.
- Corrigido: nada novo.
- Testado: **nada em dispositivo.** Sem verificação externa desta vez além da revisão do código (a lógica de pares reaproveita `mirrorPartners` da 0.21.0). **O código Kotlin das 0.20.0 a 0.23.0 não foi compilado no ambiente de geração.** As 0.12.0 a 0.22.0 continuam sem relato de teste do usuário.
- Compatibilidade PMX efetivamente testada: igual à 0.11.0.
- Ainda pendente: suavizar por pincel não depende da intensidade (sempre uma passada); espelhar pesos só em X e por posição; sem espelhar morphs nem ossos; SDEF; salvar/exportar pose; seleção de arestas; bevel; quads; física; texturas e UV; Bone Morph.
- Próximas prioridades: (1) **confirmar 0.12.0 a 0.23.0 no POCO X7 Pro**; (2) abrir o PMX no MMD Studio e posar/acionar morphs; (3) seleção de arestas e bevel; (4) UV e texturas; (5) Bone Morph.


---

## 23. Estado de implementação — Versão 0.23.0 (2026-11-22)

**Estado geral:** v0.11.0 (esqueleto e vínculo rígido) testada e aprovada pelo usuário no POCO X7 Pro. **v0.12.0 (pesos por vértice, pesos automáticos, pose de teste, PMX com BDEF1/2/4) ainda sem relato de teste. v0.13.0 (remapeamento de pesos, renomear osso), v0.14.0 (IK nos ossos e no PMX) e v0.15.0 (morphs de vértice) v0.16.0 (morphs de grupo) e v0.17.0 (remapeamento de morphs, renomear morph) v0.18.0 (cor do material) v0.19.0 (morph de material, intensidade fina, taxa de grupo), v0.20.0 (duplicar e espelhar objeto) v0.21.0 (simetria X) e v0.22.0 (pincel de pesos) e v0.23.0 (espelhar pesos, pincel de suavizar) escritas, ainda não compiladas nem testadas.**

### Implementado (código existente)
- Estrutura Android: `studio.mmd.modelstudio`, minSdk 26, target/compile 34, AGP 8.5.2, Kotlin 1.9.24, Compose BOM 2024.06.00, Gradle 8.9 instalado pelo workflow (sem Gradle Wrapper).
- `core/`: **`MorphRemap`** (remapeia morphs de vértice quando a malha muda), **`Xform`** (matrizes afins: mundo e inversa), **`VertexWeights`/`Weighting`** (pesos por vértice: auto, 100%, +/−, suavizar, zerar), **`Skinning`** (pose de teste), `MeshData` (imutável por convenção), `Vec3`, `Shape`, `Primitives` (cubo, esfera UV, cilindro, plano), `SceneObject`, `ModelProject` (esquema 5), `flattenHierarchy`, `ProjectJson`, `ProjectStore` (arquivo temporário + `.bak`), **`MeshOps`** (região de face coplanar, extrusão, inset, apagar triângulos, limpeza, subdivisão, detecção de sobreposição), **`PmxExporter`** (exportação PMX 2.0 com ossos, vínculo rígido e pesos BDEF1/2/4), `Bone`/`Skeletons` (esqueleto humanoide).
- `render/`: OpenGL ES 2.0, sombreamento plano, grade, eixos, matriz de mundo hierárquica, seleção de objeto por esfera envolvente, overlay de edição (arestas, vértices, vértices selecionados em laranja), **seleção de face por raio contra triângulos (Möller–Trumbore, no espaço local do objeto) e destaque de faces selecionadas**.
- `ui/`: `EditorViewModel` (histórico por instantâneos; ferramentas; hierarquia; edição de vértices e faces) e `EditorScreen`.

### Como usar
- **Criar:** "+ Forma" > Cubo, Esfera, Cilindro ou Plano.
- **Objeto:** Mover/Girar/Escala com botões de eixo e Passo. Aba "Objeto": Renomear, Definir pai, Soltar do pai, Ocultar/Mostrar.
- **Esqueleto:** aba "Objeto" → "Esqueleto" abre o painel. "Humanoide" cria 19 ossos; toque num osso na lista para selecioná-lo (laranja no viewport); X−/X+/Y−/Y+/Z−/Z+ movem o osso; selecione um objeto (viewport ou Hierarquia) e use "Ligar ao osso" para que ele siga o osso no MMD. O botão "PMX" exporta tudo.
- **Pesos:** com o esqueleto criado, toque em **"Pesos"** (linha de ferramentas). Escolha um osso na lista do painel (o objeto selecionado fica colorido: azul 0% → vermelho 100%). **Auto** calcula pesos pela distância aos ossos (objeto inteiro, ou só os vértices selecionados em modo "Editar"). Em "Editar" (Vértice ou Face) selecione vértices e use **100%**, **+Peso/−Peso** (o Passo vale 10/25/50%), **Suavizar** e **Zerar**. Para testar, gire o osso ativo com X−/X+/Y−/Y+/Z−/Z+ no painel (15° por toque; "Zerar pose" volta). Extrudir, Inset, Subdividir, Apagar face e Limpar **remapeiam** os pesos (vértices novos copiam o vizinho mais próximo); depois de subdividir muito, use Suavizar. No painel Esqueleto, "Renomear" muda o nome do osso (PMX e inglês). **IK:** selecione o osso da ponta (ex.: tornozelo) e toque em "Criar IK"; o osso IK novo aparece na lista (mova-o com X/Y/Z); o efeito só se vê no MMD/MMD Studio, não no app. **Morphs:** subdivida a malha antes (precisa de vértices); botão "Morphs" → "Novo morph" → nome → mova vértices em Editar → "Concluir"; saia de Editar e use 50%/100% para ver; Grupo define Olho/Boca etc. Extrudir, Inset, Subdividir, Apagar e Limpar remapeiam os morphs do objeto (vértice novo copia o vizinho; ponto médio = média); confira o preview depois. \"Renomear\" muda o nome do morph. **Grupo:** "Novo grupo" → nome → toque nos morphs para incluí-los (✓) → "Pronto"; 50%/100% no grupo aciona todos os membros.
- **Morph de cor:** painel Morphs → \"Cor\" → nome → escolha a cor alvo; 50%/100% mostram a mudança (desmarque o objeto). **−10%/+10%** ajustam a intensidade. **Taxa do grupo:** selecione o grupo, toque num membro (↳) e use \"Taxa −/+\".\n- **Duplicar / Espelhar X:** aba \"Objeto\" com um objeto selecionado (fora do modo Editar). Espelhar cria a cópia no outro lado (x → −x) com faces viradas; refaça os pesos na cópia.\n- **Simetria X:** em \"Editar\", ferramenta Seleção → \"Simetria X: sim\"; depois Mover/Girar/Escala nos vértices agem também nos vértices espelhados.\n- **Pincel de pesos:** ferramenta Pesos (sem Editar), escolha o osso na lista, \"Pincel: sim\", arraste 1 dedo sobre o objeto; \"Pintar/Apagar/Suavizar\", \"Raio\" e o Passo (10/25/50%) controlam a pincelada; cada pincelada é um passo de Desfazer. Rode Auto antes. Desligue o pincel para girar a câmera.\n- **Espelhar pesos:** ferramenta Pesos → \"Espelhar\" (Editar, com seleção como origem) ou \"Espelhar pesos\" (objeto inteiro, origem x > 0); troca ossos L ↔ R.\n- **Cor:** aba \"Objeto\" → \"Cor\" escolhe a cor do material do objeto selecionado (vai para o PMX; desmarque o objeto para vê-la no viewport).\n- **Editar malha:** selecione o objeto, toque em "Editar". Em "Seleção": Tudo, Nenhum, Inverter, Múltipla e **Vértice/Face**.
- **Modelar faces:** em modo Face, toque numa face (fica laranja). Abra "Modelar": **Extrudir +/−** puxa ou afunda a face pela distância do Passo (para quando faltam 0,02 até outra parte da malha; recusa afundar uma face que vai até a quina e qualquer operação que sobreponha faces); **Inset** cria um anel menor dentro da face; **Apagar face** remove; **Subdividir** quebra em 4 os triângulos selecionados (sem seleção, a malha inteira; vizinhos são ajustados sem rachaduras); **Limpar** remove geometria sobreposta (rodada automaticamente após Extrudir/Inset). Para fazer um rebaixo faça **Inset primeiro** e depois Extrudir − (afundar a face inteira é recusado) ou Extrudir + para uma saliência. Tudo entra no Desfazer/Refazer.

### Ainda NÃO existe (nenhum botão falso foi criado)
Seleção de arestas, bevel, simetria além de Mover/Girar/Escala em X, mesclar/separar, escultura, UV, texturas, material além da cor, pincel de suavizar pesos, espelhar pesos, interpolação de pesos ao remapear, resolução de IK no app, morphs de osso/UV/flip (o de material só tem cor difusa), física, leitura de PMX, importação OBJ/FBX/GLB, texturas/UV no PMX, bloquear/isolar objeto, gizmo/arrastar. A malha é de triângulos (sem quads): em superfícies curvas uma "face" selecionada é um triângulo. Seleção de objeto por esfera envolvente é aproximada.

### Decisões técnicas provisórias (a validar no POCO X7 Pro)
- OpenGL ES 2.0 via `GLSurfaceView` dentro do Compose; Filament/Vulkan seguem em avaliação.
- Projeto interno em JSON versionado (`org.json`); histórico por instantâneos do projeto inteiro.
- "Face" = região de triângulos vizinhos com normais iguais (limite cos ≥ 0,9995). Extrusão mantém os índices dos triângulos selecionados (a seleção continua válida) e acrescenta as paredes no fim; a direção por vértice é a média das normais das faces selecionadas (aproximada em seleções não planas).
- Pesos (0.12.0): até 4 ossos por vértice, guardados por vértice da malha (índices). Desde a 0.13.0, mudanças de topologia remapeiam os pesos pelo vértice antigo mais próximo (`Weighting.remap`). Auto = distância ao segmento osso→filho com peso 1/(d²+0,0025)^1,5 (provisório, a validar no MMD Studio). Pose de teste = skinning linear na CPU, só para conferência, sem salvar.
- A estrutura de polígonos (quads/n-gons) segue em aberto e deve ser decidida antes de loops, bevel e topologia para rosto.
- Sem testes automatizados ainda (a verificação da extrusão foi um script de conferência fora do projeto).

### Compatibilidade PMX efetivamente testada
Cubo sem esqueleto (0.10.0) importado no MMD Studio, visualização correta. Exportador PMX 2.0 (botão "PMX", seção 22 → versões 0.10.0 a 0.12.0) com ossos, vínculo rígido e pesos BDEF1/2/4. Falta abrir no MMD Studio ou no MMD original um modelo com ossos e pesos e posar os ossos.

### Fluxo de uso no celular
1. Apagar o ZIP antigo do repositório e enviar o novo (se ficarem os dois, o `build.yml` usa o de commit mais recente).
2. Aba Actions > `build` > acompanhar (ou Run workflow). O `build.yml` não mudou desde a 0.2.0.
3. Baixar o artifact `MMDModelStudio-apk` e instalar por cima.
