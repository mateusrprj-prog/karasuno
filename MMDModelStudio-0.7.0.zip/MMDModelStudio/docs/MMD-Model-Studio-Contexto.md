# MMD Model Studio --- Documento de Contexto do Projeto

> **Documento-base de visão, requisitos, arquitetura, prioridades e
> continuidade.**
>
> **Regra obrigatória de manutenção:** este arquivo deve ser atualizado
> e entregue novamente em formato `.md` a cada atualização relevante do
> aplicativo. Nenhuma atualização deve ser considerada documentada
> apenas em mensagens de conversa, commits ou arquivos de código.

------------------------------------------------------------------------

## 1. Identidade do projeto

-   **Nome provisório:** MMD Model Studio
-   **Plataforma principal:** Android
-   **Ambiente de desenvolvimento e teste do usuário:** Android, sem
    computador
-   **Categoria:** modelador 3D e editor de personagens especializado em
    MMD/PMX
-   **Formato principal de saída:** PMX
-   **Público-alvo inicial:** pessoas que querem criar personagens MMD,
    inclusive iniciantes sem experiência em modelagem 3D
-   **Projeto relacionado:** MMD Studio, aplicativo separado destinado
    principalmente à animação e utilização dos modelos

O nome é provisório e pode mudar futuramente. A finalidade central não
deve mudar sem uma decisão explícita: criar um aplicativo Android capaz
de produzir personagens MMD completos, editáveis e compatíveis, não
apenas visualizar, converter ou animar modelos existentes.

## 2. Visão e objetivo principal

Desenvolver um aplicativo Android que permita **criar personagens MMD do
zero**, com qualidade e recursos comparáveis aos encontrados em modelos
PMX bem construídos e compartilhados pela comunidade MMD.

O aplicativo deverá oferecer um fluxo completo de criação:

1.  Criar ou iniciar a geometria do personagem.
2.  Modelar corpo, cabeça, rosto, cabelo, roupas, calçados e acessórios.
3.  Organizar a malha, suas partes e seus materiais.
4.  Criar e editar UVs e texturas.
5.  Construir o esqueleto e sua hierarquia.
6.  Configurar IK e ossos auxiliares.
7.  Fazer weight painting e corrigir deformações.
8.  Criar morphs faciais e corporais.
9.  Configurar materiais e recursos específicos do MMD.
10. Configurar física de cabelos, roupas, saias e acessórios.
11. Organizar os controles e quadros de exibição.
12. Validar e exportar um arquivo PMX utilizável no MMD original.

**Não é suficiente** criar uma malha bonita, adicionar um esqueleto
genérico e exportar um GLB. O resultado desejado é um modelo PMX
estruturado corretamente, com os recursos próprios do ecossistema MMD.

O aplicativo deve permitir tanto criação manual quanto assistência
automática. A automação deve acelerar o trabalho, nunca retirar do
usuário a possibilidade de inspecionar, corrigir e configurar os dados
manualmente.

## 3. Contexto importante do usuário

-   O usuário ainda **não tem conhecimento de modelagem 3D**.
-   Aprender modelagem é um objetivo futuro, não uma exigência para
    começar a desenvolver o aplicativo.
-   O aplicativo deverá ser planejado para que uma pessoa iniciante
    consiga aprender gradualmente, com ferramentas claras, explicações
    contextuais, exemplos e ações reversíveis.
-   Não presumir que o usuário conheça termos como vértice, aresta,
    face, topologia, UV, rigging, peso, morph, IK, rigid body ou joint.
-   O usuário trabalha e testa projetos pelo Android. Não se deve
    pressupor acesso a Windows, macOS, Linux desktop, Blender desktop ou
    PMX Editor desktop.
-   O projeto deve ser construído em etapas pequenas, testáveis e
    funcionais.
-   Não apresentar uma interface cheia de botões sem implementação real.
-   Evitar exigir que o usuário modele tudo manualmente desde o primeiro
    dia. Futuramente, incluir primitivas, formas-base, modelos de
    referência, ferramentas guiadas e assistentes de criação.

## 4. O que o aplicativo deve ser --- e o que não deve ser

### Deve ser

-   Um modelador 3D para criação de personagens.
-   Um editor de dados e estruturas específicas de MMD.
-   Um ambiente para rigging, morphs, materiais e física.
-   Uma ferramenta de criação do zero, além de importação e edição de
    modelos existentes.
-   Um aplicativo utilizável em telas sensíveis ao toque.
-   Um projeto que salve dados editáveis, não somente o resultado
    exportado.
-   Um aplicativo que valide os arquivos produzidos e informe problemas
    de forma compreensível.

### Não deve ser

-   Apenas um visualizador PMX.
-   Apenas um conversor GLB/FBX/OBJ para PMX.
-   Apenas um editor de poses ou animações.
-   Apenas uma interface visual que simula ferramentas ainda não
    implementadas.
-   Um aplicativo centrado exclusivamente em escultura digital:
    modelagem poligonal, topologia, rigging, morphs e recursos MMD
    também são essenciais.
-   Uma cópia literal da interface de desktop do Blender ou PMX Editor.
    A experiência deve ser redesenhada para Android.

## 5. Referência de qualidade

A meta de qualidade é permitir a criação de personagens comparáveis, em
estrutura e acabamento técnico, aos bons modelos MMD encontrados na
comunidade:

-   Personagens humanoides estilizados/anime.
-   Rostos com geometria adequada e expressões variadas.
-   Olhos, boca, sobrancelhas e cabelo organizados de maneira editável.
-   Cabelos divididos em mechas ou partes que possam receber ossos e
    física.
-   Roupas e acessórios separados quando isso facilitar edição e
    simulação.
-   Topologia que permita deformações adequadas.
-   Texturas e materiais organizados.
-   Esqueleto completo e coerente.
-   Weight painting corrigível manualmente.
-   Morphs faciais, corporais e de materiais.
-   Física configurável por peça.
-   Exportação PMX validada.

A qualidade visual depende de modelagem, topologia, texturas, materiais
e conhecimento artístico. O aplicativo deve fornecer ferramentas
capazes, mas não prometer que um botão automático produzirá sempre um
personagem profissional.

## 6. Sistemas funcionais previstos

### 6.1. Motor 3D e viewport

É a fundação do aplicativo.

Requisitos: - Renderizar malhas 3D com câmera orbitável. - Gestos de
toque para orbitar, aproximar, afastar e deslocar a câmera. - Selecionar
objetos e componentes da malha. - Modos de visualização: sólido,
material, wireframe e, quando viável, inspeção de normais. - Grade,
eixos, gizmos e referências visuais. - Seleção de objetos por toque e
por lista/hierarquia. - Transformações de mover, girar e escalar. -
Controles adequados para telas pequenas. - Desempenho aceitável em
aparelhos Android de recursos variados. - Possibilidade de ocultar,
bloquear e isolar objetos.

A câmera do viewport não pode ser confundida com a transformação do
personagem. Girar a visualização não deve alterar a orientação real do
modelo.

### 6.2. Modelagem poligonal

Ferramentas necessárias: - Criar primitivas. - Criar objetos e malhas. -
Modo de objeto e modo de edição. - Seleção de vértices, arestas e
faces. - Mover, girar e escalar componentes. - Extrusão. - Inset. -
Bevel. - Subdivisão. - Mesclar e separar geometrias. - Duplicar e
espelhar. - Extrair/separar partes. - Preencher e apagar faces. -
Ajustar normais. - Ferramentas de simetria. - Histórico de
desfazer/refazer. - Operações com seleção múltipla.

As ferramentas devem funcionar de verdade na geometria. A interface deve
explicar o efeito das operações para iniciantes.

### 6.3. Escultura digital

Ferramentas planejadas: - Draw. - Smooth. - Grab. - Inflate. - Pinch. -
Flatten. - Crease. - Máscaras. - Simetria. - Controle de raio e
intensidade. - Níveis de subdivisão, se a arquitetura suportar. -
Conversão ou retopologia para uma malha utilizável em rigging.

A escultura é complementar. Não substitui a necessidade de uma boa malha
deformável.

### 6.4. Organização de objetos e peças

O usuário deve conseguir selecionar e editar partes separadamente.

Estrutura sugerida: - Corpo. - Cabeça. - Olhos. - Boca. - Cabelo por
grupos/mechas. - Roupas. - Sapatos. - Acessórios. - Outros objetos.

Requisitos: - Hierarquia de objetos. - Renomear, agrupar, ocultar e
bloquear. - Isolar uma peça. - Selecionar por lista. - Selecionar partes
na viewport. - Definir relações entre objetos. - Separar e unir objetos
quando apropriado. - Manter nomes e organização ao salvar e exportar.

O reconhecimento automático de partes pode ser adicionado futuramente,
mas não deve ser tratado como infalível. Deve existir sempre uma forma
manual de corrigir a classificação.

### 6.5. Topologia e retopologia

Requisitos: - Exibir wireframe. - Inspecionar densidade e distribuição
de polígonos. - Ferramentas de fluxo de arestas. - Simetria. -
Ferramentas para loops e cortes, conforme viabilidade. - Inspeção de
regiões de articulação: ombros, cotovelos, punhos, quadril, joelhos,
tornozelos e rosto. - Detecção de problemas comuns, como faces
degeneradas, normais inconsistentes e geometria duplicada. - Ferramentas
de retopologia em etapas futuras.

A topologia deve ser tratada como requisito central para deformação,
especialmente em rostos e articulações.

### 6.6. UV e texturas

Requisitos: - Criar e editar coordenadas UV. - Visualizar ilhas UV. -
Desdobrar (unwrap). - Ajustar, mover, girar e escalar ilhas. - Detectar
sobreposição quando possível. - Importar imagens como texturas. - Pintar
texturas em uma etapa futura. - Gerenciar arquivos de imagem do
projeto. - Visualizar materiais com textura. - Preservar caminhos e
referências de textura ao salvar/exportar.

### 6.7. Materiais e aparência MMD

Requisitos: - Criar e editar materiais. - Cor difusa. - Cor especular e
intensidade. - Ambiente/ambient, conforme o formato. - Transparência. -
Texturas. - Sphere Maps e modos compatíveis. - Toon textures. -
Configuração de contorno/edge. - Ordem e atribuição de materiais às
faces. - Pré-visualização aproximada do resultado MMD.

A aparência no viewport próprio deve ser comparada com a interpretação
do MMD original. Não assumir que um material que parece correto no
aplicativo será idêntico no MMD.

### 6.8. Rigging e esqueleto

Requisitos: - Criar ossos manualmente. - Criar hierarquia e
parentagem. - Definir posição, orientação e nome dos ossos. - Criar
estrutura humanoide inicial. - Ossos para coluna, quadril, pescoço e
cabeça. - Braços, antebraços, mãos e dedos. - Pernas, joelhos,
tornozelos e pés. - Ossos auxiliares para cabelo, roupa e acessórios. -
Espelhamento de ossos. - Ferramentas para reorganizar e renomear. -
Testar movimentos no viewport. - Definir propriedades específicas de
ossos PMX. - Criar e configurar IK.

O sistema automático de rigging deve ser assistido: gerar uma proposta,
permitir inspeção e oferecer correção manual. Deve suportar personagens
humanoides primeiro; outros tipos de rig podem vir depois.

### 6.9. Weight Painting

Requisitos: - Visualizar influência dos ossos por cores. - Selecionar o
osso que será pintado. - Pintar, apagar, suavizar e substituir pesos. -
Espelhar pesos. - Normalizar pesos. - Limitar influências conforme as
regras do formato. - Testar deformações em poses. - Inspecionar regiões
problemáticas. - Corrigir manualmente resultados automáticos.

O sistema precisa preservar os pesos corretamente na exportação PMX. Não
basta exibir uma pintura visual sem alterar os dados de influência da
malha.

### 6.10. Morph Editor

O Morph Editor é uma das áreas mais importantes do aplicativo.

Tipos a considerar: - Vertex Morph. - Bone Morph. - UV Morph e variações
suportadas. - Material Morph. - Group Morph. - Flip Morph, conforme
suporte do formato e compatibilidade.

Usos esperados: - Piscar. - Olhos fechados. - Olhos semicerrados. -
Sorriso. - Tristeza. - Raiva. - Surpresa. - Boca aberta e fechada. -
Formatos de boca/fonemas. - Sobrancelhas. - Bochechas e outras
deformações. - Mudanças de materiais. - Combinações de morphs.

Requisitos: - Criar morph a partir da malha base. - Registrar alterações
de vértices ou demais dados pertinentes. - Ajustar intensidade. -
Pré-visualizar. - Renomear e organizar. - Combinar morphs. - Testar
combinações conflitantes. - Definir categorias e quadros de exibição. -
Validar referências e índices antes da exportação.

O aplicativo deve explicar que morphs não são apenas imagens de
expressões: são dados estruturados associados à geometria, ossos, UVs,
materiais ou outros morphs.

### 6.11. Física MMD

Requisitos: - Criar rigid bodies. - Criar joints. - Configurar grupos de
colisão e máscaras. - Ajustar forma, tamanho, posição e rotação. -
Ajustar massa e parâmetros físicos aplicáveis. - Vincular física aos
ossos. - Pré-visualizar simulação. - Configurar cabelos por
mechas/grupos. - Configurar saias por painéis/partes. - Configurar
roupas e acessórios. - Permitir seleção individual de cada peça. -
Copiar configurações entre partes, com possibilidade de ajuste
individual.

A física deve ser configurável por personagem e por peça. Não aplicar
uma configuração global indiscriminadamente a todos os modelos.

### 6.12. Gerenciador PMX

Deve permitir editar e validar os dados próprios do formato: -
Informações e nomes do modelo. - Comentários e créditos. - Vértices e
índices. - Faces. - Materiais. - Texturas. - Ossos. - IK. - Morphs. -
Display Frames. - Rigid Bodies. - Joints. - Propriedades e referências
internas.

Deve haver uma representação interna consistente dos dados, separada da
interface. O formato PMX não deve ser manipulado por alterações
improvisadas espalhadas por diferentes telas.

### 6.13. Importação, exportação e validação

Formatos de entrada desejáveis: - PMX. - PMD, se viável. - OBJ. - FBX. -
GLB/GLTF.

Formato prioritário de saída: - PMX 2.0.

Formato posterior: - PMX 2.1, depois que a base 2.0 estiver testada.

A exportação deve: - Preservar os dados suportados. - Validar índices,
referências e hierarquias. - Verificar materiais e caminhos de
textura. - Verificar ossos e pesos. - Verificar morphs e seus
elementos. - Verificar rigid bodies e joints. - Avisar sobre recursos
não suportados. - Gerar relatório de erros e avisos. - Evitar afirmar
que o arquivo é compatível sem testes reais.

Critério essencial: abrir e testar os arquivos exportados no MMD
original e, quando aplicável, em ferramentas de referência. O
visualizador interno não é prova suficiente de compatibilidade.

------------------------------------------------------------------------

## 7. Experiência para iniciantes e aprendizado futuro

Como o usuário ainda não sabe modelagem, a experiência deve ensinar sem
exigir conhecimento prévio.

Recursos didáticos futuros: - Modo iniciante e modo avançado. -
Explicação curta ao selecionar uma ferramenta. - Dicas contextuais. -
Passo a passo para criar uma cabeça, corpo, cabelo e roupa. -
Demonstração visual de vértices, arestas e faces. - Exemplos de
topologia adequada e inadequada. - Guia de UV. - Guia de rigging
humanoide. - Guia de weight painting. - Guia de criação de morphs. -
Guia de física para cabelo e saia. - Projetos de treinamento. -
Desfazer/refazer confiável. - Avisos que expliquem o problema e como
corrigi-lo.

O usuário poderá aprender modelagem enquanto o aplicativo evolui. Não é
necessário dominar modelagem para iniciar a implementação do motor e das
ferramentas básicas.

## 8. Arquitetura técnica --- proposta inicial, não decisão imutável

A arquitetura deve ser avaliada por protótipos no Android real. Não
escolher tecnologias apenas por parecerem modernas.

Possíveis componentes: - **Interface:** Kotlin + Jetpack Compose. -
**Renderização 3D:** avaliar Filament, OpenGL ES ou Vulkan conforme
compatibilidade, desempenho e necessidades de edição. - **Geometria e
operações de malha:** avaliar C++/NDK para operações intensivas e
estruturas de dados apropriadas. - **Física:** avaliar Bullet ou outra
biblioteca compatível com Android e com os requisitos de simulação. -
**Formato PMX:** implementar ou adaptar um parser/exportador com testes
e documentação do formato. - **Persistência:** formato de projeto
próprio, versionado e recuperável. - **Arquivos:** gerenciar texturas e
recursos locais de forma confiável.

### Princípios de arquitetura

1.  Separar interface, dados do modelo, geometria, renderização, física
    e serialização.
2.  Não fazer da viewport a fonte única dos dados do projeto.
3.  Manter um modelo de dados interno consistente.
4.  Permitir salvar e reabrir projetos sem perda.
5.  Versionar o formato interno de projeto.
6.  Criar testes automatizados para parser, exportador e operações
    críticas.
7.  Projetar operações de geometria para malhas grandes sem bloquear a
    interface.
8.  Considerar memória, bateria, aquecimento e limitações de GPU de
    celulares.
9.  Ter recuperação após falhas e salvamento seguro.
10. Não assumir que todas as bibliotecas desktop funcionam no Android.

### Formato de projeto interno

O projeto deve ter um formato editável próprio, contendo: - Geometria e
objetos. - Hierarquia. - Materiais e referências de texturas. - UVs. -
Esqueleto. - Pesos. - Morphs. - Física. - Configurações do projeto. -
Versão do esquema.

A exportação PMX deve ser uma operação derivada desse projeto interno.
Assim, o usuário poderá continuar editando o personagem sem depender de
reimportar o arquivo exportado.

------------------------------------------------------------------------

## 9. Integração futura com o MMD Studio

O MMD Model Studio e o MMD Studio são projetos distintos, com
responsabilidades diferentes.

### MMD Model Studio

Criação e preparação de personagens: - Modelagem. - Materiais. -
Rigging. - Weight painting. - Morphs. - Física. - Exportação PMX.

### MMD Studio

Utilização dos personagens: - Importação de modelos. - Animação. -
Poses. - Timeline. - Câmeras. - Cenários. - Simulação e ajustes de
física durante a animação.

A integração principal será por arquivos PMX compatíveis. VMD/VPD e
outros formatos podem ser considerados conforme as necessidades do MMD
Studio.

Não acoplar os dois aplicativos de forma que um deixe de funcionar sem o
outro.

------------------------------------------------------------------------

## 10. Plano de desenvolvimento por prioridades

A ordem abaixo é uma proposta de implementação. Cada etapa deve ser
concluída e testada antes de avançar. Não criar todos os painéis de uma
vez.

### Fase 0 --- Pesquisa técnica e prova de viabilidade

1.  Estudar a estrutura do PMX 2.0 e os requisitos de compatibilidade.
2.  Avaliar bibliotecas de renderização no Android.
3.  Criar um protótipo mínimo de viewport.
4.  Testar leitura de uma malha simples.
5.  Testar salvamento e recuperação de projeto.
6.  Confirmar que a arquitetura escolhida funciona no dispositivo
    Android de teste.

**Critério de conclusão:** protótipo Android abre, renderiza, seleciona
e salva uma malha simples.

### Fase 1 --- Fundação do editor

1.  Projeto interno editável.
2.  Viewport 3D.
3.  Câmera e gestos.
4.  Seleção de objetos.
5.  Hierarquia.
6.  Transformações.
7.  Desfazer/refazer.
8.  Salvamento e abertura.

**Critério de conclusão:** usuário cria/abre uma cena, transforma
objetos, organiza a hierarquia e reabre o projeto sem perder dados.

### Fase 2 --- Modelagem básica

1.  Primitivas.
2.  Modo de objeto.
3.  Modo de edição.
4.  Vértices, arestas e faces.
5.  Extrusão.
6.  Inset.
7.  Bevel.
8.  Separar e unir.
9.  Simetria.
10. Normais e inspeção de malha.

**Critério de conclusão:** usuário consegue construir e editar uma malha
simples, sem depender de importação.

### Fase 3 --- Preparação de personagem

1.  Organização de partes.
2.  Ferramentas de escultura iniciais.
3.  Topologia e inspeção.
4.  UV básico.
5.  Materiais.
6.  Texturas.
7.  Ferramentas de referência e proporção.

**Critério de conclusão:** personagem simples composto por partes
organizadas, com material e textura.

### Fase 4 --- Estrutura PMX e exportação inicial

1.  Modelo de dados PMX.
2.  Leitura de arquivo PMX.
3.  Escrita de PMX 2.0.
4.  Materiais e texturas.
5.  Validação estrutural.
6.  Testes no MMD original.

**Critério de conclusão:** exportar e abrir um modelo simples no MMD
original. Recursos não implementados devem ser explicitamente
sinalizados.

### Fase 5 --- Rigging e pesos

1.  Criação manual de ossos.
2.  Hierarquia.
3.  Rig humanoide assistido.
4.  IK.
5.  Weight painting.
6.  Espelhamento e normalização.
7.  Testes de deformação.
8.  Exportação e validação.

**Critério de conclusão:** personagem humanoide simples pode ser posado
e deformado adequadamente, e o rig é preservado no PMX.

### Fase 6 --- Morph Editor

1.  Estrutura de morphs.
2.  Vertex Morph.
3.  Pré-visualização e intensidade.
4.  Morphs faciais.
5.  Group Morph.
6.  Bone Morph.
7.  Material Morph.
8.  UV Morph e demais tipos planejados.
9.  Organização em Display Frames.
10. Testes de compatibilidade.

**Critério de conclusão:** modelo exportado contém morphs funcionais que
podem ser acionados no MMD.

### Fase 7 --- Física MMD

1.  Rigid Bodies.
2.  Joints.
3.  Grupos de colisão.
4.  Vinculação a ossos.
5.  Ferramentas de cabelo.
6.  Ferramentas de saia e roupa.
7.  Simulação.
8.  Validação no MMD.

**Critério de conclusão:** uma peça simples de cabelo ou roupa possui
física configurável e funciona no MMD original.

### Fase 8 --- Recursos avançados e qualidade

1.  Retopologia mais avançada.
2.  Pintura de textura.
3.  Ferramentas avançadas de materiais.
4.  Assistente de criação de personagem.
5.  Detecção e classificação assistida de partes.
6.  Automação de rigging e pesos.
7.  Bibliotecas de presets editáveis.
8.  Otimização de desempenho.
9.  Melhorias de acessibilidade e tutoriais.

### Fase 9 --- Integração e acabamento

1.  Testes com modelos complexos.
2.  Testes com muitos morphs e ossos.
3.  Testes de física.
4.  Compatibilidade com MMD Studio.
5.  Exportação confiável.
6.  Relatórios de validação.
7.  Documentação de uso.
8.  Preparação de versões estáveis.

------------------------------------------------------------------------

## 11. Regras de qualidade e desenvolvimento

-   Não declarar uma função concluída se ela apenas tiver interface
    visual.
-   Não substituir uma implementação funcional por um mockup sem avisar.
-   Não remover recursos existentes sem avaliar impacto e documentar a
    decisão.
-   Corrigir regressões antes de adicionar novas funções.
-   Testar em dispositivo Android real sempre que possível.
-   Priorizar estabilidade e integridade dos projetos.
-   Manter operações de desfazer/refazer para ações destrutivas.
-   Avisar quando uma operação puder alterar muitos vértices ou dados.
-   Não descartar dados desconhecidos de PMX silenciosamente durante
    importação/exportação.
-   Registrar recursos ainda não suportados.
-   Evitar prometer compatibilidade total antes de testar no MMD
    original.
-   Manter nomes, índices e referências consistentes.
-   Fazer backups ou salvamento atômico dos projetos.
-   Preferir ferramentas pequenas e completas a grandes conjuntos de
    controles incompletos.

## 12. Testes obrigatórios

Cada sistema deve ter testes apropriados.

### Geometria

-   Criar e editar malhas.
-   Operações de extrusão, inset, separação e união.
-   Normais e índices.
-   Malhas vazias ou inválidas.

### Projeto interno

-   Salvar e reabrir.
-   Preservar hierarquia, materiais e referências.
-   Recuperar projeto após interrupção.
-   Migrar versões antigas do projeto.

### PMX

-   Importar arquivos de referência.
-   Exportar modelos simples e complexos.
-   Verificar índices e referências.
-   Verificar materiais, ossos, morphs e física.
-   Abrir os arquivos no MMD original.
-   Registrar diferenças de interpretação.

### Rigging e morphs

-   Testar deformações.
-   Testar IK.
-   Testar combinações de morphs.
-   Verificar se morphs não apontam para elementos incorretos.
-   Confirmar que a exportação preserva os dados.

### Física

-   Testar estabilidade da simulação.
-   Verificar grupos de colisão.
-   Verificar joints e vínculos.
-   Comparar comportamento no aplicativo e no MMD.

------------------------------------------------------------------------

## 13. Riscos e limitações conhecidos

1.  Criar um modelador 3D completo é um projeto grande e de longo prazo.
2.  O desenvolvimento no Android impõe limitações de tela, memória, GPU,
    aquecimento e ferramentas de compilação.
3.  PMX possui detalhes específicos que não são preservados por uma
    conversão genérica de GLB/FBX.
4.  Um rig automático pode precisar de correção manual.
5.  Weight painting de qualidade exige inspeção e testes.
6.  Morphs faciais de boa qualidade dependem de geometria apropriada.
7.  Física MMD exige configuração cuidadosa de rigid bodies, joints e
    colisões.
8.  A aparência do viewport pode diferir do MMD original.
9.  Bibliotecas externas precisam ter licença e compatibilidade
    verificadas.
10. O projeto não deve depender de serviços online para operações
    essenciais; funcionamento offline é uma meta importante.

------------------------------------------------------------------------

## 14. Decisões ainda em aberto

Estas decisões devem ser tomadas com protótipos, não por suposição:

-   Motor de renderização definitivo.
-   Linguagem e divisão entre Kotlin e C++.
-   Biblioteca de física.
-   Formato exato do projeto interno.
-   Estratégia de escultura e retopologia.
-   Importação de FBX e GLB.
-   Suporte a PMD.
-   Momento de implementação de PMX 2.1.
-   Estratégia de pintura de texturas.
-   Limites de polígonos e tamanho de projetos.
-   Distribuição de recursos entre versões gratuitas e futuras versões,
    se aplicável.

Não tratar propostas técnicas iniciais como decisões definitivas até
serem validadas no Android.

------------------------------------------------------------------------

## 15. Modelo de interface e usabilidade

A interface deve ser mobile-first.

Estrutura possível: - Viewport central. - Barra inferior contextual. -
Painel de propriedades recolhível. - Hierarquia de objetos acessível. -
Seletor de modos: Modelagem, Escultura, Materiais, Rigging, Pesos,
Morphs e Física. - Ferramentas com alvos de toque adequados. - Gestos
configuráveis. - Opção de desfazer/refazer visível. - Ajuda
contextual. - Controles importantes não devem ficar escondidos em menus
profundos.

Evitar reproduzir uma interface desktop comprimida. A tela deve
priorizar a tarefa atual e apresentar controles específicos do modo
selecionado.

------------------------------------------------------------------------

## 16. Como trabalhar com outras IAs e colaboradores

Este documento é a fonte principal de contexto do projeto.

Qualquer IA ou colaborador que receber este arquivo deve:

1.  Ler o documento inteiro antes de propor alterações.
2.  Respeitar o objetivo de criar modelos PMX completos do zero no
    Android.
3.  Considerar que o usuário é iniciante em modelagem.
4.  Não presumir que existe PC disponível.
5.  Não reduzir o projeto a conversão de modelos prontos.
6.  Não implementar apenas telas decorativas.
7.  Trabalhar de acordo com as prioridades e critérios de conclusão.
8.  Informar claramente o que foi realmente implementado, o que foi
    testado e o que continua pendente.
9.  Atualizar este documento depois de cada atualização relevante.
10. Entregar o arquivo `.md` atualizado junto com os demais arquivos da
    atualização.

Se uma decisão nova contradisser este documento, registrar a mudança na
seção de histórico e explicar o motivo. Não apagar decisões anteriores
importantes sem deixar registro.

------------------------------------------------------------------------

## 17. Regra obrigatória: atualizar e entregar o MD em toda atualização

**Esta regra é permanente e obrigatória.**

A cada atualização do aplicativo, seja pequena ou grande, deve ser
entregue uma nova versão atualizada deste documento Markdown.

A atualização do MD deve incluir, quando aplicável:

-   Nova versão do aplicativo.
-   Data da atualização.
-   Funcionalidades adicionadas.
-   Funcionalidades modificadas.
-   Correções realizadas.
-   Problemas conhecidos.
-   Testes executados e seus resultados.
-   Recursos que ainda são apenas protótipos.
-   Recursos planejados que continuam pendentes.
-   Mudanças de arquitetura.
-   Decisões técnicas tomadas.
-   Próximas prioridades em ordem.
-   Compatibilidade PMX efetivamente testada.

Não basta dizer que o MD foi atualizado: **o arquivo atualizado precisa
ser anexado/entregue ao usuário em cada atualização**.

Não substituir o contexto inteiro por uma lista curta de novidades.
Preservar este documento como base, atualizar as seções relevantes e
manter o histórico.

### Modelo de registro de atualização

Para cada versão, adicionar uma entrada:

``` text
## Histórico de atualizações

### Versão X.Y — AAAA-MM-DD
- Adicionado:
- Alterado:
- Corrigido:
- Testado:
- Ainda pendente:
- Próximas prioridades:
```

Se ainda não houver versão de aplicativo, registrar como
`Documento inicial / pré-desenvolvimento`.

------------------------------------------------------------------------

## 18. Estado inicial do projeto

**Estado:** planejamento / pré-desenvolvimento. *(Atualizado em 2026-11-21: base Android em evolução, versão atual 0.5.0 — ver seção 23.)*

Ainda não há uma implementação funcional confirmada do MMD Model Studio.

### Já definido

-   O aplicativo será voltado à criação de personagens MMD/PMX do zero.
-   A plataforma-alvo é Android.
-   O usuário não dispõe de PC para o fluxo de desenvolvimento e uso.
-   O usuário é iniciante em modelagem e pretende aprender no futuro.
-   O aplicativo deverá ensinar gradualmente e oferecer ferramentas
    acessíveis.
-   O objetivo é alcançar modelos completos, com malha, materiais,
    rigging, pesos, morphs e física.
-   O formato PMX é central.
-   O MMD Studio será um projeto separado que poderá consumir os modelos
    criados.
-   O MD atualizado deve ser entregue a cada atualização do aplicativo.

### Próximas prioridades imediatas

1.  Investigar e validar a renderização 3D no Android.
2.  Definir a estrutura de dados de geometria e objetos.
3.  Criar um protótipo de viewport funcional.
4.  Implementar seleção e transformações.
5.  Implementar salvamento e abertura de um projeto interno.
6.  Só então iniciar as ferramentas de modelagem poligonal.

### Não considerar implementado

Todos os sistemas descritos neste documento são requisitos ou planos,
salvo quando uma atualização futura registrar explicitamente sua
implementação e seus testes.

------------------------------------------------------------------------

## 19. Histórico do documento

### Documento inicial --- 2026-11-20

-   Criado o contexto-base do MMD Model Studio.
-   Definido o objetivo de criar personagens PMX completos do zero no
    Android.
-   Registrado que o usuário ainda é iniciante em modelagem e deverá
    poder aprender gradualmente.
-   Definidos os sistemas previstos, prioridades, critérios de qualidade
    e integração futura com MMD Studio.
-   Estabelecida a regra permanente de entregar o `.md` atualizado em
    toda atualização do aplicativo.
-   Estado do projeto: planejamento / pré-desenvolvimento.


---

## 20. Ambiente obrigatório de desenvolvimento: GitHub, build.yml e POCO X7 Pro

Esta seção é uma restrição operacional do projeto, não uma sugestão.

### Dispositivo e ferramentas

- O usuário utilizará **somente um POCO X7 Pro** para acompanhar, editar, enviar e testar o projeto.
- O fluxo de desenvolvimento deverá utilizar **GitHub** e **GitHub Actions**.
- O workflow de compilação deverá se chamar `build.yml`.
- Não exigir computador ou etapas que dependam de Windows, macOS ou Linux desktop.
- Não orientar o usuário a abrir o projeto no Blender desktop, Android Studio desktop, VS Code desktop ou PMX Editor desktop.
- Toda entrega compilável deverá permitir que o usuário obtenha o APK pelos artifacts do GitHub Actions e teste no POCO X7 Pro.

### Contrato obrigatório do workflow `build.yml`

**O primeiro `build.yml` deve ser entregue fora do ZIP do projeto**, como arquivo separado, para que o usuário consiga adicioná-lo diretamente ao repositório GitHub antes de enviar o ZIP com o código-fonte. Não colocar o único exemplar do workflow dentro do ZIP inicial, pois isso impediria o fluxo de bootstrap esperado.

Depois que o repositório estiver criado, o workflow poderá também ser incluído no código-fonte/ZIP nas atualizações seguintes, mas a primeira entrega precisa conter o arquivo `build.yml` separado e pronto para ser colocado no local correto do repositório (normalmente `.github/workflows/build.yml`).

O workflow deve ser genérico quanto ao nome do arquivo ZIP de entrada.

Regras:
1. **Nunca codificar um nome específico de ZIP** como `app.zip`, `source.zip`, `project.zip`, `MMDModelStudio.zip` ou semelhante.
2. Localizar os arquivos de entrada pela extensão `.zip`, sem diferenciar letras maiúsculas/minúsculas na extensão quando possível.
3. Procurar no diretório de entrada definido pelo próprio workflow/repositório, e não em um nome presumido.
4. Se não encontrar ZIP, encerrar com mensagem clara indicando onde o arquivo deveria ser colocado.
5. Se encontrar mais de um ZIP candidato, não escolher aleatoriamente: informar os arquivos encontrados e solicitar/usar um critério explícito de seleção. Se o workflow oferecer um input para caminho do ZIP, esse input deve aceitar qualquer nome.
6. Extrair o ZIP escolhido para um diretório de trabalho limpo.
7. Detectar a raiz real do projeto extraído, inclusive quando o ZIP contém uma pasta superior com nome arbitrário.
8. Validar a presença dos arquivos necessários à compilação antes de iniciar o Gradle.
9. Compilar e publicar o APK como artifact do workflow.
10. Exibir mensagens de erro úteis, sem ocultar a causa da falha.

O workflow não deve presumir que a pasta interna do ZIP tem um nome fixo. Deve identificar a raiz do projeto pelos arquivos de configuração do Gradle e pela estrutura do projeto Android.

### Entrega e teste

- A primeira entrega deverá fornecer o arquivo `build.yml` separadamente, fora do ZIP inicial, pronto para ser adicionado ao repositório GitHub em `.github/workflows/build.yml`.
- Cada atualização posterior deverá incluir o código-fonte atualizado e manter o workflow `build.yml` funcional; se o workflow for alterado, entregar também a versão atualizada do arquivo separadamente para fácil substituição no GitHub.
- Quando houver APK compilado, publicá-lo como artifact do GitHub Actions.
- Informar o resultado real da compilação: sucesso ou falha.
- Não afirmar que o APK foi testado no POCO X7 Pro se apenas foi compilado.
- Diferenciar claramente: compilado, instalado, iniciado e testado funcionalmente.
- Registrar no MD os testes efetivamente realizados no dispositivo.

---

## 21. Instrução de execução imediata para qualquer IA que receber este MD

**Ao ler este documento, a IA deverá começar a construir a base do aplicativo imediatamente.**

Não deve responder apenas com uma análise do documento, uma lista de sugestões, um novo planejamento ou perguntas sobre qual etapa iniciar. O planejamento principal já está definido aqui.

A primeira tarefa é entregar uma **base real e compilável do MMD Model Studio**, com:
- Estrutura inicial de aplicativo Android.
- Identidade/nome provisório MMD Model Studio.
- Tela principal inicial, organizada para futura viewport 3D.
- Arquitetura inicial separando interface e núcleo do projeto.
- Estrutura preparada para receber o motor 3D e o modelo de dados.
- Salvamento ou estrutura inicial de projeto, se viável nessa primeira base.
- Repositório/arquivos preparados para compilação por GitHub Actions.
- Workflow `build.yml` que aceite ZIP de qualquer nome, conforme o contrato da seção 20.
- Instruções curtas para o usuário enviar o ZIP pelo GitHub e baixar o APK no POCO X7 Pro.

A IA deverá tomar decisões técnicas razoáveis sem bloquear o início por perguntas não essenciais. Se uma escolha importante depender de teste, criar um protótipo pequeno e registrar a decisão como provisória.

### O que significa “fazer a base”

A primeira entrega não precisa conter modelagem avançada, rigging, morphs ou física. Porém, precisa ser um aplicativo Android verdadeiro, com projeto organizado e compilável, e não somente mockups, imagens, telas conceituais ou código ilustrativo.

A IA deve:
1. Examinar o ambiente/repositório fornecido.
2. Criar ou atualizar os arquivos do projeto.
3. Criar o `build.yml`.
4. Garantir que o workflow não dependa do nome do ZIP.
5. Fazer uma revisão dos arquivos e da configuração.
6. Entregar os arquivos atualizados e o MD atualizado.
7. Informar exatamente como executar o workflow pelo GitHub e obter o APK.
8. Registrar o que foi implementado, o que compilou e o que ainda não foi testado.

Se a IA não tiver acesso direto ao repositório ou não puder executar uma ação no GitHub, deverá entregar os arquivos completos necessários e instruções específicas para o usuário aplicá-los pelo celular, sem alegar que fez alterações remotas.

---

## 22. Histórico de atualizações do contexto

### Complemento operacional — 2026-11-20
- Especificado que o desenvolvimento e os testes serão feitos exclusivamente pelo Android, tendo o POCO X7 Pro como dispositivo principal.
- Definido GitHub + GitHub Actions como fluxo de versionamento e compilação.
- Definido `build.yml` como workflow de compilação.
- Tornado obrigatório que o workflow localize ZIPs pela extensão e não por um nome de arquivo fixo.
- Registrada a instrução para qualquer IA que receber o MD iniciar imediatamente a construção de uma base Android real e compilável, em vez de apenas discutir o planejamento.


### Complemento — bootstrap do primeiro workflow (2026-11-20)
- Definido que o primeiro `build.yml` deve ser entregue fora do ZIP inicial, como arquivo separado, para ser adicionado manualmente ao repositório GitHub antes do envio do ZIP com o código-fonte.
- Local esperado no repositório: `.github/workflows/build.yml`.
- Nas atualizações seguintes, se o workflow mudar, entregar também sua versão atualizada separadamente, além de mantê-lo no projeto quando aplicável.


### Versão 0.1.0 — 2026-11-20
- Adicionado: projeto Android real (Kotlin + Jetpack Compose + OpenGL ES 2.0): viewport 3D com grade e eixos, câmera orbital por toque (1 dedo gira, pinça faz zoom), criação de cubo, seleção por toque, exclusão, salvamento e abertura de projeto interno (JSON versionado, esquema 1, salvamento via arquivo temporário + cópia .bak). `build.yml` genérico entregue separado do ZIP.
- Alterado: nada (primeira base).
- Corrigido: nada.
- Testado: **nada ainda em dispositivo.** O código foi escrito e revisado, mas NÃO foi compilado nem instalado no ambiente em que foi gerado (sem rede/Gradle). O YAML do `build.yml` e o XML do manifesto foram validados sintaticamente.
- Ainda pendente: compilar no GitHub Actions, instalar e testar no POCO X7 Pro; todas as fases 1 a 9 do plano (seção 10), exceto o esboço da Fase 0 descrito na seção 23.
- Próximas prioridades: (1) confirmar compilação e execução no POCO X7 Pro; (2) transformações (mover/girar/escalar) e hierarquia; (3) desfazer/refazer; (4) modo de edição de malha.


### Versão 0.2.0 — 2026-11-20
- Adicionado: transformações do objeto selecionado (Mover, Girar, Escala) por botões de eixo com passo ajustável (pequeno/médio/grande); desfazer/refazer (até 100 níveis) para criar, excluir e transformar; lista de objetos na viewport para selecionar por nome; rotação no modelo de dados e no renderizador; esquema de projeto 2 (projetos do esquema 1 abrem com rotação zero).
- Alterado: interface compacta (cabeçalho virou texto sobreposto na viewport; barra inferior com 3 linhas) para sobrar mais área 3D em tela deitada. `build.yml`: quando houver mais de um ZIP, usa o de commit mais recente (critério explícito, registrado no log) e falha se houver empate.
- Corrigido: nada reportado. Risco conhecido do 0.1.0 (ZIPs antigos travarem o workflow) tratado no `build.yml`.
- Testado: v0.1.0 confirmada pelo usuário (print): compilou, instalou, iniciou, renderizou grade, eixos e cubo, e a seleção apareceu na barra de status. Salvar/Abrir, Excluir e gestos de câmera ainda não confirmados. **v0.2.0 não foi compilada nem testada.**
- Ainda pendente: hierarquia real (pai/filho), renomear, mover por arrastar na viewport/gizmo, modo de edição de malha, todo o resto do plano.
- Próximas prioridades: (1) confirmar 0.2.0 no POCO X7 Pro; (2) hierarquia e renomear; (3) modo de edição (vértices/arestas/faces); (4) extrusão e inset.


### Versão 0.2.1 — 2026-11-20
- Adicionado: nada.
- Alterado: nada funcional.
- Corrigido: a 0.2.0 falhou na compilação (GitHub Actions, `compileDebugKotlin`): conflito de assinatura JVM entre o setter automático da propriedade `mode` e a função `setMode` em `EditorViewModel`. Função renomeada para `selectMode`.
- Testado: nenhum teste novo. 0.2.1 ainda não compilada nem testada.
- Ainda pendente: igual à 0.2.0.
- Próximas prioridades: (1) confirmar compilação e uso no POCO X7 Pro; (2) hierarquia e renomear; (3) modo de edição de malha.


### Versão 0.3.0 — 2026-11-20
- Adicionado: hierarquia pai/filho (definir pai por lista, soltar do pai, indentação na lista "Hierarquia"); renomear objeto; ocultar/mostrar objeto; ferramenta "Objeto" na barra de baixo; matrizes de mundo hierárquicas no renderizador (filhos acompanham o pai) e na seleção por toque; esquema de projeto 3 (pai e visibilidade; projetos dos esquemas 1 e 2 abrem normalmente).
- Alterado: excluir um objeto agora exclui também seus filhos (desfazer recupera). Lista de objetos virou "Hierarquia".
- Corrigido: nada novo.
- Testado: v0.2.1 confirmada pelo usuário (print): compilou, instalou e iniciou; Girar aplicou rotação ao cubo; botões Desfazer/Refazer com estados corretos; lista de objetos e modos visíveis. Mover, Escala, Salvar/Abrir, Excluir e gestos de câmera ainda não confirmados explicitamente. **v0.3.0 não foi compilada nem testada.**
- Ainda pendente: ao definir um pai, os valores locais do filho são mantidos (o objeto pode "pular" de lugar; preservar a posição de mundo fica para depois); bloquear e isolar objeto; arrastar na viewport/gizmo; modo de edição de malha.
- Próximas prioridades: (1) confirmar 0.3.0 no POCO X7 Pro; (2) modo de edição de malha (vértices/arestas/faces); (3) extrusão e inset; (4) mover por arrastar na viewport.


### Versão 0.4.0 — 2026-11-20
- Adicionado: novas formas (Esfera, Cilindro, Plano) além do Cubo, escolhidas em "+ Forma"; **modo de edição de malha** (botão "Editar"): mostra arestas e vértices do objeto, seleção de vértices por toque (simples ou múltipla), ferramentas "Seleção" (Tudo, Nenhum, Inverter, Múltipla sim/não) e Mover/Girar/Escala aplicados aos vértices selecionados (eixos locais do objeto; Girar e Escala usam o centro da seleção). Edições de vértice entram no Desfazer/Refazer e são salvas no projeto (as posições já eram gravadas por inteiro, sem mudança de esquema; continua o esquema 3).
- Alterado: botão "+ Cubo" virou "+ Forma". Em modo de edição ficam desativados "+ Forma" e "Excluir". Sair da seleção do objeto sai do modo de edição. Arestas desenhadas = bordas e quinas (diagonais de triangulação entre faces coplanares ficam ocultas). Vértices são desenhados sobre as faces (visíveis mesmo atrás).
- Corrigido: nada novo.
- Testado: v0.3.0 confirmada pelo usuário (print): compilou, instalou e iniciou; hierarquia exibida com Cubo 2 como filho de Cubo 1 (indentação); dois cubos na viewport; rotação aplicada (status "Girar -15°"). Mover, Escala, Objeto (renomear/ocultar), Salvar/Abrir e Excluir ainda não confirmados. **v0.4.0 não foi compilada nem testada.** *(Atualizado na 0.5.0: ver entrada da 0.5.0 — a 0.4.0 foi compilada, instalada e aprovada pelo usuário.)*
- Ainda pendente: malha ainda é de **triângulos** (seleção de aresta e face, extrusão, inset e bevel ainda não existem); seleção de vértice sem considerar oclusão (pega o mais próximo do toque, mesmo atrás); mover vértices por arrastar; simetria; bloquear/isolar objeto; ao definir pai, valores locais são mantidos.
- Próximas prioridades: (1) confirmar 0.4.0 no POCO X7 Pro; (2) seleção de faces e arestas; (3) extrusão e inset; (4) mover por arrastar/gizmo; (5) simetria.


### Versão 0.5.0 — 2026-11-21
- Adicionado: **seleção de faces** no modo de edição (botão Vértice/Face em "Seleção" e em "Modelar"); toque numa face seleciona a região plana inteira (triângulos vizinhos e coplanares, ex.: a face quadrada do cubo) e a destaca em laranja translúcido; "Múltipla", Tudo, Nenhum e Inverter também valem para faces. Nova ferramenta **"Modelar"** (só aparece no modo de edição): **Extrudir +/−** (distância = Passo: 0,05 / 0,1 / 0,25; negativo faz um rebaixo para dentro), **Inset** (encolhe a face criando um anel em volta, com limite automático para não inverter faces pequenas) e **Apagar face** (remove triângulos e vértices sem uso; recusa apagar tudo). Mover/Girar/Escala passam a atuar nos vértices das faces selecionadas. Novo arquivo `core/MeshOps.kt` (operações de malha puras, sem Android).
- Alterado: ao trocar Face → Vértice, a seleção de faces vira seleção dos seus vértices; Vértice → Face limpa a seleção. Sair do modo de edição volta para modo Vértice. Versão do app 0.5.0 (versionCode 6). Esquema de projeto continua 3 (extrusão e inset apenas geram nova lista de posições/índices). `build.yml` não mudou.
- Corrigido: nada novo.
- Testado: **v0.4.0 compilada, instalada e aprovada pelo usuário no POCO X7 Pro** (print: esfera com vértices editados, cilindro, hierarquia, botões Mover/Girar/Escala/Objeto/Editar/Passo). A lógica de extrusão foi conferida fora do app com um espelho em Python: depois de extrudir a face de cima de um cubo (+0,5 e −0,3) a malha continua fechada, sem arestas soltas, e o volume sai correto (1,0 → 1,5 e 0,7). **O código Kotlin da 0.5.0 não foi compilado no ambiente de geração** (sem Kotlin/rede) *(atualizado na 0.6.0: o usuário compilou e instalou no POCO X7 Pro e enviou print e vídeo; ver 0.6.0)*.
- Ainda pendente: a malha continua de **triângulos**; em superfícies curvas (esfera, lado do cilindro) cada "face" é um único triângulo, porque só triângulos exatamente coplanares são agrupados; seleção de arestas; bevel, subdivisão, simetria, mesclar/separar; seleção de face sem checar oclusão além do triângulo mais próximo do raio (usa o mais próximo, correto para faces visíveis); mover por arrastar/gizmo; seleção de vértice ignora oclusão; ao definir pai os valores locais são mantidos; bloquear/isolar objeto; sem testes automatizados ainda.
- Próximas prioridades: (1) confirmar compilação e uso da 0.5.0 no POCO X7 Pro (extrudir, inset e apagar num cubo; salvar e reabrir); (2) seleção de arestas e corte em loop; (3) bevel e simetria; (4) decidir estrutura de polígonos (quads) para a malha; (5) mover por arrastar/gizmo.


### Versão 0.6.0 — 2026-11-21
- Adicionado: **Limpar** (solda vértices na mesma posição, remove triângulos degenerados, duplicados e paredes internas sobrepostas) e **Subdividir** (todos os triângulos da malha em 4, pontos médios compartilhados, sem rachaduras; a seleção de faces acompanha os filhos; limite 60000 triângulos) na ferramenta "Modelar".
- Alterado: Extrudir e Inset passam a rodar a limpeza automaticamente, e a seleção é remapeada. Versão 0.6.0 (versionCode 7). Esquema de projeto continua 3. `build.yml` não mudou.
- Corrigido: **chiado/cintilação (z-fighting) no cubo** visto no vídeo do usuário. Causa provável (hipótese, reproduzida fora do app): extrudir + e depois extrudir − na mesma face deixava dois conjuntos de paredes sobrepostas no mesmo plano. Reproduzido em script Python: extrudir +0,3 e −0,3 dava 28 triângulos; com a limpeza volta aos 12 do cubo original (8 vértices, malha fechada, volume 1,0). Se o chiado continuar no aparelho, a causa é outra e precisa de nova investigação.
- Testado: **v0.5.0 compilada, instalada e iniciada no POCO X7 Pro** (print: esfera com duas extrusões longas visíveis, ou seja, Extrudir funciona; vídeo: cubo com chiado nas faces após várias operações). Inset, Apagar face e Salvar/Abrir com malhas editadas não foram confirmados explicitamente. Verificação da limpeza: só o script Python acima. **O código Kotlin da 0.6.0 não foi compilado no ambiente de geração** *(atualizado na 0.7.0: o usuário compilou e testou no POCO X7 Pro; ver 0.7.0)*.
- Ainda pendente: igual à 0.5.0 (malha de triângulos, sem arestas/bevel/simetria/gizmo etc.). Subdividir não suaviza (só adiciona geometria plana); subdividir afeta a malha inteira, não só a seleção. Limpeza solda vértices coincidentes de propósito separados (não há esse caso hoje).
- Próximas prioridades: (1) confirmar 0.6.0 no POCO X7 Pro (extrudir + e − seguidos não deve mais chiar; Subdividir; Limpar); (2) seleção de arestas e corte em loop; (3) bevel e simetria; (4) decidir quads/polígonos; (5) mover por arrastar/gizmo.


### Versão 0.7.0 — 2026-11-21
- Adicionado: **limite de extrusão**: Extrudir (para dentro ou para fora) agora lança um raio de cada vértice da face e não deixa a face chegar a menos de 0,02 de outra parte da malha; se não houver espaço, a operação é recusada com a mensagem "Sem espaço…". Profundidade da tela de 24 bits.
- Alterado: plano próximo da câmera 0,1 → 0,3 e distante 200 → 100 (mais precisão de profundidade). Versão 0.7.0 (versionCode 8). Esquema de projeto continua 3. `build.yml` não mudou.
- Corrigido: **chiado persistente (z-fighting)** visto nos dois vídeos. Causa identificada pelo vídeo da 0.6.0: o usuário cavou o cubo com Extrudir − várias vezes (passos de 0,1) até passar da espessura de 1,0; o fundo do buraco coincidia com a face de trás do cubo (duas faces no mesmo plano). A limpeza da 0.6.0 só tratava duplicatas exatas, não esse caso. Hipótese secundária: o buffer de profundidade padrão do GLSurfaceView costuma ser de 16 bits.
- Testado (vídeo do usuário, 0.6.0 no POCO X7 Pro): modo Face, Extrudir + e −, Subdividir (88 → 352 → 1408 → … até 10688 triângulos), Desfazer e Refazer funcionam. Não apareceram no vídeo: Inset, Apagar face, Limpar, Salvar/Abrir com malha editada. O chiado ainda aparecia (causa acima). Verificação do limite: script Python (raio do topo do cubo para baixo: 1,0; para cima: nenhum). **O código Kotlin da 0.7.0 não foi compilado nem testado.**
- Ainda pendente: Subdividir afeta a malha inteira e cresce rápido (cada toque ×4; o limite é 60000 triângulos); sem subdivisão só da seleção; sem seleção de arestas, bevel, simetria, quads, gizmo. O limite de extrusão não cobre Mover/Escala de vértices (que ainda podem atravessar partes da malha) nem o Inset.
- Próximas prioridades: (1) confirmar 0.7.0 no POCO X7 Pro (cavar o cubo com Extrudir − deve parar a 0,02 do fundo, sem chiado); (2) testar Inset, Apagar face, Limpar e Salvar/Abrir; (3) subdividir só a seleção; (4) seleção de arestas e corte em loop; (5) bevel, simetria e decisão sobre quads.


---

## 23. Estado de implementação — Versão 0.7.0 (2026-11-21)

**Estado geral:** v0.6.0 compilada, instalada e testada em parte no POCO X7 Pro (vídeo). **v0.7.0 escrita, ainda não compilada nem testada.**

### Implementado (código existente)
- Estrutura Android: `studio.mmd.modelstudio`, minSdk 26, target/compile 34, AGP 8.5.2, Kotlin 1.9.24, Compose BOM 2024.06.00, Gradle 8.9 instalado pelo workflow (sem Gradle Wrapper).
- `core/`: `MeshData` (imutável por convenção), `Vec3`, `Shape`, `Primitives` (cubo, esfera UV, cilindro, plano), `SceneObject`, `ModelProject` (esquema 3), `flattenHierarchy`, `ProjectJson`, `ProjectStore` (arquivo temporário + `.bak`), **`MeshOps`** (região de face coplanar, extrusão, inset, apagar triângulos, limpeza, subdivisão).
- `render/`: OpenGL ES 2.0, sombreamento plano, grade, eixos, matriz de mundo hierárquica, seleção de objeto por esfera envolvente, overlay de edição (arestas, vértices, vértices selecionados em laranja), **seleção de face por raio contra triângulos (Möller–Trumbore, no espaço local do objeto) e destaque de faces selecionadas**.
- `ui/`: `EditorViewModel` (histórico por instantâneos; ferramentas; hierarquia; edição de vértices e faces) e `EditorScreen`.

### Como usar
- **Criar:** "+ Forma" > Cubo, Esfera, Cilindro ou Plano.
- **Objeto:** Mover/Girar/Escala com botões de eixo e Passo. Aba "Objeto": Renomear, Definir pai, Soltar do pai, Ocultar/Mostrar.
- **Editar malha:** selecione o objeto, toque em "Editar". Em "Seleção": Tudo, Nenhum, Inverter, Múltipla e **Vértice/Face**.
- **Modelar faces:** em modo Face, toque numa face (fica laranja). Abra "Modelar": **Extrudir +/−** puxa ou afunda a face pela distância do Passo (para quando faltam 0,02 até outra parte da malha); **Inset** cria um anel menor dentro da face; **Apagar face** remove; **Subdividir** quebra cada triângulo da malha em 4; **Limpar** remove geometria sobreposta (rodada automaticamente após Extrudir/Inset). Depois do Inset, use Extrudir − para fazer um rebaixo ou Extrudir + para uma saliência. Tudo entra no Desfazer/Refazer.

### Ainda NÃO existe (nenhum botão falso foi criado)
Seleção de arestas, bevel, subdivisão, simetria, mesclar/separar, escultura, UV, materiais/texturas, ossos, pesos, morphs, física, leitura/escrita PMX, importação OBJ/FBX/GLB, bloquear/isolar objeto, gizmo/arrastar. A malha é de triângulos (sem quads): em superfícies curvas uma "face" selecionada é um triângulo. Seleção de objeto por esfera envolvente é aproximada.

### Decisões técnicas provisórias (a validar no POCO X7 Pro)
- OpenGL ES 2.0 via `GLSurfaceView` dentro do Compose; Filament/Vulkan seguem em avaliação.
- Projeto interno em JSON versionado (`org.json`); histórico por instantâneos do projeto inteiro.
- "Face" = região de triângulos vizinhos com normais iguais (limite cos ≥ 0,9995). Extrusão mantém os índices dos triângulos selecionados (a seleção continua válida) e acrescenta as paredes no fim; a direção por vértice é a média das normais das faces selecionadas (aproximada em seleções não planas).
- A estrutura de polígonos (quads/n-gons) segue em aberto e deve ser decidida antes de loops, bevel e topologia para rosto.
- Sem testes automatizados ainda (a verificação da extrusão foi um script de conferência fora do projeto).

### Compatibilidade PMX efetivamente testada
Nenhuma. Não há exportador PMX.

### Fluxo de uso no celular
1. Apagar o ZIP antigo do repositório e enviar o novo (se ficarem os dois, o `build.yml` usa o de commit mais recente).
2. Aba Actions > `build` > acompanhar (ou Run workflow). O `build.yml` não mudou desde a 0.2.0.
3. Baixar o artifact `MMDModelStudio-apk` e instalar por cima.
