package studio.mmd.modelstudio.core

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Resultado de uma operação de malha. [selection] = triângulos que devem continuar selecionados. */
class MeshResult(val mesh: MeshData, val selection: Set<Int>, val note: String? = null)

/**
 * Operações de malha puras (sem Android), sobre malha de triângulos.
 * Uma "face" para o usuário = região de triângulos vizinhos e coplanares (ex.: os 2 triângulos de uma face do cubo).
 */
object MeshOps {

    private fun key(a: Int, b: Int): Long = (a.toLong() shl 32) or (b.toLong() and 0xFFFFFFFFL)

    /** Normal unitária do triângulo t (zero se degenerado). */
    fun triNormal(m: MeshData, t: Int): FloatArray {
        val p = m.positions
        val a = m.indices[t * 3] * 3; val b = m.indices[t * 3 + 1] * 3; val c = m.indices[t * 3 + 2] * 3
        val ux = p[b] - p[a]; val uy = p[b + 1] - p[a + 1]; val uz = p[b + 2] - p[a + 2]
        val vx = p[c] - p[a]; val vy = p[c + 1] - p[a + 1]; val vz = p[c + 2] - p[a + 2]
        var nx = uy * vz - uz * vy; var ny = uz * vx - ux * vz; var nz = ux * vy - uy * vx
        val l = sqrt(nx * nx + ny * ny + nz * nz)
        if (l > 0f) { nx /= l; ny /= l; nz /= l }
        return floatArrayOf(nx, ny, nz)
    }

    /** Triângulos conectados por aresta e coplanares ao triângulo [seed] (inclui o próprio). */
    fun faceRegion(m: MeshData, seed: Int): Set<Int> {
        if (seed < 0 || seed >= m.triangleCount) return emptySet()
        val edgeTris = HashMap<Long, MutableList<Int>>()
        for (t in 0 until m.triangleCount) {
            for (e in 0..2) {
                val a = m.indices[t * 3 + e]; val b = m.indices[t * 3 + (e + 1) % 3]
                edgeTris.getOrPut(key(min(a, b), max(a, b))) { ArrayList() }.add(t)
            }
        }
        val n0 = triNormal(m, seed)
        val out = HashSet<Int>()
        val queue = ArrayDeque<Int>()
        out.add(seed); queue.add(seed)
        while (queue.isNotEmpty()) {
            val t = queue.removeFirst()
            for (e in 0..2) {
                val a = m.indices[t * 3 + e]; val b = m.indices[t * 3 + (e + 1) % 3]
                val others = edgeTris[key(min(a, b), max(a, b))] ?: continue
                for (o in others) {
                    if (o in out) continue
                    val n = triNormal(m, o)
                    if (n0[0] * n[0] + n0[1] * n[1] + n0[2] * n[2] >= 0.9995f) { out.add(o); queue.add(o) }
                }
            }
        }
        return out
    }

    /** Vértices usados pelos triângulos dados. */
    fun vertsOfTris(m: MeshData, tris: Set<Int>): Set<Int> {
        val s = HashSet<Int>()
        for (t in tris) if (t in 0 until m.triangleCount) for (e in 0..2) s.add(m.indices[t * 3 + e])
        return s
    }

    /** Arestas orientadas (a→b) de borda da seleção: aquelas cuja oposta (b→a) não pertence a um triângulo selecionado. Valor = triângulo dono. */
    private fun boundaryEdges(m: MeshData, tris: Set<Int>): List<Triple<Int, Int, Int>> {
        val directed = HashSet<Long>()
        for (t in tris) for (e in 0..2) directed.add(key(m.indices[t * 3 + e], m.indices[t * 3 + (e + 1) % 3]))
        val out = ArrayList<Triple<Int, Int, Int>>()
        for (t in tris.sorted()) for (e in 0..2) {
            val a = m.indices[t * 3 + e]; val b = m.indices[t * 3 + (e + 1) % 3]
            if (key(b, a) !in directed) out.add(Triple(a, b, t))
        }
        return out
    }

    /**
     * Extrude as faces selecionadas por [distIn] ao longo da normal (negativo = para dentro).
     * Os triângulos selecionados mantêm o mesmo índice (a seleção continua válida); paredes são acrescentadas no fim.
     */
    fun extrude(m: MeshData, tris: Set<Int>, distIn: Float): MeshResult? {
        val sel = tris.filter { it in 0 until m.triangleCount }.toSet()
        if (sel.isEmpty()) return null
        val verts = vertsOfTris(m, sel).sorted()
        val base = m.vertexCount
        val newIndex = HashMap<Int, Int>()
        verts.forEachIndexed { i, v -> newIndex[v] = base + i }

        // direção por vértice = média (ponderada pela área) das normais dos triângulos selecionados que o usam
        val acc = HashMap<Int, FloatArray>()
        val p = m.positions
        for (t in sel) {
            val a = m.indices[t * 3] * 3; val b = m.indices[t * 3 + 1] * 3; val c = m.indices[t * 3 + 2] * 3
            val ux = p[b] - p[a]; val uy = p[b + 1] - p[a + 1]; val uz = p[b + 2] - p[a + 2]
            val vx = p[c] - p[a]; val vy = p[c + 1] - p[a + 1]; val vz = p[c + 2] - p[a + 2]
            val nx = uy * vz - uz * vy; val ny = uz * vx - ux * vz; val nz = ux * vy - uy * vx
            for (e in 0..2) {
                val v = acc.getOrPut(m.indices[t * 3 + e]) { FloatArray(3) }
                v[0] += nx; v[1] += ny; v[2] += nz
            }
        }

        // limite: a face não pode encostar em outra parte da malha (senão duas faces ficam no mesmo plano e "chiam")
        var allowed = Math.abs(distIn)
        var limited = false
        if (distIn != 0f) {
            val sgn = if (distIn > 0f) 1f else -1f
            for (v in verts) {
                val n = acc[v]!!
                val l = sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2])
                if (l == 0f) continue
                val hit = rayHit(m, sel, v, n[0] / l * sgn, n[1] / l * sgn, n[2] / l * sgn)
                if (hit - MIN_GAP < allowed) { allowed = max(0f, hit - MIN_GAP); limited = true }
            }
        }
        if (limited && allowed < 0.005f) return null
        val dist = if (distIn >= 0f) allowed else -allowed
        val pos = m.positions.copyOf(m.positions.size + verts.size * 3)
        for (v in verts) {
            val n = acc[v]!!
            val l = sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2])
            val k = if (l > 0f) dist / l else 0f
            val o = newIndex[v]!! * 3
            pos[o] = p[v * 3] + n[0] * k
            pos[o + 1] = p[v * 3 + 1] + n[1] * k
            pos[o + 2] = p[v * 3 + 2] + n[2] * k
        }

        val border = boundaryEdges(m, sel)
        val idx = m.indices.copyOf(m.indices.size + border.size * 6)
        // tampa: mesmos triângulos, agora usando os vértices novos
        for (t in sel) for (e in 0..2) idx[t * 3 + e] = newIndex[m.indices[t * 3 + e]]!!
        var k = m.indices.size
        for ((a, b, _) in border) {
            val a2 = newIndex[a]!!; val b2 = newIndex[b]!!
            idx[k++] = a; idx[k++] = b; idx[k++] = b2
            idx[k++] = a; idx[k++] = b2; idx[k++] = a2
        }
        return MeshResult(MeshData(pos, idx), sel, if (limited) "Limitado para não encostar em outra parte da malha." else null)
    }

    private const val MIN_GAP = 0.02f

    /** Distância até o primeiro triângulo (fora da seleção e que não usa o vértice v) atingido pelo raio a partir de v; infinito se nenhum. */
    private fun rayHit(m: MeshData, sel: Set<Int>, v: Int, dx: Float, dy: Float, dz: Float): Float {
        val p = m.positions
        val ox = p[v * 3]; val oy = p[v * 3 + 1]; val oz = p[v * 3 + 2]
        var best = Float.MAX_VALUE
        for (t in 0 until m.triangleCount) {
            if (t in sel) continue
            val ia = m.indices[t * 3]; val ib = m.indices[t * 3 + 1]; val ic = m.indices[t * 3 + 2]
            if (ia == v || ib == v || ic == v) continue
            val a = ia * 3; val b = ib * 3; val c = ic * 3
            val e1x = p[b] - p[a]; val e1y = p[b + 1] - p[a + 1]; val e1z = p[b + 2] - p[a + 2]
            val e2x = p[c] - p[a]; val e2y = p[c + 1] - p[a + 1]; val e2z = p[c + 2] - p[a + 2]
            val hx = dy * e2z - dz * e2y; val hy = dz * e2x - dx * e2z; val hz = dx * e2y - dy * e2x
            val det = e1x * hx + e1y * hy + e1z * hz
            if (det > -1e-9f && det < 1e-9f) continue
            val f = 1f / det
            val sx = ox - p[a]; val sy = oy - p[a + 1]; val sz = oz - p[a + 2]
            val u = f * (sx * hx + sy * hy + sz * hz)
            if (u < -1e-4f || u > 1.0001f) continue
            val qx = sy * e1z - sz * e1y; val qy = sz * e1x - sx * e1z; val qz = sx * e1y - sy * e1x
            val w = f * (dx * qx + dy * qy + dz * qz)
            if (w < -1e-4f || u + w > 1.0001f) continue
            val tt = f * (e2x * qx + e2y * qy + e2z * qz)
            if (tt > 1e-4f && tt < best) best = tt
        }
        return best
    }

    /**
     * Inset: encolhe as faces selecionadas para dentro por [amount] (unidades do objeto), criando um anel de faces em volta.
     * Só os vértices de borda são duplicados e movidos. O deslocamento é limitado para evitar inverter faces pequenas.
     */
    fun inset(m: MeshData, tris: Set<Int>, amount: Float): MeshResult? {
        val sel = tris.filter { it in 0 until m.triangleCount }.toSet()
        if (sel.isEmpty() || amount <= 0f) return null
        val border = boundaryEdges(m, sel)
        if (border.isEmpty()) return null
        val bverts = border.flatMap { listOf(it.first, it.second) }.toSortedSet().toList()
        val base = m.vertexCount
        val newIndex = HashMap<Int, Int>()
        bverts.forEachIndexed { i, v -> newIndex[v] = base + i }

        val p = m.positions
        // direção "para dentro" de cada aresta de borda = normal do triângulo × direção da aresta
        val inward = HashMap<Int, MutableList<FloatArray>>()
        for ((a, b, t) in border) {
            val n = triNormal(m, t)
            val ex = p[b * 3] - p[a * 3]; val ey = p[b * 3 + 1] - p[a * 3 + 1]; val ez = p[b * 3 + 2] - p[a * 3 + 2]
            var dx = n[1] * ez - n[2] * ey; var dy = n[2] * ex - n[0] * ez; var dz = n[0] * ey - n[1] * ex
            val l = sqrt(dx * dx + dy * dy + dz * dz)
            if (l == 0f) continue
            dx /= l; dy /= l; dz /= l
            val d = floatArrayOf(dx, dy, dz)
            inward.getOrPut(a) { ArrayList() }.add(d)
            inward.getOrPut(b) { ArrayList() }.add(d)
        }

        // limite por vértice: 90% da menor distância até o centro de um triângulo selecionado vizinho
        val limit = HashMap<Int, Float>()
        for (t in sel) {
            var cx = 0f; var cy = 0f; var cz = 0f
            for (e in 0..2) { val v = m.indices[t * 3 + e]; cx += p[v * 3]; cy += p[v * 3 + 1]; cz += p[v * 3 + 2] }
            cx /= 3f; cy /= 3f; cz /= 3f
            for (e in 0..2) {
                val v = m.indices[t * 3 + e]
                if (v !in newIndex) continue
                val dx = p[v * 3] - cx; val dy = p[v * 3 + 1] - cy; val dz = p[v * 3 + 2] - cz
                val dist = sqrt(dx * dx + dy * dy + dz * dz) * 0.9f
                limit[v] = min(limit[v] ?: Float.MAX_VALUE, dist)
            }
        }

        var clamped = false
        val pos = m.positions.copyOf(m.positions.size + bverts.size * 3)
        for (v in bverts) {
            val dirs = inward[v] ?: emptyList<FloatArray>()
            var sx = 0f; var sy = 0f; var sz = 0f
            for (d in dirs) { sx += d[0]; sy += d[1]; sz += d[2] }
            val sl = sqrt(sx * sx + sy * sy + sz * sz)
            var ox = 0f; var oy = 0f; var oz = 0f
            if (sl > 1e-6f) {
                sx /= sl; sy /= sl; sz /= sl
                var cosMin = 1f
                for (d in dirs) cosMin = min(cosMin, sx * d[0] + sy * d[1] + sz * d[2])
                var len = amount / max(cosMin, 0.3f)
                val lim = limit[v] ?: len
                if (len > lim) { len = lim; clamped = true }
                ox = sx * len; oy = sy * len; oz = sz * len
            }
            val o = newIndex[v]!! * 3
            pos[o] = p[v * 3] + ox; pos[o + 1] = p[v * 3 + 1] + oy; pos[o + 2] = p[v * 3 + 2] + oz
        }

        val idx = m.indices.copyOf(m.indices.size + border.size * 6)
        for (t in sel) for (e in 0..2) {
            val v = m.indices[t * 3 + e]
            idx[t * 3 + e] = newIndex[v] ?: v
        }
        var k = m.indices.size
        // anel: a face original ficou "por baixo"; o quadrilátero a,b,b',a' tem a mesma orientação das faces
        for ((a, b, _) in border) {
            val a2 = newIndex[a]!!; val b2 = newIndex[b]!!
            idx[k++] = a; idx[k++] = b; idx[k++] = b2
            idx[k++] = a; idx[k++] = b2; idx[k++] = a2
        }
        return MeshResult(MeshData(pos, idx), sel, if (clamped) "Inset limitado para não inverter faces pequenas." else null)
    }

    /** Apaga os triângulos dados e remove vértices que ficaram sem uso. Retorna null se apagaria tudo. */
    fun deleteTris(m: MeshData, tris: Set<Int>): MeshData? {
        val del = tris.filter { it in 0 until m.triangleCount }.toSet()
        if (del.isEmpty() || del.size >= m.triangleCount) return null
        val keep = (0 until m.triangleCount).filter { it !in del }
        val remap = IntArray(m.vertexCount) { -1 }
        var n = 0
        for (t in keep) for (e in 0..2) {
            val v = m.indices[t * 3 + e]
            if (remap[v] < 0) remap[v] = n++
        }
        val pos = FloatArray(n * 3)
        for (v in 0 until m.vertexCount) {
            val r = remap[v]
            if (r >= 0) { pos[r * 3] = m.positions[v * 3]; pos[r * 3 + 1] = m.positions[v * 3 + 1]; pos[r * 3 + 2] = m.positions[v * 3 + 2] }
        }
        val idx = IntArray(keep.size * 3)
        keep.forEachIndexed { i, t -> for (e in 0..2) idx[i * 3 + e] = remap[m.indices[t * 3 + e]] }
        return MeshData(pos, idx)
    }

    private fun normalOf(p: FloatArray, a: Int, b: Int, c: Int): FloatArray {
        val ux = p[b * 3] - p[a * 3]; val uy = p[b * 3 + 1] - p[a * 3 + 1]; val uz = p[b * 3 + 2] - p[a * 3 + 2]
        val vx = p[c * 3] - p[a * 3]; val vy = p[c * 3 + 1] - p[a * 3 + 1]; val vz = p[c * 3 + 2] - p[a * 3 + 2]
        var nx = uy * vz - uz * vy; var ny = uz * vx - ux * vz; var nz = ux * vy - uy * vx
        val l = sqrt(nx * nx + ny * ny + nz * nz)
        if (l > 0f) { nx /= l; ny /= l; nz /= l }
        return floatArrayOf(nx, ny, nz)
    }

    /**
     * Limpeza: solda vértices na mesma posição, remove triângulos degenerados, duplicados e paredes internas
     * sobrepostas (ex.: extrudir + e depois extrudir − deixava faces coincidentes que "chiavam" na tela).
     * A seleção de triângulos é remapeada.
     */
    fun cleanup(m: MeshData, sel: Set<Int>): MeshResult {
        val vc = m.vertexCount
        val tc = m.triangleCount
        // 1) soldar
        val keyMap = HashMap<Triple<Int, Int, Int>, Int>()
        val canon = IntArray(vc)
        val wl = ArrayList<Float>()
        for (v in 0 until vc) {
            val x = m.positions[v * 3]; val y = m.positions[v * 3 + 1]; val z = m.positions[v * 3 + 2]
            val k = Triple(Math.round(x * 1e4f), Math.round(y * 1e4f), Math.round(z * 1e4f))
            val existing = keyMap[k]
            if (existing != null) canon[v] = existing
            else {
                val n = keyMap.size
                keyMap[k] = n
                canon[v] = n
                wl.add(x); wl.add(y); wl.add(z)
            }
        }
        val wp = wl.toFloatArray()
        val idx = IntArray(m.indices.size) { canon[m.indices[it]] }
        val alive = BooleanArray(tc) { true }
        // 2) degenerados
        for (t in 0 until tc) {
            val a = idx[t * 3]; val b = idx[t * 3 + 1]; val c = idx[t * 3 + 2]
            if (a == b || b == c || a == c) alive[t] = false
        }
        // 3) mesmo trio de vértices: opostos se anulam, iguais ficam um só
        fun orient(t: Int): Triple<Int, Int, Int> {
            val a = idx[t * 3]; val b = idx[t * 3 + 1]; val c = idx[t * 3 + 2]
            return if (a < b && a < c) Triple(a, b, c) else if (b < a && b < c) Triple(b, c, a) else Triple(c, a, b)
        }
        val groups = HashMap<Triple<Int, Int, Int>, MutableList<Int>>()
        for (t in 0 until tc) if (alive[t]) {
            val sorted = listOf(idx[t * 3], idx[t * 3 + 1], idx[t * 3 + 2]).sorted()
            groups.getOrPut(Triple(sorted[0], sorted[1], sorted[2])) { ArrayList() }.add(t)
        }
        for ((_, l) in groups) {
            if (l.size < 2) continue
            val ref = orient(l[0])
            val same = l.filter { orient(it) == ref }.toMutableList()
            val opp = l.filter { orient(it) != ref }.toMutableList()
            while (same.isNotEmpty() && opp.isNotEmpty()) {
                alive[same.removeAt(same.size - 1)] = false
                alive[opp.removeAt(opp.size - 1)] = false
            }
            for (i in 1 until same.size) alive[same[i]] = false
            for (i in 1 until opp.size) alive[opp[i]] = false
        }
        // 4) quadriláteros (2 triângulos coplanares) sobrepostos com orientação oposta se anulam
        val nrm = HashMap<Int, FloatArray>()
        fun nOf(t: Int): FloatArray = nrm.getOrPut(t) { normalOf(wp, idx[t * 3], idx[t * 3 + 1], idx[t * 3 + 2]) }
        val edgeTris = HashMap<Long, MutableList<Int>>()
        for (t in 0 until tc) if (alive[t]) for (e in 0..2) {
            val a = idx[t * 3 + e]; val b = idx[t * 3 + (e + 1) % 3]
            edgeTris.getOrPut(key(min(a, b), max(a, b))) { ArrayList() }.add(t)
        }
        val quads = HashMap<List<Int>, MutableList<IntArray>>()
        for ((_, l) in edgeTris) {
            if (l.size != 2) continue
            val a = l[0]; val b = l[1]
            val na = nOf(a); val nb = nOf(b)
            if (na[0] * nb[0] + na[1] * nb[1] + na[2] * nb[2] <= 0.9999f) continue
            val vs = HashSet<Int>()
            for (e in 0..2) { vs.add(idx[a * 3 + e]); vs.add(idx[b * 3 + e]) }
            if (vs.size != 4) continue
            quads.getOrPut(vs.sorted()) { ArrayList() }.add(intArrayOf(a, b))
        }
        for ((_, l) in quads) {
            val used = HashSet<Int>()
            for (i in 0 until l.size) for (j in i + 1 until l.size) {
                val p = l[i]; val q = l[j]
                if (p[0] in used || p[1] in used || q[0] in used || q[1] in used) continue
                if (p[0] == q[0] || p[0] == q[1] || p[1] == q[0] || p[1] == q[1]) continue
                val n1 = nOf(p[0]); val n2 = nOf(q[0])
                if (n1[0] * n2[0] + n1[1] * n2[1] + n1[2] * n2[2] < -0.9999f) {
                    for (x in intArrayOf(p[0], p[1], q[0], q[1])) { alive[x] = false; used.add(x) }
                }
            }
        }
        // 5) compactar
        val triMap = IntArray(tc) { -1 }
        val remap = IntArray(wp.size / 3) { -1 }
        var nv = 0
        var nt = 0
        for (t in 0 until tc) if (alive[t]) {
            triMap[t] = nt++
            for (e in 0..2) { val v = idx[t * 3 + e]; if (remap[v] < 0) remap[v] = nv++ }
        }
        val pos = FloatArray(nv * 3)
        for (v in remap.indices) {
            val r = remap[v]
            if (r >= 0) { pos[r * 3] = wp[v * 3]; pos[r * 3 + 1] = wp[v * 3 + 1]; pos[r * 3 + 2] = wp[v * 3 + 2] }
        }
        val out = IntArray(nt * 3)
        for (t in 0 until tc) if (alive[t]) for (e in 0..2) out[triMap[t] * 3 + e] = remap[idx[t * 3 + e]]
        val newSel = sel.filter { it in 0 until tc && triMap[it] >= 0 }.map { triMap[it] }.toSet()
        return MeshResult(MeshData(pos, out), newSel)
    }

    /** Subdivide TODOS os triângulos em 4 (pontos médios compartilhados, sem rachaduras). Seleção = filhos dos selecionados. */
    fun subdivide(m: MeshData, sel: Set<Int>): MeshResult? {
        if (m.triangleCount == 0 || m.triangleCount * 4 > 60000) return null
        val mids = HashMap<Long, Int>()
        val pl = ArrayList<Float>(m.positions.size * 2)
        for (f in m.positions) pl.add(f)
        var count = m.vertexCount
        fun mid(a: Int, b: Int): Int {
            val k = key(min(a, b), max(a, b))
            val e = mids[k]
            if (e != null) return e
            for (c in 0..2) pl.add((m.positions[a * 3 + c] + m.positions[b * 3 + c]) / 2f)
            mids[k] = count
            return count++
        }
        val out = IntArray(m.triangleCount * 12)
        for (t in 0 until m.triangleCount) {
            val a = m.indices[t * 3]; val b = m.indices[t * 3 + 1]; val c = m.indices[t * 3 + 2]
            val ab = mid(a, b); val bc = mid(b, c); val ca = mid(c, a)
            val o = t * 12
            out[o] = a; out[o + 1] = ab; out[o + 2] = ca
            out[o + 3] = ab; out[o + 4] = b; out[o + 5] = bc
            out[o + 6] = ca; out[o + 7] = bc; out[o + 8] = c
            out[o + 9] = ab; out[o + 10] = bc; out[o + 11] = ca
        }
        val newSel = HashSet<Int>()
        for (t in sel) if (t in 0 until m.triangleCount) for (k in 0..3) newSel.add(t * 4 + k)
        return MeshResult(MeshData(pl.toFloatArray(), out), newSel)
    }
}
