package studio.mmd.modelstudio.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** Malha triangulada: posições (x,y,z) e índices de triângulos. Imutável por convenção: editar = criar nova MeshData. */
class MeshData(val positions: FloatArray, val indices: IntArray) {
    val vertexCount: Int get() = positions.size / 3
    val triangleCount: Int get() = indices.size / 3

    /** Raio da esfera que envolve a malha, a partir da origem local. */
    fun boundingRadius(): Float {
        var r2 = 0f
        for (i in 0 until vertexCount) {
            val x = positions[i * 3]
            val y = positions[i * 3 + 1]
            val z = positions[i * 3 + 2]
            r2 = max(r2, x * x + y * y + z * z)
        }
        return sqrt(r2)
    }
}

data class Vec3(val x: Float, val y: Float, val z: Float)

enum class Shape(val label: String) {
    CUBE("Cubo"), SPHERE("Esfera"), CYLINDER("Cilindro"), PLANE("Plano")
}

object Primitives {
    fun create(shape: Shape): MeshData = when (shape) {
        Shape.CUBE -> cube(1f)
        Shape.SPHERE -> sphere()
        Shape.CYLINDER -> cylinder()
        Shape.PLANE -> plane(2f)
    }

    /** Cubo centrado na origem, com triângulos em sentido anti-horário visto de fora. */
    fun cube(size: Float = 1f): MeshData {
        val h = size / 2f
        val pos = FloatArray(24)
        for (i in 0 until 8) {
            pos[i * 3] = if (i and 1 != 0) h else -h
            pos[i * 3 + 1] = if (i and 2 != 0) h else -h
            pos[i * 3 + 2] = if (i and 4 != 0) h else -h
        }
        val quads = arrayOf(
            intArrayOf(4, 5, 7, 6), // +Z
            intArrayOf(1, 0, 2, 3), // -Z
            intArrayOf(5, 1, 3, 7), // +X
            intArrayOf(0, 4, 6, 2), // -X
            intArrayOf(2, 6, 7, 3), // +Y
            intArrayOf(0, 1, 5, 4)  // -Y
        )
        val idx = IntArray(36)
        var k = 0
        for (q in quads) {
            idx[k++] = q[0]; idx[k++] = q[1]; idx[k++] = q[2]
            idx[k++] = q[0]; idx[k++] = q[2]; idx[k++] = q[3]
        }
        return MeshData(pos, idx)
    }

    /** Plano no eixo XZ, normal para +Y. */
    fun plane(size: Float = 2f): MeshData {
        val h = size / 2f
        val pos = floatArrayOf(-h, 0f, -h, h, 0f, -h, h, 0f, h, -h, 0f, h)
        val idx = intArrayOf(0, 3, 2, 0, 2, 1)
        return MeshData(pos, idx)
    }

    /** Cilindro centrado na origem, eixo Y, com tampas. */
    fun cylinder(radius: Float = 0.5f, height: Float = 1f, segments: Int = 16): MeshData {
        val n = segments
        val h = height / 2f
        val pos = FloatArray((n * 2 + 2) * 3)
        for (i in 0 until n) {
            val a = 2.0 * PI * i / n
            val x = (radius * cos(a)).toFloat()
            val z = (radius * sin(a)).toFloat()
            val b = i * 3
            pos[b] = x; pos[b + 1] = -h; pos[b + 2] = z
            val t = (n + i) * 3
            pos[t] = x; pos[t + 1] = h; pos[t + 2] = z
        }
        val bc = 2 * n
        val tc = 2 * n + 1
        pos[bc * 3 + 1] = -h
        pos[tc * 3 + 1] = h
        val idx = ArrayList<Int>()
        for (i in 0 until n) {
            val j = (i + 1) % n
            val bi = i; val bj = j; val ti = n + i; val tj = n + j
            idx.add(bi); idx.add(tj); idx.add(bj)
            idx.add(bi); idx.add(ti); idx.add(tj)
            idx.add(tc); idx.add(tj); idx.add(ti)
            idx.add(bc); idx.add(bi); idx.add(bj)
        }
        return MeshData(pos, idx.toIntArray())
    }

    /** Esfera UV centrada na origem, polos em Y. */
    fun sphere(radius: Float = 0.5f, rings: Int = 12, segments: Int = 16): MeshData {
        val vc = 2 + (rings - 1) * segments
        val pos = FloatArray(vc * 3)
        pos[1] = radius
        for (r in 1 until rings) {
            val phi = PI * r / rings
            val y = (radius * cos(phi)).toFloat()
            val rr = radius * sin(phi)
            for (i in 0 until segments) {
                val th = 2.0 * PI * i / segments
                val v = (1 + (r - 1) * segments + i) * 3
                pos[v] = (rr * cos(th)).toFloat()
                pos[v + 1] = y
                pos[v + 2] = (rr * sin(th)).toFloat()
            }
        }
        val bottom = vc - 1
        pos[bottom * 3 + 1] = -radius
        fun ring(r: Int, i: Int) = 1 + (r - 1) * segments + (i % segments)
        val idx = ArrayList<Int>()
        for (i in 0 until segments) {
            idx.add(0); idx.add(ring(1, i + 1)); idx.add(ring(1, i))
        }
        for (r in 1 until rings - 1) {
            for (i in 0 until segments) {
                val ti = ring(r, i); val tj = ring(r, i + 1)
                val bi = ring(r + 1, i); val bj = ring(r + 1, i + 1)
                idx.add(bi); idx.add(tj); idx.add(bj)
                idx.add(bi); idx.add(ti); idx.add(tj)
            }
        }
        for (i in 0 until segments) {
            idx.add(bottom); idx.add(ring(rings - 1, i)); idx.add(ring(rings - 1, i + 1))
        }
        return MeshData(pos, idx.toIntArray())
    }
}
