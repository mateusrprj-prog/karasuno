package studio.mmd.modelstudio.render

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLU
import android.opengl.Matrix
import android.os.Handler
import android.os.Looper
import studio.mmd.modelstudio.core.MeshData
import studio.mmd.modelstudio.core.SceneObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Renderizador OpenGL ES 2.0 da viewport. Só lê dados; a fonte da verdade é o ModelProject. */
class ViewportRenderer : GLSurfaceView.Renderer {

    @Volatile var objects: List<SceneObject> = emptyList()
    @Volatile var selectedId: String? = null
    @Volatile var yaw = 35f
    @Volatile var pitch = 25f
    @Volatile var distance = 9f
    var onPick: (String?) -> Unit = {}

    // ---- modo de edição de malha ----
    @Volatile var editObjectId: String? = null
    @Volatile var selectedVerts: Set<Int> = emptySet()
    var onVertexPick: (Int) -> Unit = {}
    @Volatile var faceMode = false
    @Volatile var selectedTris: Set<Int> = emptySet()
    var onFacePick: (Int) -> Unit = {}
    private var triBuf: FloatBuffer? = null
    private var triMesh: MeshData? = null
    private var triRef: Set<Int>? = null
    private var triCount = 0
    private var uPointSize = 0
    private class EdgeCache(val mesh: MeshData, val buf: FloatBuffer, val count: Int)
    private var edgeCache: EdgeCache? = null
    private var pointBuf: FloatBuffer? = null
    private var pointMesh: MeshData? = null
    private var selBuf: FloatBuffer? = null
    private var selMesh: MeshData? = null
    private var selRef: Set<Int>? = null
    private var selCount = 0

    private val mainHandler = Handler(Looper.getMainLooper())

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private var width = 1
    private var height = 1

    private var program = 0
    private var aPos = 0
    private var aNormal = 0
    private var uMvp = 0
    private var uModel = 0
    private var uColor = 0
    private var uLight = 0

    private lateinit var gridBuf: FloatBuffer
    private var gridCount = 0
    private lateinit var axisX: FloatBuffer
    private lateinit var axisZ: FloatBuffer

    private class Cached(val mesh: MeshData, val buf: FloatBuffer, val vertexCount: Int)
    private val cache = HashMap<String, Cached>()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.11f, 0.12f, 0.15f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val vs = compile(GLES20.GL_VERTEX_SHADER, VERTEX)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FRAGMENT)
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vs)
        GLES20.glAttachShader(program, fs)
        GLES20.glLinkProgram(program)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Link: " + GLES20.glGetProgramInfoLog(program))
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aNormal = GLES20.glGetAttribLocation(program, "aNormal")
        uMvp = GLES20.glGetUniformLocation(program, "uMVP")
        uModel = GLES20.glGetUniformLocation(program, "uModel")
        uColor = GLES20.glGetUniformLocation(program, "uColor")
        uLight = GLES20.glGetUniformLocation(program, "uLight")
        uPointSize = GLES20.glGetUniformLocation(program, "uPointSize")
        buildGrid()
        cache.clear()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        width = maxOf(w, 1)
        height = maxOf(h, 1)
        GLES20.glViewport(0, 0, width, height)
        Matrix.perspectiveM(proj, 0, 45f, width.toFloat() / height.toFloat(), 0.3f, 100f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        val yr = yaw * PI.toFloat() / 180f
        val pr = pitch * PI.toFloat() / 180f
        val d = distance
        val ex = d * cos(pr) * sin(yr)
        val ey = d * sin(pr)
        val ez = d * cos(pr) * cos(yr)
        Matrix.setLookAtM(view, 0, ex, ey, ez, 0f, 0.5f, 0f, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        GLES20.glUseProgram(program)

        Matrix.setIdentityM(model, 0)
        drawLines(gridBuf, gridCount, 0.28f, 0.30f, 0.36f)
        drawLines(axisX, 2, 0.85f, 0.25f, 0.25f)
        drawLines(axisZ, 2, 0.25f, 0.45f, 0.90f)

        val sel = selectedId
        val current = objects
        val alive = HashSet<String>()
        val byId = current.associateBy { it.id }
        GLES20.glEnable(GLES20.GL_POLYGON_OFFSET_FILL)
        GLES20.glPolygonOffset(1f, 1f)
        for (o in current) {
            alive.add(o.id)
            if (!o.visible) continue
            val c = cacheFor(o)
            System.arraycopy(worldOf(o, byId, 0), 0, model, 0, 16)
            if (o.id == sel) drawMesh(c, 1.0f, 0.62f, 0.15f) else drawMesh(c, 0.55f, 0.68f, 0.85f)
        }
        GLES20.glDisable(GLES20.GL_POLYGON_OFFSET_FILL)
        val editId = editObjectId
        if (editId != null) {
            val eo = byId[editId]
            if (eo != null) drawEditOverlay(eo, worldOf(eo, byId, 0))
        }
        cache.keys.retainAll(alive)
    }

    private fun drawEditOverlay(o: SceneObject, w: FloatArray) {
        System.arraycopy(w, 0, model, 0, 16)
        val m = o.mesh
        var ec = edgeCache
        if (ec == null || ec.mesh !== m) { ec = buildEdges(m); edgeCache = ec }
        if (faceMode) drawSelectedTris(m)
        drawLines(ec.buf, ec.count, 0.92f, 0.92f, 0.97f)
        if (faceMode) return

        GLES20.glDisable(GLES20.GL_DEPTH_TEST) // vértices visíveis mesmo atrás das faces
        var pb = pointBuf
        if (pb == null || pointMesh !== m) { pb = toBuffer(m.positions); pointBuf = pb; pointMesh = m }
        drawPoints(pb, m.vertexCount, 0.95f, 0.95f, 0.95f, 14f)
        val sv = selectedVerts
        if (sv.isNotEmpty()) {
            if (selRef !== sv || selMesh !== m) {
                val list = ArrayList<Float>()
                for (i in sv) {
                    if (i in 0 until m.vertexCount) {
                        list.add(m.positions[i * 3]); list.add(m.positions[i * 3 + 1]); list.add(m.positions[i * 3 + 2])
                    }
                }
                selBuf = toBuffer(list.toFloatArray())
                selCount = list.size / 3
                selRef = sv
                selMesh = m
            }
            selBuf?.let { drawPoints(it, selCount, 1.0f, 0.62f, 0.15f, 22f) }
        }
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
    }

    /** Faces selecionadas: triângulos laranja translúcidos por cima da malha. */
    private fun drawSelectedTris(m: MeshData) {
        val st = selectedTris
        if (st.isEmpty()) return
        if (triRef !== st || triMesh !== m) {
            val arr = FloatArray(st.size * 9)
            var k = 0
            var n = 0
            for (t in st) {
                if (t < 0 || t >= m.triangleCount) continue
                for (e in 0..2) {
                    val v = m.indices[t * 3 + e] * 3
                    arr[k++] = m.positions[v]; arr[k++] = m.positions[v + 1]; arr[k++] = m.positions[v + 2]
                }
                n++
            }
            triBuf = toBuffer(arr.copyOf(k))
            triCount = n * 3
            triRef = st
            triMesh = m
        }
        val b = triBuf ?: return
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)
        GLES20.glUniform4f(uColor, 1.0f, 0.62f, 0.15f, 0.65f)
        GLES20.glUniform1f(uLight, 0f)
        GLES20.glUniform1f(uPointSize, 1f)
        b.position(0)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 0, b)
        GLES20.glDisableVertexAttribArray(aNormal)
        GLES20.glVertexAttrib3f(aNormal, 0f, 1f, 0f)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, triCount)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glDisableVertexAttribArray(aPos)
    }

    /** Chamado na thread de GL. Raio do toque contra os triângulos do objeto em edição; devolve o triângulo mais próximo ou -1. */
    fun pickFace(px: Float, py: Float) {
        val id = editObjectId
        val snapshot = objects
        val o = snapshot.firstOrNull { it.id == id }
        if (o == null) { mainHandler.post { onFacePick(-1) }; return }
        val w = worldOf(o, snapshot.associateBy { it.id }, 0)
        val inv = FloatArray(16)
        if (!Matrix.invertM(inv, 0, w, 0)) { mainHandler.post { onFacePick(-1) }; return }
        val viewport = intArrayOf(0, 0, width, height)
        val near = FloatArray(4); val far = FloatArray(4)
        val wy = height - py
        GLU.gluUnProject(px, wy, 0f, view, 0, proj, 0, viewport, 0, near, 0)
        GLU.gluUnProject(px, wy, 1f, view, 0, proj, 0, viewport, 0, far, 0)
        if (near[3] == 0f || far[3] == 0f) { mainHandler.post { onFacePick(-1) }; return }
        val nw = floatArrayOf(near[0] / near[3], near[1] / near[3], near[2] / near[3], 1f)
        val fw = floatArrayOf(far[0] / far[3], far[1] / far[3], far[2] / far[3], 1f)
        val nl = FloatArray(4); val fl = FloatArray(4)
        Matrix.multiplyMV(nl, 0, inv, 0, nw, 0)
        Matrix.multiplyMV(fl, 0, inv, 0, fw, 0)
        val ox = nl[0]; val oy = nl[1]; val oz = nl[2]
        val dx = fl[0] - ox; val dy = fl[1] - oy; val dz = fl[2] - oz
        val m = o.mesh
        val p = m.positions
        var bestT = Float.MAX_VALUE
        var best = -1
        for (t in 0 until m.triangleCount) {
            val a = m.indices[t * 3] * 3; val b = m.indices[t * 3 + 1] * 3; val c = m.indices[t * 3 + 2] * 3
            val e1x = p[b] - p[a]; val e1y = p[b + 1] - p[a + 1]; val e1z = p[b + 2] - p[a + 2]
            val e2x = p[c] - p[a]; val e2y = p[c + 1] - p[a + 1]; val e2z = p[c + 2] - p[a + 2]
            // Möller–Trumbore (dupla face)
            val hx = dy * e2z - dz * e2y; val hy = dz * e2x - dx * e2z; val hz = dx * e2y - dy * e2x
            val det = e1x * hx + e1y * hy + e1z * hz
            if (det > -1e-9f && det < 1e-9f) continue
            val f = 1f / det
            val sx = ox - p[a]; val sy = oy - p[a + 1]; val sz = oz - p[a + 2]
            val u = f * (sx * hx + sy * hy + sz * hz)
            if (u < 0f || u > 1f) continue
            val qx = sy * e1z - sz * e1y; val qy = sz * e1x - sx * e1z; val qz = sx * e1y - sy * e1x
            val v = f * (dx * qx + dy * qy + dz * qz)
            if (v < 0f || u + v > 1f) continue
            val tt = f * (e2x * qx + e2y * qy + e2z * qz)
            if (tt >= 0f && tt < bestT) { bestT = tt; best = t }
        }
        mainHandler.post { onFacePick(best) }
    }

    /** Arestas visíveis: de borda ou entre faces não coplanares (esconde diagonais de triangulação). */
    private fun buildEdges(m: MeshData): EdgeCache {
        val firstNormal = HashMap<Long, FloatArray>()
        val counts = HashMap<Long, Int>()
        val drawn = HashSet<Long>()
        val p = m.positions
        for (t in 0 until m.triangleCount) {
            val ia = m.indices[t * 3]; val ib = m.indices[t * 3 + 1]; val ic = m.indices[t * 3 + 2]
            val ux = p[ib * 3] - p[ia * 3]; val uy = p[ib * 3 + 1] - p[ia * 3 + 1]; val uz = p[ib * 3 + 2] - p[ia * 3 + 2]
            val vx = p[ic * 3] - p[ia * 3]; val vy = p[ic * 3 + 1] - p[ia * 3 + 1]; val vz = p[ic * 3 + 2] - p[ia * 3 + 2]
            var nx = uy * vz - uz * vy; var ny = uz * vx - ux * vz; var nz = ux * vy - uy * vx
            val l = sqrt(nx * nx + ny * ny + nz * nz)
            if (l > 0f) { nx /= l; ny /= l; nz /= l }
            val n = floatArrayOf(nx, ny, nz)
            val pairs = arrayOf(intArrayOf(ia, ib), intArrayOf(ib, ic), intArrayOf(ic, ia))
            for (e in pairs) {
                val lo = minOf(e[0], e[1]); val hi = maxOf(e[0], e[1])
                val key = (lo.toLong() shl 32) or hi.toLong()
                counts[key] = (counts[key] ?: 0) + 1
                val f = firstNormal[key]
                if (f == null) firstNormal[key] = n
                else if (f[0] * n[0] + f[1] * n[1] + f[2] * n[2] < 0.9995f) drawn.add(key)
            }
        }
        for ((key, c) in counts) if (c == 1) drawn.add(key)
        val arr = FloatArray(drawn.size * 6)
        var k = 0
        for (key in drawn) {
            val lo = (key shr 32).toInt(); val hi = (key and 0xFFFFFFFFL).toInt()
            arr[k++] = p[lo * 3]; arr[k++] = p[lo * 3 + 1]; arr[k++] = p[lo * 3 + 2]
            arr[k++] = p[hi * 3]; arr[k++] = p[hi * 3 + 1]; arr[k++] = p[hi * 3 + 2]
        }
        return EdgeCache(m, toBuffer(arr), drawn.size * 2)
    }

    /** Chamado na thread de GL. Escolhe o vértice mais próximo do toque (raio de ~60 px) ou -1. */
    fun pickVertex(px: Float, py: Float) {
        val id = editObjectId
        val snapshot = objects
        val o = snapshot.firstOrNull { it.id == id }
        if (o == null) { mainHandler.post { onVertexPick(-1) }; return }
        val w = worldOf(o, snapshot.associateBy { it.id }, 0)
        val inV = FloatArray(4)
        val worldV = FloatArray(4)
        val clip = FloatArray(4)
        var best = -1
        var bestD = 60f * 60f
        val m = o.mesh
        for (i in 0 until m.vertexCount) {
            inV[0] = m.positions[i * 3]; inV[1] = m.positions[i * 3 + 1]; inV[2] = m.positions[i * 3 + 2]; inV[3] = 1f
            Matrix.multiplyMV(worldV, 0, w, 0, inV, 0)
            Matrix.multiplyMV(clip, 0, vp, 0, worldV, 0)
            if (clip[3] <= 0.0001f) continue
            val sx = (clip[0] / clip[3] * 0.5f + 0.5f) * width
            val sy = (1f - (clip[1] / clip[3] * 0.5f + 0.5f)) * height
            val d = (sx - px) * (sx - px) + (sy - py) * (sy - py)
            if (d < bestD) { bestD = d; best = i }
        }
        mainHandler.post { onVertexPick(best) }
    }

    private fun drawPoints(buf: FloatBuffer, count: Int, r: Float, g: Float, b: Float, size: Float) {
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)
        GLES20.glUniform4f(uColor, r, g, b, 1f)
        GLES20.glUniform1f(uLight, 0f)
        GLES20.glUniform1f(uPointSize, size)
        buf.position(0)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 0, buf)
        GLES20.glDisableVertexAttribArray(aNormal)
        GLES20.glVertexAttrib3f(aNormal, 0f, 1f, 0f)
        GLES20.glDrawArrays(GLES20.GL_POINTS, 0, count)
        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glUniform1f(uPointSize, 1f)
    }

    /** Chamado na thread de GL. Seleciona o objeto atingido por um raio a partir do toque. */
    fun pick(px: Float, py: Float) {
        val viewport = intArrayOf(0, 0, width, height)
        val near = FloatArray(4)
        val far = FloatArray(4)
        val wy = height - py
        GLU.gluUnProject(px, wy, 0f, view, 0, proj, 0, viewport, 0, near, 0)
        GLU.gluUnProject(px, wy, 1f, view, 0, proj, 0, viewport, 0, far, 0)
        if (near[3] == 0f || far[3] == 0f) return
        val ox = near[0] / near[3]; val oy = near[1] / near[3]; val oz = near[2] / near[3]
        var dx = far[0] / far[3] - ox; var dy = far[1] / far[3] - oy; var dz = far[2] / far[3] - oz
        val len = sqrt(dx * dx + dy * dy + dz * dz)
        if (len == 0f) return
        dx /= len; dy /= len; dz /= len

        var bestT = Float.MAX_VALUE
        var bestId: String? = null
        val snapshot = objects
        val byId = snapshot.associateBy { it.id }
        for (o in snapshot) {
            if (!o.visible) continue
            val w = worldOf(o, byId, 0)
            val r = o.mesh.boundingRadius() * sqrt(w[0] * w[0] + w[1] * w[1] + w[2] * w[2])
            val cx = ox - w[12]; val cy = oy - w[13]; val cz = oz - w[14]
            val b = cx * dx + cy * dy + cz * dz
            val c = cx * cx + cy * cy + cz * cz - r * r
            val disc = b * b - c
            if (disc < 0f) continue
            val t = -b - sqrt(disc)
            if (t >= 0f && t < bestT) { bestT = t; bestId = o.id }
        }
        mainHandler.post { onPick(bestId) }
    }

    /** Matriz de mundo = matriz do pai * (T * R * S locais). Limite de profundidade protege contra ciclos. */
    private fun worldOf(o: SceneObject, byId: Map<String, SceneObject>, depth: Int): FloatArray {
        val m = FloatArray(16)
        Matrix.setIdentityM(m, 0)
        val p = o.parentId?.let { byId[it] }
        if (p != null && depth < 32) System.arraycopy(worldOf(p, byId, depth + 1), 0, m, 0, 16)
        Matrix.translateM(m, 0, o.position.x, o.position.y, o.position.z)
        Matrix.rotateM(m, 0, o.rotation.y, 0f, 1f, 0f)
        Matrix.rotateM(m, 0, o.rotation.x, 1f, 0f, 0f)
        Matrix.rotateM(m, 0, o.rotation.z, 0f, 0f, 1f)
        Matrix.scaleM(m, 0, o.scale, o.scale, o.scale)
        return m
    }

    // ---------- desenho ----------
    private fun drawLines(buf: FloatBuffer, count: Int, r: Float, g: Float, b: Float) {
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)
        GLES20.glUniform4f(uColor, r, g, b, 1f)
        GLES20.glUniform1f(uLight, 0f)
        GLES20.glUniform1f(uPointSize, 1f)
        buf.position(0)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 0, buf)
        GLES20.glDisableVertexAttribArray(aNormal)
        GLES20.glVertexAttrib3f(aNormal, 0f, 1f, 0f)
        GLES20.glDrawArrays(GLES20.GL_LINES, 0, count)
        GLES20.glDisableVertexAttribArray(aPos)
    }

    private fun drawMesh(c: Cached, r: Float, g: Float, b: Float) {
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)
        GLES20.glUniform4f(uColor, r, g, b, 1f)
        GLES20.glUniform1f(uLight, 1f)
        GLES20.glUniform1f(uPointSize, 1f)
        c.buf.position(0)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 24, c.buf)
        c.buf.position(3)
        GLES20.glEnableVertexAttribArray(aNormal)
        GLES20.glVertexAttribPointer(aNormal, 3, GLES20.GL_FLOAT, false, 24, c.buf)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, c.vertexCount)
        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aNormal)
    }

    private fun cacheFor(o: SceneObject): Cached {
        val existing = cache[o.id]
        if (existing != null && existing.mesh === o.mesh) return existing
        val c = expand(o.mesh)
        cache[o.id] = c
        return c
    }

    /** Expande a malha indexada em triângulos independentes com normal de face (sombreamento plano). */
    private fun expand(m: MeshData): Cached {
        val tris = m.triangleCount
        val arr = FloatArray(tris * 3 * 6)
        var k = 0
        for (t in 0 until tris) {
            val i0 = m.indices[t * 3] * 3
            val i1 = m.indices[t * 3 + 1] * 3
            val i2 = m.indices[t * 3 + 2] * 3
            val p = m.positions
            val ux = p[i1] - p[i0]; val uy = p[i1 + 1] - p[i0 + 1]; val uz = p[i1 + 2] - p[i0 + 2]
            val vx = p[i2] - p[i0]; val vy = p[i2 + 1] - p[i0 + 1]; val vz = p[i2 + 2] - p[i0 + 2]
            var nx = uy * vz - uz * vy
            var ny = uz * vx - ux * vz
            var nz = ux * vy - uy * vx
            val l = sqrt(nx * nx + ny * ny + nz * nz)
            if (l > 0f) { nx /= l; ny /= l; nz /= l }
            for (idx in intArrayOf(i0, i1, i2)) {
                arr[k++] = p[idx]; arr[k++] = p[idx + 1]; arr[k++] = p[idx + 2]
                arr[k++] = nx; arr[k++] = ny; arr[k++] = nz
            }
        }
        return Cached(m, toBuffer(arr), tris * 3)
    }

    private fun buildGrid() {
        val n = 10
        val list = ArrayList<Float>()
        for (i in -n..n) {
            if (i == 0) continue
            list.addAll(listOf(i.toFloat(), 0f, -n.toFloat(), i.toFloat(), 0f, n.toFloat()))
            list.addAll(listOf(-n.toFloat(), 0f, i.toFloat(), n.toFloat(), 0f, i.toFloat()))
        }
        val a = list.toFloatArray()
        gridBuf = toBuffer(a)
        gridCount = a.size / 3
        axisX = toBuffer(floatArrayOf(-n.toFloat(), 0f, 0f, n.toFloat(), 0f, 0f))
        axisZ = toBuffer(floatArrayOf(0f, 0f, -n.toFloat(), 0f, 0f, n.toFloat()))
    }

    private fun toBuffer(a: FloatArray): FloatBuffer {
        val b = ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        b.put(a)
        b.position(0)
        return b
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw RuntimeException("Shader: $log")
        }
        return s
    }

    companion object {
        private const val VERTEX = """
            uniform mat4 uMVP;
            uniform mat4 uModel;
            uniform float uPointSize;
            attribute vec3 aPos;
            attribute vec3 aNormal;
            varying vec3 vN;
            void main() {
                vN = (uModel * vec4(aNormal, 0.0)).xyz;
                gl_Position = uMVP * vec4(aPos, 1.0);
                gl_PointSize = uPointSize;
            }
        """
        private const val FRAGMENT = """
            precision mediump float;
            uniform vec4 uColor;
            uniform float uLight;
            varying vec3 vN;
            void main() {
                float l = 1.0;
                if (uLight > 0.5) {
                    vec3 n = normalize(vN);
                    l = 0.35 + 0.65 * max(dot(n, normalize(vec3(0.4, 0.8, 0.6))), 0.0);
                }
                gl_FragColor = vec4(uColor.rgb * l, uColor.a);
            }
        """
    }
}
