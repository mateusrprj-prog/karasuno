package studio.mmd.modelstudio.core

/** rotation em graus (X, Y, Z). position/rotation/scale são LOCAIS (relativos ao pai, se houver). */
data class SceneObject(
    val id: String,
    val name: String,
    val mesh: MeshData,
    val position: Vec3 = Vec3(0f, 0f, 0f),
    val rotation: Vec3 = Vec3(0f, 0f, 0f),
    val scale: Float = 1f,
    val parentId: String? = null,
    val visible: Boolean = true
)

/** Projeto interno editável. A exportação PMX (futura) será derivada deste modelo. */
data class ModelProject(
    val schemaVersion: Int = CURRENT_SCHEMA,
    val name: String = "Projeto sem título",
    val objects: List<SceneObject> = emptyList()
) {
    companion object {
        /** 1 = posição/escala; 2 = + rotação; 3 = + pai (hierarquia) e visibilidade. Versões antigas abrem normalmente. */
        const val CURRENT_SCHEMA = 3
    }
}

/** Lista em profundidade (pai antes dos filhos) com o nível de cada objeto. Pai ausente conta como raiz. */
fun flattenHierarchy(objects: List<SceneObject>): List<Pair<SceneObject, Int>> {
    val ids = objects.map { it.id }.toSet()
    val children = objects.filter { it.parentId != null && it.parentId in ids }.groupBy { it.parentId }
    val out = ArrayList<Pair<SceneObject, Int>>()
    val seen = HashSet<String>()
    fun visit(o: SceneObject, depth: Int) {
        if (!seen.add(o.id)) return
        out.add(o to depth)
        children[o.id]?.forEach { visit(it, depth + 1) }
    }
    objects.filter { it.parentId == null || it.parentId !in ids }.forEach { visit(it, 0) }
    return out
}
