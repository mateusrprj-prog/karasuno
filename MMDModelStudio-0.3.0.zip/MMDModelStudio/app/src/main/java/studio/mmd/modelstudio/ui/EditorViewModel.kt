package studio.mmd.modelstudio.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import studio.mmd.modelstudio.core.ModelProject
import studio.mmd.modelstudio.core.Primitives
import studio.mmd.modelstudio.core.ProjectStore
import studio.mmd.modelstudio.core.SceneObject
import studio.mmd.modelstudio.core.Vec3
import java.util.Locale
import java.util.UUID

enum class ToolMode(val label: String) { MOVE("Mover"), ROTATE("Girar"), SCALE("Escala"), OBJECT("Objeto") }

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    private val store = ProjectStore(app)
    private var counter = 0

    private val undoStack = ArrayList<ModelProject>()
    private val redoStack = ArrayList<ModelProject>()

    var project by mutableStateOf(ModelProject())
        private set
    var selectedId by mutableStateOf<String?>(null)
        private set
    var status by mutableStateOf("Toque em \"+ Cubo\" para criar um objeto.")
        private set
    var mode by mutableStateOf(ToolMode.MOVE)
        private set
    var stepIndex by mutableStateOf(1)
        private set
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    // quantidades por passo: [pequeno, médio, grande]
    private val moveSteps = floatArrayOf(0.1f, 0.5f, 1.0f)
    private val rotSteps = floatArrayOf(5f, 15f, 45f)
    private val scaleSteps = floatArrayOf(0.05f, 0.1f, 0.25f)

    fun stepLabel(): String = when (mode) {
        ToolMode.MOVE -> fmt(moveSteps[stepIndex])
        ToolMode.ROTATE -> fmt(rotSteps[stepIndex]) + "°"
        ToolMode.SCALE -> fmt(scaleSteps[stepIndex])
        ToolMode.OBJECT -> "-"
    }

    private fun fmt(v: Float): String = String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')

    private fun commit(newProject: ModelProject) {
        undoStack.add(project)
        if (undoStack.size > 100) undoStack.removeAt(0)
        redoStack.clear()
        project = newProject
        refreshFlags()
    }

    private fun refreshFlags() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
        if (selectedId != null && project.objects.none { it.id == selectedId }) selectedId = null
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.add(project)
        project = undoStack.removeAt(undoStack.size - 1)
        refreshFlags()
        status = "Desfeito."
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.add(project)
        project = redoStack.removeAt(redoStack.size - 1)
        refreshFlags()
        status = "Refeito."
    }

    fun selectMode(m: ToolMode) { mode = m }

    fun cycleStep() { stepIndex = (stepIndex + 1) % 3 }

    fun addCube() {
        counter++
        val i = project.objects.size
        val obj = SceneObject(
            id = UUID.randomUUID().toString(),
            name = "Cubo $counter",
            mesh = Primitives.cube(1f),
            position = Vec3((i % 5) * 2.5f - 5f, 0.5f, (i / 5) * 2.5f)
        )
        commit(project.copy(objects = project.objects + obj))
        selectedId = obj.id
        status = "${obj.name} criado."
    }

    fun descendantsOf(id: String): Set<String> {
        val result = HashSet<String>()
        val queue = ArrayDeque<String>()
        queue.add(id)
        while (queue.isNotEmpty()) {
            val cur = queue.removeFirst()
            for (o in project.objects) {
                if (o.parentId == cur && result.add(o.id)) queue.add(o.id)
            }
        }
        return result
    }

    /** Exclui o objeto e todos os seus filhos (desfazer recupera). */
    fun deleteSelected() {
        val id = selectedId
        if (id == null) {
            status = "Nada selecionado."
            return
        }
        val name = project.objects.firstOrNull { it.id == id }?.name ?: "Objeto"
        val gone = descendantsOf(id) + id
        commit(project.copy(objects = project.objects.filter { it.id !in gone }))
        selectedId = null
        status = if (gone.size > 1) "$name e ${gone.size - 1} filho(s) excluídos." else "$name excluído."
    }

    fun rename(id: String, newName: String) {
        val n = newName.trim()
        if (n.isEmpty()) { status = "O nome não pode ficar vazio."; return }
        commit(project.copy(objects = project.objects.map { if (it.id == id) it.copy(name = n) else it }))
        status = "Renomeado para $n."
    }

    /** Define o pai mantendo os valores LOCAIS do filho (ele pode "pular" de lugar). */
    fun setParent(id: String, parentId: String?) {
        if (parentId != null && (parentId == id || parentId in descendantsOf(id))) {
            status = "Não dá para usar o próprio objeto ou um filho dele como pai."
            return
        }
        val obj = project.objects.firstOrNull { it.id == id } ?: return
        if (obj.parentId == parentId) return
        commit(project.copy(objects = project.objects.map { if (it.id == id) it.copy(parentId = parentId) else it }))
        val pn = project.objects.firstOrNull { it.id == parentId }?.name
        status = if (pn == null) "${obj.name} solto na cena." else "${obj.name} agora é filho de $pn."
    }

    fun toggleVisible(id: String) {
        val obj = project.objects.firstOrNull { it.id == id } ?: return
        commit(project.copy(objects = project.objects.map { if (it.id == id) it.copy(visible = !it.visible) else it }))
        status = if (obj.visible) "${obj.name} oculto." else "${obj.name} visível."
    }

    fun select(id: String?) {
        selectedId = id
        status = if (id == null) "Seleção limpa." else
            "Selecionado: ${project.objects.firstOrNull { it.id == id }?.name ?: "?"}"
    }

    /** axis: 0=X, 1=Y, 2=Z (ignorado em Escala). sign: +1 ou -1. */
    fun nudge(axis: Int, sign: Int) {
        val id = selectedId
        val obj = project.objects.firstOrNull { it.id == id }
        if (obj == null) {
            status = "Selecione um objeto primeiro."
            return
        }
        val updated = when (mode) {
            ToolMode.MOVE -> obj.copy(position = add(obj.position, axis, sign * moveSteps[stepIndex]))
            ToolMode.ROTATE -> obj.copy(rotation = add(obj.rotation, axis, sign * rotSteps[stepIndex]))
            ToolMode.SCALE -> obj.copy(scale = (obj.scale + sign * scaleSteps[stepIndex]).coerceIn(0.1f, 20f))
            ToolMode.OBJECT -> { status = "Escolha Mover, Girar ou Escala."; return }
        }
        commit(project.copy(objects = project.objects.map { if (it.id == obj.id) updated else it }))
        status = "${obj.name}: ${mode.label} ${if (sign > 0) "+" else "-"}${stepLabel()}"
    }

    private fun add(v: Vec3, axis: Int, d: Float): Vec3 = when (axis) {
        0 -> v.copy(x = v.x + d)
        1 -> v.copy(y = v.y + d)
        else -> v.copy(z = v.z + d)
    }

    fun save() {
        val snapshot = project
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { store.save(snapshot) } }
            status = result.fold(
                onSuccess = { "Projeto salvo (${snapshot.objects.size} objetos)." },
                onFailure = { "Erro ao salvar: ${it.message}" }
            )
        }
    }

    fun load() {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { store.load() } }
            result.fold(
                onSuccess = { loaded ->
                    if (loaded == null) {
                        status = "Nenhum projeto salvo ainda."
                    } else {
                        undoStack.clear()
                        redoStack.clear()
                        project = loaded
                        selectedId = null
                        counter = loaded.objects.size
                        refreshFlags()
                        status = "Projeto aberto (${loaded.objects.size} objetos)."
                    }
                },
                onFailure = { status = "Erro ao abrir: ${it.message}" }
            )
        }
    }
}
