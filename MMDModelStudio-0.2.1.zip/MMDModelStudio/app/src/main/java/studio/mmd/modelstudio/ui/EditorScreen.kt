package studio.mmd.modelstudio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import studio.mmd.modelstudio.render.ViewportView

@Composable
private fun RowScope.Btn(text: String, primary: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val mod = Modifier.weight(1f).height(38.dp)
    val pad = PaddingValues(2.dp)
    if (primary) {
        Button(onClick = onClick, modifier = mod, enabled = enabled, contentPadding = pad) {
            Text(text, fontSize = 12.sp, maxLines = 1)
        }
    } else {
        OutlinedButton(onClick = onClick, modifier = mod, enabled = enabled, contentPadding = pad) {
            Text(text, fontSize = 12.sp, maxLines = 1)
        }
    }
}

@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val viewport = remember { ViewportView(context) }
    viewport.onPick = { id -> vm.select(id) }

    DisposableEffect(lifecycleOwner, viewport) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> viewport.onResume()
                Lifecycle.Event.ON_PAUSE -> viewport.onPause()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Scaffold(
        bottomBar = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1B1D24))
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Linha 1: objetos, histórico e arquivo
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Btn("+ Cubo", primary = true) { vm.addCube() }
                    Btn("Excluir") { vm.deleteSelected() }
                    Btn("Desfazer", enabled = vm.canUndo) { vm.undo() }
                    Btn("Refazer", enabled = vm.canRedo) { vm.redo() }
                    Btn("Salvar") { vm.save() }
                    Btn("Abrir") { vm.load() }
                }
                // Linha 2: modo de transformação e passo
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (m in ToolMode.values()) {
                        Btn(m.label, primary = vm.mode == m) { vm.selectMode(m) }
                    }
                    Btn("Passo: ${vm.stepLabel()}") { vm.cycleStep() }
                }
                // Linha 3: eixos (ou +/- em Escala)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (vm.mode == ToolMode.SCALE) {
                        Btn("−  Menor") { vm.nudge(0, -1) }
                        Btn("+  Maior") { vm.nudge(0, 1) }
                    } else {
                        val names = arrayOf("X", "Y", "Z")
                        for (a in 0..2) {
                            Btn("${names[a]}−") { vm.nudge(a, -1) }
                            Btn("${names[a]}+") { vm.nudge(a, 1) }
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            AndroidView(
                factory = { viewport },
                update = { it.setScene(vm.project.objects, vm.selectedId) },
                modifier = Modifier.fillMaxSize()
            )
            Column(Modifier.align(Alignment.TopStart).padding(10.dp)) {
                Text("MMD Model Studio  v0.2.1", color = Color.White, fontSize = 14.sp)
                Text(
                    text = "${vm.project.objects.size} objeto(s)  |  ${vm.status}",
                    color = Color(0xFFD0D4E0),
                    fontSize = 12.sp
                )
            }
            // Lista de objetos (seleção por lista)
            Column(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .width(130.dp)
                    .heightIn(max = 130.dp)
                    .background(Color(0x99000000))
                    .verticalScroll(rememberScrollState())
            ) {
                Text("Objetos", color = Color(0xFF8A90A0), fontSize = 11.sp, modifier = Modifier.padding(6.dp))
                for (o in vm.project.objects) {
                    val sel = o.id == vm.selectedId
                    Text(
                        text = o.name,
                        color = if (sel) Color(0xFFFF9E26) else Color(0xFFD0D4E0),
                        fontSize = 12.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { vm.select(o.id) }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
            }
            Text(
                text = "1 dedo: girar câmera  |  pinça: zoom  |  toque: selecionar",
                color = Color(0xFF8A90A0),
                fontSize = 11.sp,
                modifier = Modifier.align(Alignment.BottomStart).padding(10.dp)
            )
        }
    }
}
