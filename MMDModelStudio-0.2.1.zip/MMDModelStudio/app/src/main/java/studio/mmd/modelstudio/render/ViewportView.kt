package studio.mmd.modelstudio.render

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.ViewConfiguration
import studio.mmd.modelstudio.core.SceneObject
import kotlin.math.hypot

/**
 * Viewport 3D. 1 dedo: orbita a câmera. 2 dedos (pinça): aproxima/afasta. Toque curto: seleciona.
 * Os gestos mexem só na câmera da viewport, nunca na orientação real do modelo.
 */
@SuppressLint("ClickableViewAccessibility")
class ViewportView(context: Context) : GLSurfaceView(context) {

    private val renderer = ViewportRenderer()
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    var onPick: (String?) -> Unit
        get() = renderer.onPick
        set(value) { renderer.onPick = value }

    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var moved = false

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            renderer.distance = (renderer.distance / detector.scaleFactor).coerceIn(2f, 60f)
            return true
        }
    })

    init {
        setEGLContextClientVersion(2)
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    fun setScene(objects: List<SceneObject>, selectedId: String?) {
        renderer.objects = objects
        renderer.selectedId = selectedId
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x; lastY = e.y; downX = e.x; downY = e.y; moved = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount == 1 && !scaleDetector.isInProgress) {
                    if (hypot(e.x - downX, e.y - downY) > slop) moved = true
                    val dx = e.x - lastX
                    val dy = e.y - lastY
                    renderer.yaw -= dx * 0.4f
                    renderer.pitch = (renderer.pitch + dy * 0.4f).coerceIn(-89f, 89f)
                    lastX = e.x; lastY = e.y
                }
            }
            MotionEvent.ACTION_POINTER_DOWN -> moved = true
            MotionEvent.ACTION_POINTER_UP -> {
                val idx = if (e.actionIndex == 0) 1 else 0
                if (idx < e.pointerCount) { lastX = e.getX(idx); lastY = e.getY(idx) }
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) {
                    val x = e.x
                    val y = e.y
                    queueEvent { renderer.pick(x, y) }
                }
            }
        }
        return true
    }
}
