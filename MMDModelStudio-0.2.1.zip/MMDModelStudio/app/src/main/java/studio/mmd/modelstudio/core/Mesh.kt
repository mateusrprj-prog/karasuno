package studio.mmd.modelstudio.core

import kotlin.math.max
import kotlin.math.sqrt

/** Malha triangulada: posições (x,y,z) e índices de triângulos. Independente de UI e de renderização. */
class MeshData(val positions: FloatArray, val indices: IntArray) {
    val vertexCount: Int get() = positions.size / 3
    val triangleCount: Int get() = indices.size / 3

    /** Raio da esfera que envolve a malha, a partir da origem local. */
    fun boundingRadius(): Float {
        var r2 = 0f
        for (i in 0 until vertexCount) {
            val x = positions[i * 3]
            val y = positions[i * 3 + 1]
            val z = positions[i * 3 + 2]
            r2 = max(r2, x * x + y * y + z * z)
        }
        return sqrt(r2)
    }
}

data class Vec3(val x: Float, val y: Float, val z: Float)

object Primitives {
    /** Cubo centrado na origem, com triângulos em sentido anti-horário visto de fora. */
    fun cube(size: Float = 1f): MeshData {
        val h = size / 2f
        val pos = FloatArray(24)
        for (i in 0 until 8) {
            pos[i * 3] = if (i and 1 != 0) h else -h
            pos[i * 3 + 1] = if (i and 2 != 0) h else -h
            pos[i * 3 + 2] = if (i and 4 != 0) h else -h
        }
        val quads = arrayOf(
            intArrayOf(4, 5, 7, 6), // +Z
            intArrayOf(1, 0, 2, 3), // -Z
            intArrayOf(5, 1, 3, 7), // +X
            intArrayOf(0, 4, 6, 2), // -X
            intArrayOf(2, 6, 7, 3), // +Y
            intArrayOf(0, 1, 5, 4)  // -Y
        )
        val idx = IntArray(36)
        var k = 0
        for (q in quads) {
            idx[k++] = q[0]; idx[k++] = q[1]; idx[k++] = q[2]
            idx[k++] = q[0]; idx[k++] = q[2]; idx[k++] = q[3]
        }
        return MeshData(pos, idx)
    }
}
