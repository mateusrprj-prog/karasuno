package studio.mmd.modelstudio.core

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Resultado de uma operação de malha. [selection] = triângulos que devem continuar selecionados. */
class MeshResult(val mesh: MeshData, val selection: Set<Int>, val note: String? = null)

/**
 * Operações de malha puras (sem Android), sobre malha de triângulos.
 * Uma "face" para o usuário = região de triângulos vizinhos e coplanares (ex.: os 2 triângulos de uma face do cubo).
 */
object MeshOps {

    private fun key(a: Int, b: Int): Long = (a.toLong() shl 32) or (b.toLong() and 0xFFFFFFFFL)

    /** Normal unitária do triângulo t (zero se degenerado). */
    fun triNormal(m: MeshData, t: Int): FloatArray {
        val p = m.positions
        val a = m.indices[t * 3] * 3; val b = m.indices[t * 3 + 1] * 3; val c = m.indices[t * 3 + 2] * 3
        val ux = p[b] - p[a]; val uy = p[b + 1] - p[a + 1]; val uz = p[b + 2] - p[a + 2]
        val vx = p[c] - p[a]; val vy = p[c + 1] - p[a + 1]; val vz = p[c + 2] - p[a + 2]
        var nx = uy * vz - uz * vy; var ny = uz * vx - ux * vz; var nz = ux * vy - uy * vx
        val l = sqrt(nx * nx + ny * ny + nz * nz)
        if (l > 0f) { nx /= l; ny /= l; nz /= l }
        return floatArrayOf(nx, ny, nz)
    }

    /** Triângulos conectados por aresta e coplanares ao triângulo [seed] (inclui o próprio). */
    fun faceRegion(m: MeshData, seed: Int): Set<Int> {
        if (seed < 0 || seed >= m.triangleCount) return emptySet()
        val edgeTris = HashMap<Long, MutableList<Int>>()
        for (t in 0 until m.triangleCount) {
            for (e in 0..2) {
                val a = m.indices[t * 3 + e]; val b = m.indices[t * 3 + (e + 1) % 3]
                edgeTris.getOrPut(key(min(a, b), max(a, b))) { ArrayList() }.add(t)
            }
        }
        val n0 = triNormal(m, seed)
        val out = HashSet<Int>()
        val queue = ArrayDeque<Int>()
        out.add(seed); queue.add(seed)
        while (queue.isNotEmpty()) {
            val t = queue.removeFirst()
            for (e in 0..2) {
                val a = m.indices[t * 3 + e]; val b = m.indices[t * 3 + (e + 1) % 3]
                val others = edgeTris[key(min(a, b), max(a, b))] ?: continue
                for (o in others) {
                    if (o in out) continue
                    val n = triNormal(m, o)
                    if (n0[0] * n[0] + n0[1] * n[1] + n0[2] * n[2] >= 0.9995f) { out.add(o); queue.add(o) }
                }
            }
        }
        return out
    }

    /** Vértices usados pelos triângulos dados. */
    fun vertsOfTris(m: MeshData, tris: Set<Int>): Set<Int> {
        val s = HashSet<Int>()
        for (t in tris) if (t in 0 until m.triangleCount) for (e in 0..2) s.add(m.indices[t * 3 + e])
        return s
    }

    /** Arestas orientadas (a→b) de borda da seleção: aquelas cuja oposta (b→a) não pertence a um triângulo selecionado. Valor = triângulo dono. */
    private fun boundaryEdges(m: MeshData, tris: Set<Int>): List<Triple<Int, Int, Int>> {
        val directed = HashSet<Long>()
        for (t in tris) for (e in 0..2) directed.add(key(m.indices[t * 3 + e], m.indices[t * 3 + (e + 1) % 3]))
        val out = ArrayList<Triple<Int, Int, Int>>()
        for (t in tris.sorted()) for (e in 0..2) {
            val a = m.indices[t * 3 + e]; val b = m.indices[t * 3 + (e + 1) % 3]
            if (key(b, a) !in directed) out.add(Triple(a, b, t))
        }
        return out
    }

    /**
     * Extrude as faces selecionadas por [distIn] ao longo da normal (negativo = para dentro).
     * Os triângulos selecionados mantêm o mesmo índice (a seleção continua válida); paredes são acrescentadas no fim.
     */
    fun extrude(m: MeshData, tris: Set<Int>, distIn: Float): MeshResult? {
        val sel = tris.filter { it in 0 until m.triangleCount }.toSet()
        if (sel.isEmpty()) return null
        val verts = vertsOfTris(m, sel).sorted()
        val base = m.vertexCount
        val newIndex = HashMap<Int, Int>()
        verts.forEachIndexed { i, v -> newIndex[v] = base + i }

        // direção por vértice = média (ponderada pela área) das normais dos triângulos selecionados que o usam
        val acc = HashMap<Int, FloatArray>()
        val p = m.positions
        for (t in sel) {
            val a = m.indices[t * 3] * 3; val b = m.indices[t * 3 + 1] * 3; val c = m.indices[t * 3 + 2] * 3
            val ux = p[b] - p[a]; val uy = p[b + 1] - p[a + 1]; val uz = p[b + 2] - p[a + 2]
            val vx = p[c] - p[a]; val vy = p[c + 1] - p[a + 1]; val vz = p[c + 2] - p[a + 2]
            val nx = uy * vz - uz * vy; val ny = uz * vx - ux * vz; val nz = ux * vy - uy * vx
            for (e in 0..2) {
                val v = acc.getOrPut(m.indices[t * 3 + e]) { FloatArray(3) }
                v[0] += nx; v[1] += ny; v[2] += nz
            }
        }

        // afundar uma face que vai até a quina do objeto: as paredes cairiam no plano das faces vizinhas (duas faces no mesmo plano = chiado)
        if (distIn < 0f) {
            val others = HashMap<Long, Int>()
            for (t in 0 until m.triangleCount) if (t !in sel) for (e in 0..2) {
                others[key(m.indices[t * 3 + e], m.indices[t * 3 + (e + 1) % 3])] = t
            }
            for ((a, b, t) in boundaryEdges(m, sel)) {
                val nb = others[key(b, a)] ?: continue
                val n1 = triNormal(m, t); val n2 = triNormal(m, nb)
                if (Math.abs(n1[0] * n2[0] + n1[1] * n2[1] + n1[2] * n2[2]) < 0.01f) return null
            }
        }
        // limite: a face não pode encostar em outra parte da malha (senão duas faces ficam no mesmo plano e "chiam")
        var allowed = Math.abs(distIn)
        var limited = false
        if (distIn != 0f) {
            val sgn = if (distIn > 0f) 1f else -1f
            for (v in verts) {
                val n = acc[v]!!
                val l = sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2])
                if (l == 0f) continue
                val hit = rayHit(m, sel, v, n[0] / l * sgn, n[1] / l * sgn, n[2] / l * sgn)
                if (hit - MIN_GAP < allowed) { allowed = max(0f, hit - MIN_GAP); limited = true }
            }
        }
        if (limited && allowed < 0.005f) return null
        val dist = if (distIn >= 0f) allowed else -allowed
        val pos = m.positions.copyOf(m.positions.size + verts.size * 3)
        for (v in verts) {
            val n = acc[v]!!
            val l = sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2])
            val k = if (l > 0f) dist / l else 0f
            val o = newIndex[v]!! * 3
            pos[o] = p[v * 3] + n[0] * k
            pos[o + 1] = p[v * 3 + 1] + n[1] * k
            pos[o + 2] = p[v * 3 + 2] + n[2] * k
        }

        val border = boundaryEdges(m, sel)
        val idx = m.indices.copyOf(m.indices.size + border.size * 6)
        // tampa: mesmos triângulos, agora usando os vértices novos
        for (t in sel) for (e in 0..2) idx[t * 3 + e] = newIndex[m.indices[t * 3 + e]]!!
        var k = m.indices.size
        for ((a, b, _) in border) {
            val a2 = newIndex[a]!!; val b2 = newIndex[b]!!
            idx[k++] = a; idx[k++] = b; idx[k++] = b2
            idx[k++] = a; idx[k++] = b2; idx[k++] = a2
        }
        return MeshResult(MeshData(pos, idx), sel, if (limited) "Limitado para não encostar em outra parte da malha." else null)
    }

    private const val MIN_GAP = 0.02f

    /** Distância até o primeiro triângulo (fora da seleção e que não usa o vértice v) atingido pelo raio a partir de v; infinito se nenhum. */
    private fun rayHit(m: MeshData, sel: Set<Int>, v: Int, dx: Float, dy: Float, dz: Float): Float {
        val p = m.positions
        val ox = p[v * 3]; val oy = p[v * 3 + 1]; val oz = p[v * 3 + 2]
        var best = Float.MAX_VALUE
        for (t in 0 until m.triangleCount) {
            if (t in sel) continue
            val ia = m.indices[t * 3]; val ib = m.indices[t * 3 + 1]; val ic = m.indices[t * 3 + 2]
            if (ia == v || ib == v || ic == v) continue
            val a = ia * 3; val b = ib * 3; val c = ic * 3
            val e1x = p[b] - p[a]; val e1y = p[b + 1] - p[a + 1]; val e1z = p[b + 2] - p[a + 2]
            val e2x = p[c] - p[a]; val e2y = p[c + 1] - p[a + 1]; val e2z = p[c + 2] - p[a + 2]
            val hx = dy * e2z - dz * e2y; val hy = dz * e2x - dx * e2z; val hz = dx * e2y - dy * e2x
            val det = e1x * hx + e1y * hy + e1z * hz
            if (det > -1e-9f && det < 1e-9f) continue
            val f = 1f / det
            val sx = ox - p[a]; val sy = oy - p[a + 1]; val sz = oz - p[a + 2]
            val u = f * (sx * hx + sy * hy + sz * hz)
            if (u < -1e-4f || u > 1.0001f) continue
            val qx = sy * e1z - sz * e1y; val qy = sz * e1x - sx * e1z; val qz = sx * e1y - sy * e1x
            val w = f * (dx * qx + dy * qy + dz * qz)
            if (w < -1e-4f || u + w > 1.0001f) continue
            val tt = f * (e2x * qx + e2y * qy + e2z * qz)
            if (tt > 1e-4f && tt < best) best = tt
        }
        return best
    }

    /**
     * Inset: encolhe as faces selecionadas para dentro por [amount] (unidades do objeto), criando um anel de faces em volta.
     * Só os vértices de borda são duplicados e movidos. O deslocamento é limitado para evitar inverter faces pequenas.
     */
    fun inset(m: MeshData, tris: Set<Int>, amount: Float): MeshResult? {
        val sel = tris.filter { it in 0 until m.triangleCount }.toSet()
        if (sel.isEmpty() || amount <= 0f) return null
        val border = boundaryEdges(m, sel)
        if (border.isEmpty()) return null
        val bverts = border.flatMap { listOf(it.first, it.second) }.toSortedSet().toList()
        val base = m.vertexCount
        val newIndex = HashMap<Int, Int>()
        bverts.forEachIndexed { i, v -> newIndex[v] = base + i }

        val p = m.positions
        // direção "para dentro" de cada aresta de borda = normal do triângulo × direção da aresta
        val inward = HashMap<Int, MutableList<FloatArray>>()
        for ((a, b, t) in border) {
            val n = triNormal(m, t)
            val ex = p[b * 3] - p[a * 3]; val ey = p[b * 3 + 1] - p[a * 3 + 1]; val ez = p[b * 3 + 2] - p[a * 3 + 2]
            var dx = n[1] * ez - n[2] * ey; var dy = n[2] * ex - n[0] * ez; var dz = n[0] * ey - n[1] * ex
            val l = sqrt(dx * dx + dy * dy + dz * dz)
            if (l == 0f) continue
            dx /= l; dy /= l; dz /= l
            val d = floatArrayOf(dx, dy, dz)
            inward.getOrPut(a) { ArrayList() }.add(d)
            inward.getOrPut(b) { ArrayList() }.add(d)
        }

        // limite por vértice: 90% da menor distância até o centro de um triângulo selecionado vizinho
        val limit = HashMap<Int, Float>()
        for (t in sel) {
            var cx = 0f; var cy = 0f; var cz = 0f
            for (e in 0..2) { val v = m.indices[t * 3 + e]; cx += p[v * 3]; cy += p[v * 3 + 1]; cz += p[v * 3 + 2] }
            cx /= 3f; cy /= 3f; cz /= 3f
            for (e in 0..2) {
                val v = m.indices[t * 3 + e]
                if (v !in newIndex) continue
                val dx = p[v * 3] - cx; val dy = p[v * 3 + 1] - cy; val dz = p[v * 3 + 2] - cz
                val dist = sqrt(dx * dx + dy * dy + dz * dz) * 0.9f
                limit[v] = min(limit[v] ?: Float.MAX_VALUE, dist)
            }
        }

        var clamped = false
        val pos = m.positions.copyOf(m.positions.size + bverts.size * 3)
        for (v in bverts) {
            val dirs = inward[v] ?: emptyList<FloatArray>()
            var sx = 0f; var sy = 0f; var sz = 0f
            for (d in dirs) { sx += d[0]; sy += d[1]; sz += d[2] }
            val sl = sqrt(sx * sx + sy * sy + sz * sz)
            var ox = 0f; var oy = 0f; var oz = 0f
            if (sl > 1e-6f) {
                sx /= sl; sy /= sl; sz /= sl
                var cosMin = 1f
                for (d in dirs) cosMin = min(cosMin, sx * d[0] + sy * d[1] + sz * d[2])
                var len = amount / max(cosMin, 0.3f)
                val lim = limit[v] ?: len
                if (len > lim) { len = lim; clamped = true }
                ox = sx * len; oy = sy * len; oz = sz * len
            }
            val o = newIndex[v]!! * 3
            pos[o] = p[v * 3] + ox; pos[o + 1] = p[v * 3 + 1] + oy; pos[o + 2] = p[v * 3 + 2] + oz
        }

        val idx = m.indices.copyOf(m.indices.size + border.size * 6)
        for (t in sel) for (e in 0..2) {
            val v = m.indices[t * 3 + e]
            idx[t * 3 + e] = newIndex[v] ?: v
        }
        var k = m.indices.size
        // anel: a face original ficou "por baixo"; o quadrilátero a,b,b',a' tem a mesma orientação das faces
        for ((a, b, _) in border) {
            val a2 = newIndex[a]!!; val b2 = newIndex[b]!!
            idx[k++] = a; idx[k++] = b; idx[k++] = b2
            idx[k++] = a; idx[k++] = b2; idx[k++] = a2
        }
        return MeshResult(MeshData(pos, idx), sel, if (clamped) "Inset limitado para não inverter faces pequenas." else null)
    }

    /** Apaga os triângulos dados e remove vértices que ficaram sem uso. Retorna null se apagaria tudo. */
    fun deleteTris(m: MeshData, tris: Set<Int>): MeshData? {
        val del = tris.filter { it in 0 until m.triangleCount }.toSet()
        if (del.isEmpty() || del.size >= m.triangleCount) return null
        val keep = (0 until m.triangleCount).filter { it !in del }
        val remap = IntArray(m.vertexCount) { -1 }
        var n = 0
        for (t in keep) for (e in 0..2) {
            val v = m.indices[t * 3 + e]
            if (remap[v] < 0) remap[v] = n++
        }
        val pos = FloatArray(n * 3)
        for (v in 0 until m.vertexCount) {
            val r = remap[v]
            if (r >= 0) { pos[r * 3] = m.positions[v * 3]; pos[r * 3 + 1] = m.positions[v * 3 + 1]; pos[r * 3 + 2] = m.positions[v * 3 + 2] }
        }
        val idx = IntArray(keep.size * 3)
        keep.forEachIndexed { i, t -> for (e in 0..2) idx[i * 3 + e] = remap[m.indices[t * 3 + e]] }
        return MeshData(pos, idx)
    }

    private fun normalOf(p: FloatArray, a: Int, b: Int, c: Int): FloatArray {
        val ux = p[b * 3] - p[a * 3]; val uy = p[b * 3 + 1] - p[a * 3 + 1]; val uz = p[b * 3 + 2] - p[a * 3 + 2]
        val vx = p[c * 3] - p[a * 3]; val vy = p[c * 3 + 1] - p[a * 3 + 1]; val vz = p[c * 3 + 2] - p[a * 3 + 2]
        var nx = uy * vz - uz * vy; var ny = uz * vx - ux * vz; var nz = ux * vy - uy * vx
        val l = sqrt(nx * nx + ny * ny + nz * nz)
        if (l > 0f) { nx /= l; ny /= l; nz /= l }
        return floatArrayOf(nx, ny, nz)
    }

    /**
     * Limpeza: solda vértices na mesma posição, remove triângulos degenerados, duplicados e paredes internas
     * sobrepostas (ex.: extrudir + e depois extrudir − deixava faces coincidentes que "chiavam" na tela).
     * A seleção de triângulos é remapeada.
     */
    fun cleanup(m: MeshData, sel: Set<Int>): MeshResult {
        val vc = m.vertexCount
        val tc = m.triangleCount
        // 1) soldar
        val keyMap = HashMap<Triple<Int, Int, Int>, Int>()
        val canon = IntArray(vc)
        val wl = ArrayList<Float>()
        for (v in 0 until vc) {
            val x = m.positions[v * 3]; val y = m.positions[v * 3 + 1]; val z = m.positions[v * 3 + 2]
            val k = Triple(Math.round(x * 1e4f), Math.round(y * 1e4f), Math.round(z * 1e4f))
            val existing = keyMap[k]
            if (existing != null) canon[v] = existing
            else {
                val n = keyMap.size
                keyMap[k] = n
                canon[v] = n
                wl.add(x); wl.add(y); wl.add(z)
            }
        }
        val wp = wl.toFloatArray()
        val idx = IntArray(m.indices.size) { canon[m.indices[it]] }
        val alive = BooleanArray(tc) { true }
        // 2) degenerados
        for (t in 0 until tc) {
            val a = idx[t * 3]; val b = idx[t * 3 + 1]; val c = idx[t * 3 + 2]
            if (a == b || b == c || a == c) alive[t] = false
        }
        // 3) mesmo trio de vértices: opostos se anulam, iguais ficam um só
        fun orient(t: Int): Triple<Int, Int, Int> {
            val a = idx[t * 3]; val b = idx[t * 3 + 1]; val c = idx[t * 3 + 2]
            return if (a < b && a < c) Triple(a, b, c) else if (b < a && b < c) Triple(b, c, a) else Triple(c, a, b)
        }
        val groups = HashMap<Triple<Int, Int, Int>, MutableList<Int>>()
        for (t in 0 until tc) if (alive[t]) {
            val sorted = listOf(idx[t * 3], idx[t * 3 + 1], idx[t * 3 + 2]).sorted()
            groups.getOrPut(Triple(sorted[0], sorted[1], sorted[2])) { ArrayList() }.add(t)
        }
        for ((_, l) in groups) {
            if (l.size < 2) continue
            val ref = orient(l[0])
            val same = l.filter { orient(it) == ref }.toMutableList()
            val opp = l.filter { orient(it) != ref }.toMutableList()
            while (same.isNotEmpty() && opp.isNotEmpty()) {
                alive[same.removeAt(same.size - 1)] = false
                alive[opp.removeAt(opp.size - 1)] = false
            }
            for (i in 1 until same.size) alive[same[i]] = false
            for (i in 1 until opp.size) alive[opp[i]] = false
        }
        // 4) quadriláteros (2 triângulos coplanares) sobrepostos com orientação oposta se anulam
        val nrm = HashMap<Int, FloatArray>()
        fun nOf(t: Int): FloatArray = nrm.getOrPut(t) { normalOf(wp, idx[t * 3], idx[t * 3 + 1], idx[t * 3 + 2]) }
        val edgeTris = HashMap<Long, MutableList<Int>>()
        for (t in 0 until tc) if (alive[t]) for (e in 0..2) {
            val a = idx[t * 3 + e]; val b = idx[t * 3 + (e + 1) % 3]
            edgeTris.getOrPut(key(min(a, b), max(a, b))) { ArrayList() }.add(t)
        }
        val quads = HashMap<List<Int>, MutableList<IntArray>>()
        for ((_, l) in edgeTris) {
            if (l.size != 2) continue
            val a = l[0]; val b = l[1]
            val na = nOf(a); val nb = nOf(b)
            if (na[0] * nb[0] + na[1] * nb[1] + na[2] * nb[2] <= 0.9999f) continue
            val vs = HashSet<Int>()
            for (e in 0..2) { vs.add(idx[a * 3 + e]); vs.add(idx[b * 3 + e]) }
            if (vs.size != 4) continue
            quads.getOrPut(vs.sorted()) { ArrayList() }.add(intArrayOf(a, b))
        }
        for ((_, l) in quads) {
            val used = HashSet<Int>()
            for (i in 0 until l.size) for (j in i + 1 until l.size) {
                val p = l[i]; val q = l[j]
                if (p[0] in used || p[1] in used || q[0] in used || q[1] in used) continue
                if (p[0] == q[0] || p[0] == q[1] || p[1] == q[0] || p[1] == q[1]) continue
                val n1 = nOf(p[0]); val n2 = nOf(q[0])
                if (n1[0] * n2[0] + n1[1] * n2[1] + n1[2] * n2[2] < -0.9999f) {
                    for (x in intArrayOf(p[0], p[1], q[0], q[1])) { alive[x] = false; used.add(x) }
                }
            }
        }
        // 5) compactar
        val triMap = IntArray(tc) { -1 }
        val remap = IntArray(wp.size / 3) { -1 }
        var nv = 0
        var nt = 0
        for (t in 0 until tc) if (alive[t]) {
            triMap[t] = nt++
            for (e in 0..2) { val v = idx[t * 3 + e]; if (remap[v] < 0) remap[v] = nv++ }
        }
        val pos = FloatArray(nv * 3)
        for (v in remap.indices) {
            val r = remap[v]
            if (r >= 0) { pos[r * 3] = wp[v * 3]; pos[r * 3 + 1] = wp[v * 3 + 1]; pos[r * 3 + 2] = wp[v * 3 + 2] }
        }
        val out = IntArray(nt * 3)
        for (t in 0 until tc) if (alive[t]) for (e in 0..2) out[triMap[t] * 3 + e] = remap[idx[t * 3 + e]]
        val newSel = sel.filter { it in 0 until tc && triMap[it] >= 0 }.map { triMap[it] }.toSet()
        return MeshResult(MeshData(pos, out), newSel)
    }

    /**
     * Subdivide as faces selecionadas (cada triângulo em 4). Triângulos vizinhos que dividem uma aresta cortada
     * também são divididos (2, 3 ou 4 partes) para não deixar rachaduras. Sem seleção, subdivide a malha inteira.
     * A seleção devolvida = filhos dos triângulos selecionados.
     */
    fun subdivide(m: MeshData, sel: Set<Int>): MeshResult? {
        if (m.triangleCount == 0 || m.triangleCount * 4 > 60000) return null
        val target: Set<Int> = if (sel.isEmpty()) (0 until m.triangleCount).toSet() else sel.filter { it in 0 until m.triangleCount }.toSet()
        if (target.isEmpty()) return null
        val cut = HashSet<Long>()
        for (t in target) for (e in 0..2) {
            val a = m.indices[t * 3 + e]; val b = m.indices[t * 3 + (e + 1) % 3]
            cut.add(key(min(a, b), max(a, b)))
        }
        val mids = HashMap<Long, Int>()
        val pl = ArrayList<Float>(m.positions.size * 2)
        for (f in m.positions) pl.add(f)
        var count = m.vertexCount
        fun mid(a: Int, b: Int): Int {
            val k = key(min(a, b), max(a, b))
            val e = mids[k]
            if (e != null) return e
            for (c in 0..2) pl.add((m.positions[a * 3 + c] + m.positions[b * 3 + c]) / 2f)
            mids[k] = count
            return count++
        }
        val out = ArrayList<Int>(m.indices.size * 2)
        val newSel = HashSet<Int>()
        for (t in 0 until m.triangleCount) {
            val v = intArrayOf(m.indices[t * 3], m.indices[t * 3 + 1], m.indices[t * 3 + 2])
            val isSel = sel.isNotEmpty() && t in target
            val has = BooleanArray(3) { e -> key(min(v[e], v[(e + 1) % 3]), max(v[e], v[(e + 1) % 3])) in cut }
            val n = has.count { it }
            fun add(x: Int, y: Int, z: Int) {
                if (isSel) newSel.add(out.size / 3)
                out.add(x); out.add(y); out.add(z)
            }
            if (isSel || n == 3 || (sel.isEmpty())) {
                val a = v[0]; val b = v[1]; val c = v[2]
                val ab = mid(a, b); val bc = mid(b, c); val ca = mid(c, a)
                add(a, ab, ca); add(ab, b, bc); add(ca, bc, c); add(ab, bc, ca)
            } else if (n == 0) {
                add(v[0], v[1], v[2])
            } else if (n == 1) {
                val r = has.indexOfFirst { it }
                val x = v[r]; val y = v[(r + 1) % 3]; val z = v[(r + 2) % 3]
                val mx = mid(x, y)
                add(x, mx, z); add(mx, y, z)
            } else {
                val r = has.indexOfFirst { !it }
                val x = v[r]; val y = v[(r + 1) % 3]; val z = v[(r + 2) % 3]
                val m1 = mid(y, z); val m2 = mid(z, x)
                add(z, m2, m1); add(x, y, m1); add(x, m1, m2)
            }
        }
        return MeshResult(MeshData(pl.toFloatArray(), out.toIntArray()), newSel)
    }

    /**
     * Detecta faces (triângulos) coplanares que se sobrepõem em área — a causa do "chiado" (z-fighting).
     * Agrupa por plano para não comparar tudo com tudo.
     */
    fun hasOverlap(m: MeshData): Boolean {
        val p = m.positions
        val buckets = HashMap<List<Int>, MutableList<Int>>()
        for (t in 0 until m.triangleCount) {
            val n = triNormal(m, t)
            if (n[0] == 0f && n[1] == 0f && n[2] == 0f) continue
            var sx = n[0]; var sy = n[1]; var sz = n[2]
            val flip = sx < -1e-4f || (Math.abs(sx) <= 1e-4f && (sy < -1e-4f || (Math.abs(sy) <= 1e-4f && sz < 0f)))
            if (flip) { sx = -sx; sy = -sy; sz = -sz }
            val a = m.indices[t * 3] * 3
            val d = sx * p[a] + sy * p[a + 1] + sz * p[a + 2]
            val k = listOf(Math.round(sx * 1000f), Math.round(sy * 1000f), Math.round(sz * 1000f), Math.round(d * 500f))
            buckets.getOrPut(k) { ArrayList() }.add(t)
        }
        for ((_, l) in buckets) {
            if (l.size < 2) continue
            // plano com triângulos demais (ex.: face muito subdividida): pula a checagem para não travar o app
            if (l.size.toLong() * l.size > 400_000L) continue
            for (i in 0 until l.size) for (j in i + 1 until l.size) {
                if (trianglesOverlap(m, l[i], l[j])) return true
            }
        }
        return false
    }

    private fun trianglesOverlap(m: MeshData, t1: Int, t2: Int): Boolean {
        val p = m.positions
        val n = triNormal(m, t1)
        val ax = if (Math.abs(n[0]) >= Math.abs(n[1]) && Math.abs(n[0]) >= Math.abs(n[2])) 0 else if (Math.abs(n[1]) >= Math.abs(n[2])) 1 else 2
        val u = (ax + 1) % 3; val w = (ax + 2) % 3
        fun tri2d(t: Int): Array<FloatArray> {
            val pts = Array(3) { e -> val v = m.indices[t * 3 + e] * 3; floatArrayOf(p[v + u], p[v + w]) }
            val cr = (pts[1][0] - pts[0][0]) * (pts[2][1] - pts[0][1]) - (pts[1][1] - pts[0][1]) * (pts[2][0] - pts[0][0])
            if (cr < 0f) { val tmp = pts[1]; pts[1] = pts[2]; pts[2] = tmp }
            return pts
        }
        // descarte rápido por caixa envolvente (sem alocar)
        var minU1 = Float.MAX_VALUE; var maxU1 = -Float.MAX_VALUE; var minW1 = Float.MAX_VALUE; var maxW1 = -Float.MAX_VALUE
        var minU2 = Float.MAX_VALUE; var maxU2 = -Float.MAX_VALUE; var minW2 = Float.MAX_VALUE; var maxW2 = -Float.MAX_VALUE
        for (e in 0..2) {
            val v1 = m.indices[t1 * 3 + e] * 3; val v2 = m.indices[t2 * 3 + e] * 3
            minU1 = min(minU1, p[v1 + u]); maxU1 = max(maxU1, p[v1 + u]); minW1 = min(minW1, p[v1 + w]); maxW1 = max(maxW1, p[v1 + w])
            minU2 = min(minU2, p[v2 + u]); maxU2 = max(maxU2, p[v2 + u]); minW2 = min(minW2, p[v2 + w]); maxW2 = max(maxW2, p[v2 + w])
        }
        if (maxU1 <= minU2 || maxU2 <= minU1 || maxW1 <= minW2 || maxW2 <= minW1) return false
        val a = tri2d(t1); val b = tri2d(t2)
        var poly: List<FloatArray> = a.toList()
        for (k in 0..2) {
            val c = b[k]; val d = b[(k + 1) % 3]
            val out = ArrayList<FloatArray>()
            for (i in poly.indices) {
                val s = poly[i]; val e = poly[(i + 1) % poly.size]
                val ss = (d[0] - c[0]) * (s[1] - c[1]) - (d[1] - c[1]) * (s[0] - c[0])
                val se = (d[0] - c[0]) * (e[1] - c[1]) - (d[1] - c[1]) * (e[0] - c[0])
                if (ss >= 0f) out.add(s)
                if ((ss >= 0f) != (se >= 0f)) {
                    val f = ss / (ss - se)
                    out.add(floatArrayOf(s[0] + f * (e[0] - s[0]), s[1] + f * (e[1] - s[1])))
                }
            }
            poly = out
            if (poly.size < 3) return false
        }
        var area = 0f
        for (i in poly.indices) {
            val s = poly[i]; val e = poly[(i + 1) % poly.size]
            area += s[0] * e[1] - e[0] * s[1]
        }
        return Math.abs(area) * 0.5f > 1e-6f
    }
}
