package studio.mmd.modelstudio.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import studio.mmd.modelstudio.core.Bone
import studio.mmd.modelstudio.core.MeshData
import studio.mmd.modelstudio.core.MeshResult
import studio.mmd.modelstudio.core.MeshOps
import studio.mmd.modelstudio.core.ModelProject
import studio.mmd.modelstudio.core.PmxExporter
import studio.mmd.modelstudio.core.Primitives
import studio.mmd.modelstudio.core.Skeletons
import studio.mmd.modelstudio.core.ProjectStore
import studio.mmd.modelstudio.core.SceneObject
import studio.mmd.modelstudio.core.Shape
import studio.mmd.modelstudio.core.Skinning
import studio.mmd.modelstudio.core.Vec3
import studio.mmd.modelstudio.core.VertexWeights
import studio.mmd.modelstudio.core.Weighting
import java.util.Locale
import java.util.UUID
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

enum class ToolMode(val label: String) { MOVE("Mover"), ROTATE("Girar"), SCALE("Escala"), OBJECT("Objeto"), MODEL("Modelar"), WEIGHT("Pesos") }

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    private val store = ProjectStore(app)
    private var counter = 0

    private val undoStack = ArrayList<ModelProject>()
    private val redoStack = ArrayList<ModelProject>()

    var project by mutableStateOf(ModelProject())
        private set
    var selectedId by mutableStateOf<String?>(null)
        private set
    var status by mutableStateOf("Toque em \"+ Forma\" para criar um objeto.")
        private set
    var mode by mutableStateOf(ToolMode.MOVE)
        private set
    var stepIndex by mutableStateOf(1)
        private set
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    // ---- modo de edição de malha ----
    var editMode by mutableStateOf(false)
        private set
    var selectedVerts by mutableStateOf<Set<Int>>(emptySet())
        private set
    var additive by mutableStateOf(false)
        private set
    var selectedBoneId by mutableStateOf<String?>(null)
        private set
    private var boneStepIndex = 1
    private val boneSteps = floatArrayOf(0.02f, 0.05f, 0.1f, 0.25f)
    /** true = seleciona faces (regiões planas); false = seleciona vértices. */
    var faceMode by mutableStateOf(false)
        private set
    var selectedTris by mutableStateOf<Set<Int>>(emptySet())
        private set

    // ---- pose de teste (não é salva) ----
    /** Rotação (graus) de cada osso na pose de teste. Vazio = sem pose. */
    var poseRot by mutableStateOf<Map<String, Vec3>>(emptyMap())
        private set
    /** Objetos e ossos como devem ser DESENHADOS: deformados pela pose na ferramenta Pesos, senão iguais ao projeto. */
    var displayObjects by mutableStateOf<List<SceneObject>>(emptyList())
        private set
    var displayBones by mutableStateOf<List<Bone>>(emptyList())
        private set
    private val weightSteps = floatArrayOf(0.1f, 0.25f, 0.5f)
    private val poseStep = 15f

    // quantidades por passo: [pequeno, médio, grande]
    private val moveSteps = floatArrayOf(0.1f, 0.5f, 1.0f)
    private val rotSteps = floatArrayOf(5f, 15f, 45f)
    private val scaleSteps = floatArrayOf(0.05f, 0.1f, 0.25f)
    private val modelSteps = floatArrayOf(0.05f, 0.1f, 0.25f)

    fun stepLabel(): String = when (mode) {
        ToolMode.MOVE -> fmt(moveSteps[stepIndex])
        ToolMode.ROTATE -> fmt(rotSteps[stepIndex]) + "°"
        ToolMode.SCALE -> fmt(scaleSteps[stepIndex])
        ToolMode.OBJECT -> "-"
        ToolMode.MODEL -> fmt(modelSteps[stepIndex])
        ToolMode.WEIGHT -> fmt(weightSteps[stepIndex])
    }

    private fun fmt(v: Float): String = String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')

    private fun commit(newProject: ModelProject) {
        undoStack.add(project)
        if (undoStack.size > 100) undoStack.removeAt(0)
        redoStack.clear()
        project = newProject
        refreshFlags()
    }

    private fun refreshFlags() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
        if (selectedBoneId != null && project.bones.none { it.id == selectedBoneId }) selectedBoneId = null
        if (selectedId != null && project.objects.none { it.id == selectedId }) {
            selectedId = null
            exitEdit()
        }
        if (editMode) {
            val vc = project.objects.firstOrNull { it.id == selectedId }?.mesh?.vertexCount ?: 0
            if (selectedVerts.any { it >= vc }) selectedVerts = selectedVerts.filter { it < vc }.toSet()
            val tc = project.objects.firstOrNull { it.id == selectedId }?.mesh?.triangleCount ?: 0
            if (selectedTris.any { it >= tc }) selectedTris = selectedTris.filter { it < tc }.toSet()
        }
        if (mode == ToolMode.WEIGHT && project.bones.isEmpty()) {
            mode = ToolMode.MOVE
            poseRot = emptyMap()
        }
        refreshDisplay()
    }

    /** Recalcula o que a viewport desenha: com pose ativa (ferramenta Pesos), as malhas deformadas; senão, o projeto. */
    private fun refreshDisplay() {
        if (mode == ToolMode.WEIGHT && poseRot.isNotEmpty()) {
            val posed = Skinning.pose(project, poseRot)
            displayObjects = posed.first
            displayBones = posed.second
        } else {
            displayObjects = project.objects
            displayBones = project.bones
        }
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.add(project)
        project = undoStack.removeAt(undoStack.size - 1)
        refreshFlags()
        status = "Desfeito."
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.add(project)
        project = redoStack.removeAt(redoStack.size - 1)
        refreshFlags()
        status = "Refeito."
    }

    fun selectMode(m: ToolMode) {
        if (m == ToolMode.WEIGHT && project.bones.isEmpty()) {
            status = "Crie o esqueleto primeiro: aba Objeto → Esqueleto → Humanoide."
            return
        }
        if (m != ToolMode.WEIGHT && poseRot.isNotEmpty()) poseRot = emptyMap()
        mode = m
        if (m == ToolMode.WEIGHT) status = "Pesos: escolha um osso na lista. Cores no objeto: azul 0% → vermelho 100%."
        refreshDisplay()
    }

    fun cycleStep() { stepIndex = (stepIndex + 1) % 3 }

    fun addShape(shape: Shape) {
        if (editMode) { status = "Saia do modo de edição para criar objetos."; return }
        counter++
        val i = project.objects.size
        val y = if (shape == Shape.PLANE) 0f else 0.5f
        val obj = SceneObject(
            id = UUID.randomUUID().toString(),
            name = "${shape.label} $counter",
            mesh = Primitives.create(shape),
            position = Vec3((i % 5) * 2.5f - 5f, y, (i / 5) * 2.5f)
        )
        commit(project.copy(objects = project.objects + obj))
        selectedId = obj.id
        status = "${obj.name} criado."
    }

    fun descendantsOf(id: String): Set<String> {
        val result = HashSet<String>()
        val queue = ArrayDeque<String>()
        queue.add(id)
        while (queue.isNotEmpty()) {
            val cur = queue.removeFirst()
            for (o in project.objects) {
                if (o.parentId == cur && result.add(o.id)) queue.add(o.id)
            }
        }
        return result
    }

    /** Exclui o objeto e todos os seus filhos (desfazer recupera). */
    fun deleteSelected() {
        if (editMode) { status = "Saia do modo de edição para excluir objetos."; return }
        val id = selectedId
        if (id == null) {
            status = "Nada selecionado."
            return
        }
        val name = project.objects.firstOrNull { it.id == id }?.name ?: "Objeto"
        val gone = descendantsOf(id) + id
        commit(project.copy(objects = project.objects.filter { it.id !in gone }))
        selectedId = null
        status = if (gone.size > 1) "$name e ${gone.size - 1} filho(s) excluídos." else "$name excluído."
    }

    fun rename(id: String, newName: String) {
        val n = newName.trim()
        if (n.isEmpty()) { status = "O nome não pode ficar vazio."; return }
        commit(project.copy(objects = project.objects.map { if (it.id == id) it.copy(name = n) else it }))
        status = "Renomeado para $n."
    }

    /** Define o pai mantendo os valores LOCAIS do filho (ele pode "pular" de lugar). */
    fun setParent(id: String, parentId: String?) {
        if (parentId != null && (parentId == id || parentId in descendantsOf(id))) {
            status = "Não dá para usar o próprio objeto ou um filho dele como pai."
            return
        }
        val obj = project.objects.firstOrNull { it.id == id } ?: return
        if (obj.parentId == parentId) return
        commit(project.copy(objects = project.objects.map { if (it.id == id) it.copy(parentId = parentId) else it }))
        val pn = project.objects.firstOrNull { it.id == parentId }?.name
        status = if (pn == null) "${obj.name} solto na cena." else "${obj.name} agora é filho de $pn."
    }

    fun toggleVisible(id: String) {
        val obj = project.objects.firstOrNull { it.id == id } ?: return
        commit(project.copy(objects = project.objects.map { if (it.id == id) it.copy(visible = !it.visible) else it }))
        status = if (obj.visible) "${obj.name} oculto." else "${obj.name} visível."
    }

    fun select(id: String?) {
        if (editMode && id != selectedId) exitEdit()
        selectedId = id
        status = if (id == null) "Seleção limpa." else
            "Selecionado: ${project.objects.firstOrNull { it.id == id }?.name ?: "?"}"
    }

    // ---------------- modo de edição ----------------
    private fun exitEdit() {
        editMode = false
        selectedVerts = emptySet()
        selectedTris = emptySet()
        faceMode = false
        if (mode == ToolMode.MODEL) mode = ToolMode.MOVE
    }

    fun toggleEdit() {
        if (editMode) {
            exitEdit()
            status = "Saiu do modo de edição."
            return
        }
        val obj = project.objects.firstOrNull { it.id == selectedId }
        if (obj == null) { status = "Selecione um objeto para editar."; return }
        editMode = true
        selectedVerts = emptySet()
        selectedTris = emptySet()
        faceMode = false
        status = "Edição de ${obj.name}: ${obj.mesh.vertexCount} vértices. Toque nos vértices."
    }

    fun toggleAdditive() {
        additive = !additive
        status = if (additive) "Seleção múltipla: cada toque soma/remove um vértice." else "Seleção simples: um vértice por vez."
    }

    fun pickVertex(idx: Int) {
        if (!editMode) return
        selectedVerts = if (idx < 0) {
            if (additive) selectedVerts else emptySet()
        } else if (additive) {
            if (idx in selectedVerts) selectedVerts - idx else selectedVerts + idx
        } else {
            setOf(idx)
        }
        status = "${selectedVerts.size} vértice(s) selecionado(s)."
    }

    /** Alterna entre selecionar vértices e faces. Face → vértice converte a seleção; vértice → face limpa. */
    fun toggleFaceMode() {
        if (!editMode) return
        val obj = project.objects.firstOrNull { it.id == selectedId } ?: return
        if (faceMode) {
            selectedVerts = MeshOps.vertsOfTris(obj.mesh, selectedTris)
            selectedTris = emptySet()
            faceMode = false
            status = "Modo vértice."
        } else {
            selectedVerts = emptySet()
            faceMode = true
            status = "Modo face: toque numa face para selecioná-la."
        }
    }

    /** [tri] = triângulo tocado (ou -1). Seleciona a região plana inteira. */
    fun pickFace(tri: Int) {
        if (!editMode || !faceMode) return
        val obj = project.objects.firstOrNull { it.id == selectedId } ?: return
        if (tri < 0) {
            if (!additive) selectedTris = emptySet()
        } else {
            val region = MeshOps.faceRegion(obj.mesh, tri)
            selectedTris = if (additive) {
                if (tri in selectedTris) selectedTris - region else selectedTris + region
            } else region
        }
        status = "${selectedTris.size} triângulo(s) selecionado(s)."
    }

    private fun editedObject(): SceneObject? = project.objects.firstOrNull { it.id == selectedId }

    /** Limpeza automática depois de extrudir/inset (remove paredes internas sobrepostas), mantendo a nota. */
    private fun tidy(r: MeshResult): MeshResult {
        val c = MeshOps.cleanup(r.mesh, r.selection)
        return MeshResult(c.mesh, c.selection, r.note)
    }

    fun subdivideMesh() {
        val obj = editedObject() ?: return
        val r = MeshOps.subdivide(obj.mesh, selectedTris)
            ?: run { status = "Malha grande demais para subdividir (limite 60000 triângulos)."; return }
        applyMeshResult(obj, r, "Subdividido: ${obj.mesh.triangleCount} → ${r.mesh.triangleCount} triângulos (${if (selectedTris.isEmpty()) "malha inteira" else "só a seleção"}).")
    }

    fun cleanMesh() {
        val obj = editedObject() ?: return
        val r = MeshOps.cleanup(obj.mesh, selectedTris)
        val dv = obj.mesh.vertexCount - r.mesh.vertexCount
        val dt = obj.mesh.triangleCount - r.mesh.triangleCount
        if (dv == 0 && dt == 0) { status = "Malha já está limpa."; return }
        applyMeshResult(obj, r, "Limpeza: $dt triângulo(s) e $dv vértice(s) removidos.")
    }

    /** Recusa a operação se ela criar faces sobrepostas no mesmo plano (chiado), a menos que a malha já estivesse assim. */
    private fun applySafe(obj: SceneObject, r: MeshResult, label: String) {
        if (!MeshOps.hasOverlap(obj.mesh) && MeshOps.hasOverlap(r.mesh)) {
            status = "Recusado: criaria faces sobrepostas no mesmo plano (chiado). Tente outra distância ou faça Inset antes."
            return
        }
        applyMeshResult(obj, r, label)
    }

    /** Pesos só sobrevivem a uma operação que não mexeu nos vértices (mesma quantidade e mesmas posições). */
    private fun keepWeights(old: SceneObject, newMesh: MeshData): VertexWeights? {
        val w = old.weights ?: return null
        return if (w.vertexCount == newMesh.vertexCount && old.mesh.positions.contentEquals(newMesh.positions)) w else null
    }

    private fun applyMeshResult(obj: SceneObject, r: MeshResult, label: String) {
        val kept = keepWeights(obj, r.mesh)
        val dropped = obj.weights != null && kept == null
        commit(project.copy(objects = project.objects.map { if (it.id == obj.id) it.copy(mesh = r.mesh, weights = kept) else it }))
        selectedTris = r.selection
        status = label + (r.note?.let { " $it" } ?: "") + (if (dropped) " Pesos descartados porque a malha mudou: refaça com Pesos → Auto." else "")
    }

    /** sign +1 = para fora, -1 = para dentro. Distância = passo atual. */
    fun extrudeFaces(sign: Int) {
        val obj = editedObject() ?: return
        if (!faceMode) { status = "Mude para Face (botão Vértice/Face) e selecione uma face."; return }
        if (selectedTris.isEmpty()) { status = "Toque numa face para selecioná-la."; return }
        val d = sign * modelSteps[stepIndex]
        val r = MeshOps.extrude(obj.mesh, selectedTris, d) ?: run { status = "Recusado: sem espaço, ou a face vai até a quina do objeto (faça Inset antes de afundar)."; return }
        applySafe(obj, tidy(r), "Extrudido ${if (sign > 0) "+" else "-"}${fmt(modelSteps[stepIndex])}.")
    }

    fun insetFaces() {
        val obj = editedObject() ?: return
        if (!faceMode) { status = "Mude para Face (botão Vértice/Face) e selecione uma face."; return }
        if (selectedTris.isEmpty()) { status = "Toque numa face para selecioná-la."; return }
        val r = MeshOps.inset(obj.mesh, selectedTris, modelSteps[stepIndex])
            ?: run { status = "Inset não aplicável (sem borda ou nada selecionado)."; return }
        applySafe(obj, tidy(r), "Inset ${fmt(modelSteps[stepIndex])}.")
    }

    fun deleteFaces() {
        val obj = editedObject() ?: return
        if (!faceMode) { status = "Mude para Face (botão Vértice/Face) e selecione uma face."; return }
        if (selectedTris.isEmpty()) { status = "Toque numa face para selecioná-la."; return }
        val m = MeshOps.deleteTris(obj.mesh, selectedTris)
            ?: run { status = "Não dá para apagar todas as faces; use Excluir no modo objeto."; return }
        val n = selectedTris.size
        val kept = keepWeights(obj, m)
        val dropped = obj.weights != null && kept == null
        commit(project.copy(objects = project.objects.map { if (it.id == obj.id) it.copy(mesh = m, weights = kept) else it }))
        selectedTris = emptySet()
        status = "$n triângulo(s) apagado(s)." + (if (dropped) " Pesos descartados porque a malha mudou: refaça com Pesos → Auto." else "")
    }

    fun selectAllVerts() {
        if (faceMode) {
            val tc = editedObject()?.mesh?.triangleCount ?: return
            selectedTris = (0 until tc).toSet(); status = "Todas as faces selecionadas."; return
        }
        val vc = project.objects.firstOrNull { it.id == selectedId }?.mesh?.vertexCount ?: return
        selectedVerts = (0 until vc).toSet()
        status = "${selectedVerts.size} vértice(s) selecionado(s)."
    }

    fun clearVerts() {
        if (faceMode) { selectedTris = emptySet(); status = "Nenhuma face selecionada."; return }
        selectedVerts = emptySet()
        status = "Nenhum vértice selecionado."
    }

    fun invertVerts() {
        if (faceMode) {
            val tc = editedObject()?.mesh?.triangleCount ?: return
            selectedTris = (0 until tc).filter { it !in selectedTris }.toSet(); status = "Seleção de faces invertida."; return
        }
        val vc = project.objects.firstOrNull { it.id == selectedId }?.mesh?.vertexCount ?: return
        selectedVerts = (0 until vc).filter { it !in selectedVerts }.toSet()
        status = "${selectedVerts.size} vértice(s) selecionado(s)."
    }

    /** axis: 0=X, 1=Y, 2=Z (ignorado em Escala). sign: +1 ou -1. */
    fun nudge(axis: Int, sign: Int) {
        val id = selectedId
        val obj = project.objects.firstOrNull { it.id == id }
        if (obj == null) {
            status = "Selecione um objeto primeiro."
            return
        }
        if (editMode) {
            nudgeVertices(obj, axis, sign)
            return
        }
        val updated = when (mode) {
            ToolMode.MOVE -> obj.copy(position = add(obj.position, axis, sign * moveSteps[stepIndex]))
            ToolMode.ROTATE -> obj.copy(rotation = add(obj.rotation, axis, sign * rotSteps[stepIndex]))
            ToolMode.SCALE -> obj.copy(scale = (obj.scale + sign * scaleSteps[stepIndex]).coerceIn(0.1f, 20f))
            ToolMode.OBJECT, ToolMode.MODEL, ToolMode.WEIGHT -> { status = "Escolha Mover, Girar ou Escala."; return }
        }
        commit(project.copy(objects = project.objects.map { if (it.id == obj.id) updated else it }))
        status = "${obj.name}: ${mode.label} ${if (sign > 0) "+" else "-"}${stepLabel()}"
    }

    /** Mover/Girar/Escalar vértices selecionados, nos eixos LOCAIS do objeto; girar e escalar usam o centro da seleção. */
    private fun nudgeVertices(obj: SceneObject, axis: Int, sign: Int) {
        if (mode == ToolMode.OBJECT || mode == ToolMode.MODEL || mode == ToolMode.WEIGHT) { status = "Escolha Mover, Girar ou Escala."; return }
        val sel = (if (faceMode) MeshOps.vertsOfTris(obj.mesh, selectedTris) else selectedVerts).filter { it < obj.mesh.vertexCount }
        if (sel.isEmpty()) { status = if (faceMode) "Toque numa face para selecioná-la." else "Toque nos vértices para selecioná-los."; return }
        val pos = obj.mesh.positions.copyOf()
        var cx = 0f; var cy = 0f; var cz = 0f
        for (i in sel) { cx += pos[i * 3]; cy += pos[i * 3 + 1]; cz += pos[i * 3 + 2] }
        cx /= sel.size; cy /= sel.size; cz /= sel.size
        when (mode) {
            ToolMode.MOVE -> {
                val d = sign * moveSteps[stepIndex]
                for (i in sel) pos[i * 3 + axis] += d
            }
            ToolMode.SCALE -> {
                val f = (1f + sign * scaleSteps[stepIndex]).coerceAtLeast(0.05f)
                for (i in sel) {
                    pos[i * 3] = cx + (pos[i * 3] - cx) * f
                    pos[i * 3 + 1] = cy + (pos[i * 3 + 1] - cy) * f
                    pos[i * 3 + 2] = cz + (pos[i * 3 + 2] - cz) * f
                }
            }
            ToolMode.ROTATE -> {
                val a = Math.toRadians((sign * rotSteps[stepIndex]).toDouble())
                val c = cos(a).toFloat(); val s = sin(a).toFloat()
                for (i in sel) {
                    val rx = pos[i * 3] - cx; val ry = pos[i * 3 + 1] - cy; val rz = pos[i * 3 + 2] - cz
                    var nx = rx; var ny = ry; var nz = rz
                    when (axis) {
                        0 -> { ny = ry * c - rz * s; nz = ry * s + rz * c }
                        1 -> { nx = rx * c + rz * s; nz = -rx * s + rz * c }
                        else -> { nx = rx * c - ry * s; ny = rx * s + ry * c }
                    }
                    pos[i * 3] = cx + nx; pos[i * 3 + 1] = cy + ny; pos[i * 3 + 2] = cz + nz
                }
            }
            ToolMode.OBJECT, ToolMode.MODEL, ToolMode.WEIGHT -> return
        }
        val updated = obj.copy(mesh = MeshData(pos, obj.mesh.indices))
        commit(project.copy(objects = project.objects.map { if (it.id == obj.id) updated else it }))
        status = "${sel.size} vértice(s)${if (faceMode) " das faces" else ""}: ${mode.label} ${if (sign > 0) "+" else "-"}${stepLabel()}"
    }

    private fun add(v: Vec3, axis: Int, d: Float): Vec3 = when (axis) {
        0 -> v.copy(x = v.x + d)
        1 -> v.copy(y = v.y + d)
        else -> v.copy(z = v.z + d)
    }

    fun save() {
        val snapshot = project
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { store.save(snapshot) } }
            status = result.fold(
                onSuccess = { "Projeto salvo (${snapshot.objects.size} objetos)." },
                onFailure = { "Erro ao salvar: ${it.message}" }
            )
        }
    }

    /** Exporta todos os objetos visíveis para um arquivo PMX 2.0 escolhido pelo usuário. */
    fun exportPmx(uri: android.net.Uri) {
        val snapshot = project
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val r = PmxExporter.export(snapshot)
                    if (r.report.vertices > 0) {
                        val stream = getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
                            ?: throw IllegalStateException("não foi possível abrir o arquivo de saída")
                        stream.use { it.write(r.data) }
                    }
                    r.report
                }
            }
            status = result.fold(
                onSuccess = { rep ->
                    if (rep.vertices == 0) "Nada exportado: crie um objeto visível com faces."
                    else "PMX exportado: ${rep.vertices} vértices, ${rep.triangles} triângulos, ${rep.materials} material(is), ${rep.bytes} bytes." +
                        " ${rep.bones} osso(s)." +
                        (if (rep.weighted > 0) " ${rep.weighted} vértice(s) com pesos." else "") +
                        (if (rep.warnings.isEmpty()) "" else " Avisos: " + rep.warnings.joinToString(" ")) +
                        " Sem texturas, morphs ou física."
                },
                onFailure = { "Erro ao exportar PMX: ${it.message}" }
            )
        }
    }

    // ---------- esqueleto ----------
    fun boneStepLabel(): String = fmt(boneSteps[boneStepIndex])
    fun cycleBoneStep() { boneStepIndex = (boneStepIndex + 1) % boneSteps.size }

    fun addHumanoidSkeleton() {
        val skeleton = Skeletons.humanoid()
        val ids = skeleton.map { it.id }.toSet()
        // objetos ligados a ossos que não existem mais no novo esqueleto ficam sem vínculo; pesos desses ossos somem
        val objs = project.objects.map { stripBones(it, ids) }
        commit(project.copy(objects = objs, bones = skeleton))
        selectedBoneId = skeleton.first().id
        status = "Esqueleto humanoide criado (${skeleton.size} ossos). Ligue cada objeto a um osso."
    }

    fun selectBone(id: String?) { selectedBoneId = id }

    /** Tira do objeto o vínculo e os pesos de ossos que não estão em [valid]. */
    private fun stripBones(o: SceneObject, valid: Set<String>): SceneObject {
        val newBone = if (o.boneId != null && o.boneId !in valid) null else o.boneId
        val w = o.weights
        val newWeights = if (w == null || valid.containsAll(w.palette)) w else Weighting.retain(w, valid)
        return if (newBone == o.boneId && newWeights === w) o else o.copy(boneId = newBone, weights = newWeights)
    }

    fun addBone() {
        val parent = project.bones.firstOrNull { it.id == selectedBoneId }
        val n = project.bones.size + 1
        val pos = if (parent != null) Vec3(parent.position.x, parent.position.y + 0.1f, parent.position.z) else Vec3(0f, 0.85f, 0f)
        val bone = Bone("b:" + UUID.randomUUID().toString().take(8), "Osso$n", "Bone$n", parent?.id, pos)
        commit(project.copy(bones = project.bones + bone))
        selectedBoneId = bone.id
        status = "Osso ${bone.name} criado."
    }

    fun deleteBone() {
        val b = project.bones.firstOrNull { it.id == selectedBoneId } ?: run { status = "Selecione um osso."; return }
        val bones = project.bones.filter { it.id != b.id }.map { if (it.parentId == b.id) it.copy(parentId = b.parentId) else it }
        val validIds = bones.map { it.id }.toSet()
        val objs = project.objects.map { stripBones(it, validIds) }
        commit(project.copy(bones = bones, objects = objs))
        selectedBoneId = null
        status = "Osso ${b.name} excluído (filhos sobem para o pai; objetos ligados ficaram sem vínculo)."
    }

    fun nudgeBone(axis: Int, dir: Int) {
        val id = selectedBoneId ?: run { status = "Selecione um osso."; return }
        val d = boneSteps[boneStepIndex] * dir
        commit(project.copy(bones = project.bones.map {
            if (it.id != id) it else it.copy(position = when (axis) {
                0 -> it.position.copy(x = it.position.x + d)
                1 -> it.position.copy(y = it.position.y + d)
                else -> it.position.copy(z = it.position.z + d)
            })
        }))
        status = "Osso movido ${if (dir > 0) "+" else "-"}${fmt(boneSteps[boneStepIndex])}."
    }

    fun bindObjectToBone(bind: Boolean) {
        val o = project.objects.firstOrNull { it.id == selectedId } ?: run { status = "Selecione um objeto na viewport ou na Hierarquia."; return }
        if (bind) {
            val b = project.bones.firstOrNull { it.id == selectedBoneId } ?: run { status = "Selecione um osso."; return }
            commit(project.copy(objects = project.objects.map { if (it.id == o.id) it.copy(boneId = b.id) else it }))
            status = "${o.name} ligado ao osso ${b.name}."
        } else {
            commit(project.copy(objects = project.objects.map { if (it.id == o.id) it.copy(boneId = null) else it }))
            status = "${o.name} sem vínculo."
        }
    }

    // ---------- pesos e pose de teste ----------
    private fun boneName(id: String): String = project.bones.firstOrNull { it.id == id }?.name ?: "?"

    /** Vértices que as ferramentas de peso usam: a seleção atual (vértices, ou os vértices das faces) no modo de edição; senão vazio. */
    private fun weightVerts(obj: SceneObject): Set<Int> {
        if (!editMode) return emptySet()
        val sel = if (faceMode) MeshOps.vertsOfTris(obj.mesh, selectedTris) else selectedVerts
        return sel.filter { it >= 0 && it < obj.mesh.vertexCount }.toSet()
    }

    private fun setWeights(obj: SceneObject, w: VertexWeights?, msg: String) {
        commit(project.copy(objects = project.objects.map { if (it.id == obj.id) it.copy(weights = w) else it }))
        status = msg
    }

    /** Texto do painel Pesos: pesos do vértice selecionado ou um resumo do objeto. */
    fun weightInfo(): String {
        val obj = project.objects.firstOrNull { it.id == selectedId } ?: return "Selecione um objeto (viewport ou Hierarquia)."
        val w = obj.weights
        if (w == null || w.vertexCount != obj.mesh.vertexCount) {
            val rigid = obj.boneId?.let { " Hoje ele segue inteiro o osso ${boneName(it)}." } ?: ""
            return "${obj.name}: sem pesos.$rigid Use Auto."
        }
        if (editMode && !faceMode && selectedVerts.size == 1) {
            val v = selectedVerts.first()
            val inf = Weighting.influences(w, v)
            val txt = if (inf.isEmpty()) "sem peso" else inf.joinToString(", ") { "${boneName(it.first)} ${(it.second * 100f).roundToInt()}%" }
            return "Vértice $v: $txt"
        }
        return "${obj.name}: ${Weighting.countWeighted(w)} de ${obj.mesh.vertexCount} vértices com pesos."
    }

    /** Pesos automáticos pela distância aos ossos: nos vértices selecionados (modo de edição) ou no objeto inteiro. */
    fun weightAuto() {
        if (project.bones.isEmpty()) { status = "Crie o esqueleto primeiro (aba Objeto → Esqueleto)."; return }
        val obj = editedObject() ?: run { status = "Selecione um objeto."; return }
        val sel = weightVerts(obj)
        val world = Weighting.worldPositions(obj, project.objects.associateBy { it.id })
        val w = Weighting.auto(world, project.bones, obj.weights, if (sel.isEmpty()) null else sel)
        val what = if (sel.isEmpty()) "objeto inteiro (${obj.mesh.vertexCount} vértices)" else "${sel.size} vértice(s)"
        setWeights(obj, w, "Pesos automáticos em $what. Gire ossos na pose de teste para conferir.")
    }

    private fun weightBone(): Bone? {
        val b = project.bones.firstOrNull { it.id == selectedBoneId }
        if (b == null) status = "Escolha um osso na lista do painel Pesos."
        return b
    }

    private fun weightSelection(obj: SceneObject): Set<Int>? {
        val sel = weightVerts(obj)
        if (sel.isEmpty()) {
            status = if (!editMode) "Entre em Editar e selecione vértices (ou faces) para pintar." else "Selecione vértices (ou faces) para pintar."
            return null
        }
        return sel
    }

    /** 100% do osso escolhido nos vértices selecionados. */
    fun weightAssign() {
        val obj = editedObject() ?: run { status = "Selecione um objeto."; return }
        val bone = weightBone() ?: return
        val sel = weightSelection(obj) ?: return
        val r = Weighting.assign(obj.weights, obj.mesh.vertexCount, sel, bone.id)
        setWeights(obj, r.weights, "${r.changed} vértice(s): 100% no osso ${bone.name}.")
    }

    /** sign +1 / −1: soma ou tira (passo) de peso do osso escolhido; os outros ossos do vértice compensam. */
    fun weightAdjust(sign: Int) {
        val obj = editedObject() ?: run { status = "Selecione um objeto."; return }
        val bone = weightBone() ?: return
        val sel = weightSelection(obj) ?: return
        val d = sign * weightSteps[stepIndex]
        val r = Weighting.adjust(obj.weights, obj.mesh.vertexCount, sel, bone.id, d)
        if (r.changed == 0) { status = "Nada mudou: o vértice só tem esse osso (ou já está no limite)."; return }
        setWeights(obj, r.weights, "${r.changed} vértice(s): ${if (sign > 0) "+" else "−"}${(weightSteps[stepIndex] * 100f).roundToInt()}% no osso ${bone.name}.")
    }

    /** Média dos pesos com os vizinhos, nos vértices selecionados. */
    fun weightSmooth() {
        val obj = editedObject() ?: run { status = "Selecione um objeto."; return }
        val sel = weightSelection(obj) ?: return
        if (obj.weights == null) { status = "Sem pesos para suavizar: use Auto primeiro."; return }
        val r = Weighting.smooth(obj.weights, obj.mesh, sel)
        setWeights(obj, r.weights, "Suavizado em ${r.changed} vértice(s).")
    }

    /** Zera os pesos dos vértices selecionados; sem seleção, zera o objeto inteiro (volta ao vínculo rígido). */
    fun weightClear() {
        val obj = editedObject() ?: run { status = "Selecione um objeto."; return }
        if (obj.weights == null) { status = "O objeto já está sem pesos."; return }
        val sel = weightVerts(obj)
        if (sel.isEmpty()) { setWeights(obj, null, "Pesos de ${obj.name} zerados."); return }
        val r = Weighting.clear(obj.weights, obj.mesh.vertexCount, sel)
        setWeights(obj, r.weights, "Pesos zerados em ${r.changed} vértice(s).")
    }

    fun poseLabel(): String {
        val id = selectedBoneId ?: return "Escolha um osso."
        val r = poseRot[id] ?: Vec3(0f, 0f, 0f)
        return "${boneName(id)}: X ${r.x.roundToInt()}°  Y ${r.y.roundToInt()}°  Z ${r.z.roundToInt()}°"
    }

    /** Gira o osso escolhido na pose de teste (15° por toque). Não altera o projeto. */
    fun poseBone(axis: Int, dir: Int) {
        val id = selectedBoneId ?: run { status = "Escolha um osso na lista."; return }
        val cur = poseRot[id] ?: Vec3(0f, 0f, 0f)
        val next = add(cur, axis, dir * poseStep)
        val map = HashMap<String, Vec3>(poseRot)
        if (next.x == 0f && next.y == 0f && next.z == 0f) {
            map.remove(id)
        } else {
            map[id] = next
        }
        poseRot = map
        refreshDisplay()
        status = "Pose de teste: ${poseLabel()}"
    }

    fun resetPose() {
        poseRot = emptyMap()
        refreshDisplay()
        status = "Pose de teste zerada."
    }

    fun load() {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { store.load() } }
            result.fold(
                onSuccess = { loaded ->
                    if (loaded == null) {
                        status = "Nenhum projeto salvo ainda."
                    } else {
                        undoStack.clear()
                        redoStack.clear()
                        exitEdit()
                        poseRot = emptyMap()
                        project = loaded
                        selectedId = null
                        selectedBoneId = null
                        counter = loaded.objects.size
                        refreshFlags()
                        status = "Projeto aberto (${loaded.objects.size} objetos)."
                    }
                },
                onFailure = { status = "Erro ao abrir: ${it.message}" }
            )
        }
    }
}
