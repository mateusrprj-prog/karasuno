package studio.mmd.modelstudio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import studio.mmd.modelstudio.core.Shape
import studio.mmd.modelstudio.core.flattenHierarchy
import studio.mmd.modelstudio.render.ViewportView

@Composable
private fun RowScope.Btn(text: String, primary: Boolean = false, enabled: Boolean = true, size: Int = 12, onClick: () -> Unit) {
    val mod = Modifier.weight(1f).height(38.dp)
    val pad = PaddingValues(2.dp)
    if (primary) {
        Button(onClick = onClick, modifier = mod, enabled = enabled, contentPadding = pad) {
            Text(text, fontSize = size.sp, maxLines = 1)
        }
    } else {
        OutlinedButton(onClick = onClick, modifier = mod, enabled = enabled, contentPadding = pad) {
            Text(text, fontSize = size.sp, maxLines = 1)
        }
    }
}

@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val pmxLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) vm.exportPmx(uri)
    }
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val viewport = remember { ViewportView(context) }
    viewport.onPick = { id -> vm.select(id) }
    viewport.onVertexPick = { idx -> vm.pickVertex(idx) }
    viewport.onFacePick = { t -> vm.pickFace(t) }

    var showRename by remember { mutableStateOf(false) }

    var showSkeleton by remember { mutableStateOf(false) }
    var showParent by remember { mutableStateOf(false) }
    var showShapes by remember { mutableStateOf(false) }
    val sel = vm.project.objects.firstOrNull { it.id == vm.selectedId }

    DisposableEffect(lifecycleOwner, viewport) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> viewport.onResume()
                Lifecycle.Event.ON_PAUSE -> viewport.onPause()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (showShapes) {
        AlertDialog(
            onDismissRequest = { showShapes = false },
            title = { Text("Nova forma") },
            text = {
                Column {
                    for (sh in Shape.values()) {
                        Text(
                            sh.label,
                            modifier = Modifier.fillMaxWidth().clickable { vm.addShape(sh); showShapes = false }.padding(12.dp)
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showShapes = false }) { Text("Cancelar") } }
        )
    }

    if (showRename && sel != null) {
        var text by remember(sel.id) { mutableStateOf(sel.name) }
        AlertDialog(
            onDismissRequest = { showRename = false },
            title = { Text("Renomear objeto") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = { vm.rename(sel.id, text); showRename = false }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showRename = false }) { Text("Cancelar") } }
        )
    }

    if (showParent && sel != null) {
        val blocked = vm.descendantsOf(sel.id) + sel.id
        val candidates = vm.project.objects.filter { it.id !in blocked }
        AlertDialog(
            onDismissRequest = { showParent = false },
            title = { Text("Pai de ${sel.name}") },
            text = {
                Column(Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState())) {
                    Text(
                        "(nenhum — solto na cena)",
                        modifier = Modifier.fillMaxWidth().clickable { vm.setParent(sel.id, null); showParent = false }.padding(10.dp)
                    )
                    for (c in candidates) {
                        Text(
                            c.name,
                            color = if (c.id == sel.parentId) Color(0xFFFF9E26) else Color.Unspecified,
                            modifier = Modifier.fillMaxWidth().clickable { vm.setParent(sel.id, c.id); showParent = false }.padding(10.dp)
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showParent = false }) { Text("Cancelar") } }
        )
    }

    Scaffold(
        bottomBar = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1B1D24))
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Linha 1: objetos, histórico e arquivo
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Btn("+ Forma", primary = true, enabled = !vm.editMode) { showShapes = true }
                    Btn("Excluir", enabled = !vm.editMode) { vm.deleteSelected() }
                    Btn("Desfazer", enabled = vm.canUndo) { vm.undo() }
                    Btn("Refazer", enabled = vm.canRedo) { vm.redo() }
                    Btn("Salvar") { vm.save() }
                    Btn("Abrir") { vm.load() }
                    Btn("PMX") { pmxLauncher.launch("modelo.pmx") }
                }
                // Linha 2: ferramentas
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (m in ToolMode.values()) {
                        if (m == ToolMode.MODEL && !vm.editMode) continue
                        if (m == ToolMode.WEIGHT && vm.project.bones.isEmpty()) continue
                        val label = if (vm.editMode && m == ToolMode.OBJECT) "Seleção" else m.label
                        Btn(label, primary = vm.mode == m, size = 11) { vm.selectMode(m) }
                    }
                    Btn("Editar", primary = vm.editMode, enabled = sel != null || vm.editMode, size = 11) { vm.toggleEdit() }
                    Btn("Passo: ${vm.stepLabel()}", enabled = vm.mode != ToolMode.OBJECT, size = 11) { vm.cycleStep() }
                }
                // Linha 3: depende da ferramenta
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    when (vm.mode) {
                        ToolMode.SCALE -> {
                            Btn("−  Menor") { vm.nudge(0, -1) }
                            Btn("+  Maior") { vm.nudge(0, 1) }
                        }
                        ToolMode.OBJECT -> if (vm.editMode) {
                            Btn("Tudo") { vm.selectAllVerts() }
                            Btn("Nenhum") { vm.clearVerts() }
                            Btn("Inverter") { vm.invertVerts() }
                            Btn("Múltipla: ${if (vm.additive) "sim" else "não"}", primary = vm.additive) { vm.toggleAdditive() }
                            Btn(if (vm.faceMode) "Face" else "Vértice", primary = vm.faceMode) { vm.toggleFaceMode() }
                        } else {
                            Btn("Renomear", enabled = sel != null) { showRename = true }
                            Btn("Definir pai", enabled = sel != null) { showParent = true }
                            Btn("Soltar do pai", enabled = sel?.parentId != null) { sel?.let { vm.setParent(it.id, null) } }
                            Btn("Esqueleto", primary = showSkeleton) { showSkeleton = !showSkeleton }
                            Btn(if (sel?.visible == false) "Mostrar" else "Ocultar", enabled = sel != null) {
                                sel?.let { vm.toggleVisible(it.id) }
                            }
                        }
                        ToolMode.MODEL -> {
                            Btn(if (vm.faceMode) "Face" else "Vértice", primary = vm.faceMode) { vm.toggleFaceMode() }
                            Btn("Extrudir +") { vm.extrudeFaces(1) }
                            Btn("Extrudir −") { vm.extrudeFaces(-1) }
                            Btn("Inset") { vm.insetFaces() }
                            Btn("Apagar face") { vm.deleteFaces() }
                            Btn("Subdividir") { vm.subdivideMesh() }
                            Btn("Limpar") { vm.cleanMesh() }
                        }
                        ToolMode.WEIGHT -> if (vm.editMode) {
                            Btn(if (vm.faceMode) "Face" else "Vértice", primary = vm.faceMode) { vm.toggleFaceMode() }
                            Btn("Auto") { vm.weightAuto() }
                            Btn("100%") { vm.weightAssign() }
                            Btn("+Peso") { vm.weightAdjust(1) }
                            Btn("−Peso") { vm.weightAdjust(-1) }
                            Btn("Suavizar") { vm.weightSmooth() }
                            Btn("Zerar") { vm.weightClear() }
                        } else {
                            Btn("Auto (objeto)", enabled = sel != null) { vm.weightAuto() }
                            Btn("Zerar pesos", enabled = sel != null) { vm.weightClear() }
                        }
                        else -> {
                            val names = arrayOf("X", "Y", "Z")
                            for (a in 0..2) {
                                Btn("${names[a]}−") { vm.nudge(a, -1) }
                                Btn("${names[a]}+") { vm.nudge(a, 1) }
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            AndroidView(
                factory = { viewport },
                update = { it.setScene(vm.displayObjects, vm.selectedId, if (vm.editMode) vm.selectedId else null, vm.selectedVerts, vm.faceMode, vm.selectedTris, vm.displayBones, vm.selectedBoneId, if (vm.mode == ToolMode.WEIGHT) vm.selectedBoneId else null) },
                modifier = Modifier.fillMaxSize()
            )
            Column(Modifier.align(Alignment.TopStart).padding(start = 10.dp, top = 10.dp, end = 170.dp)) {
                Text("MMD Model Studio  v0.12.0", color = Color.White, fontSize = 14.sp)
                Text(
                    text = (if (vm.editMode) "EDIÇÃO  |  " else "${vm.project.objects.size} objeto(s)  |  ") + vm.status,
                    color = Color(0xFFD0D4E0),
                    fontSize = 12.sp
                )
            }
            if (showSkeleton && vm.mode != ToolMode.WEIGHT) SkeletonPanel(vm, sel, Modifier.align(Alignment.CenterStart).padding(start = 8.dp, top = 30.dp))
            if (vm.mode == ToolMode.WEIGHT) WeightPanel(vm, Modifier.align(Alignment.CenterStart).padding(start = 8.dp, top = 30.dp))
            // Hierarquia (seleção por lista)
            Column(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .width(150.dp)
                    .heightIn(max = 140.dp)
                    .background(Color(0x99000000))
                    .verticalScroll(rememberScrollState())
            ) {
                Text("Hierarquia", color = Color(0xFF8A90A0), fontSize = 11.sp, modifier = Modifier.padding(6.dp))
                for ((o, depth) in flattenHierarchy(vm.project.objects)) {
                    val selected = o.id == vm.selectedId
                    val label = (if (depth > 0) "└ " else "") + o.name + (if (!o.visible) " (oculto)" else "")
                    Text(
                        text = label,
                        color = when {
                            selected -> Color(0xFFFF9E26)
                            !o.visible -> Color(0xFF6B7080)
                            else -> Color(0xFFD0D4E0)
                        },
                        fontSize = 12.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { vm.select(o.id) }
                            .padding(start = (8 + depth * 12).dp, end = 8.dp, top = 6.dp, bottom = 6.dp)
                    )
                }
            }
            Text(
                text = if (vm.editMode) (if (vm.faceMode) "1 dedo: girar câmera  |  pinça: zoom  |  toque: escolher face" else "1 dedo: girar câmera  |  pinça: zoom  |  toque: escolher vértice")
                else "1 dedo: girar câmera  |  pinça: zoom  |  toque: selecionar",
                color = Color(0xFF8A90A0),
                fontSize = 11.sp,
                modifier = Modifier.align(Alignment.BottomStart).padding(10.dp)
            )
        }
    }
}


/** Painel flutuante (não bloqueia a viewport) para criar, mover e ligar ossos. */
@Composable
private fun SkeletonPanel(vm: EditorViewModel, sel: studio.mmd.modelstudio.core.SceneObject?, modifier: Modifier) {
    val bones = vm.project.bones
    val byId = bones.associateBy { it.id }
    fun depthOf(b: studio.mmd.modelstudio.core.Bone): Int {
        var d = 0
        var p = b.parentId?.let { byId[it] }
        while (p != null && d < 20) { d++; p = p.parentId?.let { byId[it] } }
        return d
    }
    val tight = PaddingValues(0.dp)
    Column(
        modifier
            .width(220.dp)
            .heightIn(max = 250.dp)
            .background(Color(0xCC000000))
            .verticalScroll(rememberScrollState())
            .padding(6.dp)
    ) {
        Text("Esqueleto: ${bones.size} osso(s)", color = Color(0xFFD0D4E0), fontSize = 12.sp)
        Row(Modifier.fillMaxWidth()) {
            TextButton(onClick = { vm.addHumanoidSkeleton() }, contentPadding = tight, modifier = Modifier.weight(1.4f)) { Text("Humanoide", fontSize = 11.sp) }
            TextButton(onClick = { vm.addBone() }, contentPadding = tight, modifier = Modifier.weight(1f)) { Text("+ Osso", fontSize = 11.sp) }
            TextButton(onClick = { vm.deleteBone() }, enabled = vm.selectedBoneId != null, contentPadding = tight, modifier = Modifier.weight(1f)) { Text("Excluir", fontSize = 11.sp) }
        }
        val selBone = vm.selectedBoneId?.let { byId[it] }
        Text("Osso: ${selBone?.name ?: "-"}", color = Color(0xFFFF9E26), fontSize = 12.sp)
        Row(Modifier.fillMaxWidth()) {
            val names = arrayOf("X", "Y", "Z")
            for (a in 0..2) {
                TextButton(onClick = { vm.nudgeBone(a, -1) }, enabled = selBone != null, contentPadding = tight, modifier = Modifier.weight(1f)) { Text("${names[a]}−", fontSize = 12.sp) }
                TextButton(onClick = { vm.nudgeBone(a, 1) }, enabled = selBone != null, contentPadding = tight, modifier = Modifier.weight(1f)) { Text("${names[a]}+", fontSize = 12.sp) }
            }
        }
        Row(Modifier.fillMaxWidth()) {
            TextButton(onClick = { vm.cycleBoneStep() }, contentPadding = tight, modifier = Modifier.weight(1f)) { Text("Passo: ${vm.boneStepLabel()}", fontSize = 11.sp) }
        }
        val boundName = sel?.boneId?.let { byId[it]?.name }
        Text("Objeto: ${sel?.name ?: "-"}  →  ${boundName ?: "sem osso"}", color = Color(0xFFD0D4E0), fontSize = 11.sp)
        Row(Modifier.fillMaxWidth()) {
            TextButton(onClick = { vm.bindObjectToBone(true) }, enabled = sel != null && selBone != null, contentPadding = tight, modifier = Modifier.weight(1f)) { Text("Ligar ao osso", fontSize = 11.sp) }
            TextButton(onClick = { vm.bindObjectToBone(false) }, enabled = sel?.boneId != null, contentPadding = tight, modifier = Modifier.weight(1f)) { Text("Desligar", fontSize = 11.sp) }
        }
        for (b in bones) {
            val selected = b.id == vm.selectedBoneId
            Text(
                text = "  ".repeat(depthOf(b)) + b.name + (if (b.nameEn.isNotEmpty()) " (${b.nameEn})" else ""),
                color = if (selected) Color(0xFFFF9E26) else Color(0xFFB8E8C0),
                fontSize = 11.sp,
                modifier = Modifier.fillMaxWidth().clickable { vm.selectBone(b.id) }.padding(vertical = 3.dp)
            )
        }
    }
}


/** Painel flutuante da ferramenta Pesos: osso ativo, leitura dos pesos, pose de teste e lista de ossos. */
@Composable
private fun WeightPanel(vm: EditorViewModel, modifier: Modifier) {
    val bones = vm.project.bones
    val byId = bones.associateBy { it.id }
    fun depthOf(b: studio.mmd.modelstudio.core.Bone): Int {
        var d = 0
        var p = b.parentId?.let { byId[it] }
        while (p != null && d < 20) { d++; p = p.parentId?.let { byId[it] } }
        return d
    }
    val tight = PaddingValues(0.dp)
    val selBone = vm.selectedBoneId?.let { byId[it] }
    Column(
        modifier
            .width(220.dp)
            .heightIn(max = 250.dp)
            .background(Color(0xCC000000))
            .verticalScroll(rememberScrollState())
            .padding(6.dp)
    ) {
        Text("Pesos  (azul 0% → vermelho 100%)", color = Color(0xFFD0D4E0), fontSize = 11.sp)
        Text("Osso: ${selBone?.name ?: "-"}", color = Color(0xFFFF9E26), fontSize = 12.sp)
        Text(vm.weightInfo(), color = Color(0xFFD0D4E0), fontSize = 11.sp)
        Text("Pose de teste (15° por toque, não é salva):", color = Color(0xFF8A90A0), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        Text(vm.poseLabel(), color = Color(0xFFB8E8C0), fontSize = 11.sp)
        Row(Modifier.fillMaxWidth()) {
            val names = arrayOf("X", "Y", "Z")
            for (a in 0..2) {
                TextButton(onClick = { vm.poseBone(a, -1) }, enabled = selBone != null, contentPadding = tight, modifier = Modifier.weight(1f)) { Text("${names[a]}−", fontSize = 12.sp) }
                TextButton(onClick = { vm.poseBone(a, 1) }, enabled = selBone != null, contentPadding = tight, modifier = Modifier.weight(1f)) { Text("${names[a]}+", fontSize = 12.sp) }
            }
        }
        Row(Modifier.fillMaxWidth()) {
            TextButton(onClick = { vm.resetPose() }, enabled = vm.poseRot.isNotEmpty(), contentPadding = tight, modifier = Modifier.weight(1f)) { Text("Zerar pose", fontSize = 11.sp) }
        }
        for (b in bones) {
            val selected = b.id == vm.selectedBoneId
            Text(
                text = "  ".repeat(depthOf(b)) + b.name + (if (b.nameEn.isNotEmpty()) " (${b.nameEn})" else ""),
                color = if (selected) Color(0xFFFF9E26) else Color(0xFFB8E8C0),
                fontSize = 11.sp,
                modifier = Modifier.fillMaxWidth().clickable { vm.selectBone(b.id) }.padding(vertical = 3.dp)
            )
        }
    }
}
