package studio.mmd.modelstudio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import studio.mmd.modelstudio.render.ViewportView

@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val viewport = remember { ViewportView(context) }
    viewport.onPick = { id -> vm.select(id) }

    DisposableEffect(lifecycleOwner, viewport) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> viewport.onResume()
                Lifecycle.Event.ON_PAUSE -> viewport.onPause()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Scaffold(
        topBar = {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1B1D24))
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("MMD Model Studio", color = Color.White, fontSize = 18.sp)
                Text("  v0.1.0", color = Color(0xFF8A90A0), fontSize = 12.sp)
            }
        },
        bottomBar = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1B1D24))
                    .padding(8.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val pad = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                    Button(onClick = { vm.addCube() }, modifier = Modifier.weight(1f), contentPadding = pad) {
                        Text("+ Cubo", fontSize = 13.sp)
                    }
                    OutlinedButton(onClick = { vm.deleteSelected() }, modifier = Modifier.weight(1f), contentPadding = pad) {
                        Text("Excluir", fontSize = 13.sp)
                    }
                    OutlinedButton(onClick = { vm.save() }, modifier = Modifier.weight(1f), contentPadding = pad) {
                        Text("Salvar", fontSize = 13.sp)
                    }
                    OutlinedButton(onClick = { vm.load() }, modifier = Modifier.weight(1f), contentPadding = pad) {
                        Text("Abrir", fontSize = 13.sp)
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            AndroidView(
                factory = { viewport },
                update = { it.setScene(vm.project.objects, vm.selectedId) },
                modifier = Modifier.fillMaxSize()
            )
            Text(
                text = "${vm.project.objects.size} objeto(s)  |  ${vm.status}",
                color = Color(0xFFD0D4E0),
                fontSize = 12.sp,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(10.dp)
            )
            Text(
                text = "1 dedo: girar  |  pinça: zoom  |  toque: selecionar",
                color = Color(0xFF8A90A0),
                fontSize = 11.sp,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(10.dp)
            )
        }
    }
}
