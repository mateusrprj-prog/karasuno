package studio.mmd.modelstudio.core

data class SceneObject(
    val id: String,
    val name: String,
    val mesh: MeshData,
    val position: Vec3 = Vec3(0f, 0f, 0f),
    val scale: Float = 1f
)

/** Projeto interno editável. A exportação PMX (futura) será derivada deste modelo. */
data class ModelProject(
    val schemaVersion: Int = CURRENT_SCHEMA,
    val name: String = "Projeto sem título",
    val objects: List<SceneObject> = emptyList()
) {
    companion object {
        const val CURRENT_SCHEMA = 1
    }
}
