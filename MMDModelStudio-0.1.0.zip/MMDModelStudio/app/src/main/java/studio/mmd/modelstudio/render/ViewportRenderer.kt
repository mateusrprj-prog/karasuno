package studio.mmd.modelstudio.render

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLU
import android.opengl.Matrix
import android.os.Handler
import android.os.Looper
import studio.mmd.modelstudio.core.MeshData
import studio.mmd.modelstudio.core.SceneObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Renderizador OpenGL ES 2.0 da viewport. Só lê dados; a fonte da verdade é o ModelProject. */
class ViewportRenderer : GLSurfaceView.Renderer {

    @Volatile var objects: List<SceneObject> = emptyList()
    @Volatile var selectedId: String? = null
    @Volatile var yaw = 35f
    @Volatile var pitch = 25f
    @Volatile var distance = 9f
    var onPick: (String?) -> Unit = {}

    private val mainHandler = Handler(Looper.getMainLooper())

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private var width = 1
    private var height = 1

    private var program = 0
    private var aPos = 0
    private var aNormal = 0
    private var uMvp = 0
    private var uModel = 0
    private var uColor = 0
    private var uLight = 0

    private lateinit var gridBuf: FloatBuffer
    private var gridCount = 0
    private lateinit var axisX: FloatBuffer
    private lateinit var axisZ: FloatBuffer

    private class Cached(val mesh: MeshData, val buf: FloatBuffer, val vertexCount: Int)
    private val cache = HashMap<String, Cached>()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.11f, 0.12f, 0.15f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val vs = compile(GLES20.GL_VERTEX_SHADER, VERTEX)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FRAGMENT)
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vs)
        GLES20.glAttachShader(program, fs)
        GLES20.glLinkProgram(program)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Link: " + GLES20.glGetProgramInfoLog(program))
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aNormal = GLES20.glGetAttribLocation(program, "aNormal")
        uMvp = GLES20.glGetUniformLocation(program, "uMVP")
        uModel = GLES20.glGetUniformLocation(program, "uModel")
        uColor = GLES20.glGetUniformLocation(program, "uColor")
        uLight = GLES20.glGetUniformLocation(program, "uLight")
        buildGrid()
        cache.clear()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        width = maxOf(w, 1)
        height = maxOf(h, 1)
        GLES20.glViewport(0, 0, width, height)
        Matrix.perspectiveM(proj, 0, 45f, width.toFloat() / height.toFloat(), 0.1f, 200f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        val yr = yaw * PI.toFloat() / 180f
        val pr = pitch * PI.toFloat() / 180f
        val d = distance
        val ex = d * cos(pr) * sin(yr)
        val ey = d * sin(pr)
        val ez = d * cos(pr) * cos(yr)
        Matrix.setLookAtM(view, 0, ex, ey, ez, 0f, 0.5f, 0f, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        GLES20.glUseProgram(program)

        Matrix.setIdentityM(model, 0)
        drawLines(gridBuf, gridCount, 0.28f, 0.30f, 0.36f)
        drawLines(axisX, 2, 0.85f, 0.25f, 0.25f)
        drawLines(axisZ, 2, 0.25f, 0.45f, 0.90f)

        val sel = selectedId
        val current = objects
        val alive = HashSet<String>()
        for (o in current) {
            alive.add(o.id)
            val c = cacheFor(o)
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, o.position.x, o.position.y, o.position.z)
            Matrix.scaleM(model, 0, o.scale, o.scale, o.scale)
            if (o.id == sel) drawMesh(c, 1.0f, 0.62f, 0.15f) else drawMesh(c, 0.55f, 0.68f, 0.85f)
        }
        cache.keys.retainAll(alive)
    }

    /** Chamado na thread de GL. Seleciona o objeto atingido por um raio a partir do toque. */
    fun pick(px: Float, py: Float) {
        val viewport = intArrayOf(0, 0, width, height)
        val near = FloatArray(4)
        val far = FloatArray(4)
        val wy = height - py
        GLU.gluUnProject(px, wy, 0f, view, 0, proj, 0, viewport, 0, near, 0)
        GLU.gluUnProject(px, wy, 1f, view, 0, proj, 0, viewport, 0, far, 0)
        if (near[3] == 0f || far[3] == 0f) return
        val ox = near[0] / near[3]; val oy = near[1] / near[3]; val oz = near[2] / near[3]
        var dx = far[0] / far[3] - ox; var dy = far[1] / far[3] - oy; var dz = far[2] / far[3] - oz
        val len = sqrt(dx * dx + dy * dy + dz * dz)
        if (len == 0f) return
        dx /= len; dy /= len; dz /= len

        var bestT = Float.MAX_VALUE
        var bestId: String? = null
        for (o in objects) {
            val r = o.mesh.boundingRadius() * o.scale
            val cx = ox - o.position.x; val cy = oy - o.position.y; val cz = oz - o.position.z
            val b = cx * dx + cy * dy + cz * dz
            val c = cx * cx + cy * cy + cz * cz - r * r
            val disc = b * b - c
            if (disc < 0f) continue
            val t = -b - sqrt(disc)
            if (t >= 0f && t < bestT) { bestT = t; bestId = o.id }
        }
        mainHandler.post { onPick(bestId) }
    }

    // ---------- desenho ----------
    private fun drawLines(buf: FloatBuffer, count: Int, r: Float, g: Float, b: Float) {
        GLES20.glUniformMatrix4fv(uMvp, 1, false, vp, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)
        GLES20.glUniform4f(uColor, r, g, b, 1f)
        GLES20.glUniform1f(uLight, 0f)
        buf.position(0)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 0, buf)
        GLES20.glDisableVertexAttribArray(aNormal)
        GLES20.glVertexAttrib3f(aNormal, 0f, 1f, 0f)
        GLES20.glDrawArrays(GLES20.GL_LINES, 0, count)
        GLES20.glDisableVertexAttribArray(aPos)
    }

    private fun drawMesh(c: Cached, r: Float, g: Float, b: Float) {
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, model, 0)
        GLES20.glUniform4f(uColor, r, g, b, 1f)
        GLES20.glUniform1f(uLight, 1f)
        c.buf.position(0)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 24, c.buf)
        c.buf.position(3)
        GLES20.glEnableVertexAttribArray(aNormal)
        GLES20.glVertexAttribPointer(aNormal, 3, GLES20.GL_FLOAT, false, 24, c.buf)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, c.vertexCount)
        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aNormal)
    }

    private fun cacheFor(o: SceneObject): Cached {
        val existing = cache[o.id]
        if (existing != null && existing.mesh === o.mesh) return existing
        val c = expand(o.mesh)
        cache[o.id] = c
        return c
    }

    /** Expande a malha indexada em triângulos independentes com normal de face (sombreamento plano). */
    private fun expand(m: MeshData): Cached {
        val tris = m.triangleCount
        val arr = FloatArray(tris * 3 * 6)
        var k = 0
        for (t in 0 until tris) {
            val i0 = m.indices[t * 3] * 3
            val i1 = m.indices[t * 3 + 1] * 3
            val i2 = m.indices[t * 3 + 2] * 3
            val p = m.positions
            val ux = p[i1] - p[i0]; val uy = p[i1 + 1] - p[i0 + 1]; val uz = p[i1 + 2] - p[i0 + 2]
            val vx = p[i2] - p[i0]; val vy = p[i2 + 1] - p[i0 + 1]; val vz = p[i2 + 2] - p[i0 + 2]
            var nx = uy * vz - uz * vy
            var ny = uz * vx - ux * vz
            var nz = ux * vy - uy * vx
            val l = sqrt(nx * nx + ny * ny + nz * nz)
            if (l > 0f) { nx /= l; ny /= l; nz /= l }
            for (idx in intArrayOf(i0, i1, i2)) {
                arr[k++] = p[idx]; arr[k++] = p[idx + 1]; arr[k++] = p[idx + 2]
                arr[k++] = nx; arr[k++] = ny; arr[k++] = nz
            }
        }
        return Cached(m, toBuffer(arr), tris * 3)
    }

    private fun buildGrid() {
        val n = 10
        val list = ArrayList<Float>()
        for (i in -n..n) {
            if (i == 0) continue
            list.addAll(listOf(i.toFloat(), 0f, -n.toFloat(), i.toFloat(), 0f, n.toFloat()))
            list.addAll(listOf(-n.toFloat(), 0f, i.toFloat(), n.toFloat(), 0f, i.toFloat()))
        }
        val a = list.toFloatArray()
        gridBuf = toBuffer(a)
        gridCount = a.size / 3
        axisX = toBuffer(floatArrayOf(-n.toFloat(), 0f, 0f, n.toFloat(), 0f, 0f))
        axisZ = toBuffer(floatArrayOf(0f, 0f, -n.toFloat(), 0f, 0f, n.toFloat()))
    }

    private fun toBuffer(a: FloatArray): FloatBuffer {
        val b = ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        b.put(a)
        b.position(0)
        return b
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            throw RuntimeException("Shader: $log")
        }
        return s
    }

    companion object {
        private const val VERTEX = """
            uniform mat4 uMVP;
            uniform mat4 uModel;
            attribute vec3 aPos;
            attribute vec3 aNormal;
            varying vec3 vN;
            void main() {
                vN = (uModel * vec4(aNormal, 0.0)).xyz;
                gl_Position = uMVP * vec4(aPos, 1.0);
            }
        """
        private const val FRAGMENT = """
            precision mediump float;
            uniform vec4 uColor;
            uniform float uLight;
            varying vec3 vN;
            void main() {
                float l = 1.0;
                if (uLight > 0.5) {
                    vec3 n = normalize(vN);
                    l = 0.35 + 0.65 * max(dot(n, normalize(vec3(0.4, 0.8, 0.6))), 0.0);
                }
                gl_FragColor = vec4(uColor.rgb * l, uColor.a);
            }
        """
    }
}
