package studio.mmd.modelstudio.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object ProjectJson {
    fun toJson(p: ModelProject): String {
        val root = JSONObject()
        root.put("schemaVersion", p.schemaVersion)
        root.put("name", p.name)
        val arr = JSONArray()
        for (o in p.objects) {
            val jo = JSONObject()
            jo.put("id", o.id)
            jo.put("name", o.name)
            jo.put("position", JSONArray(listOf(o.position.x.toDouble(), o.position.y.toDouble(), o.position.z.toDouble())))
            jo.put("scale", o.scale.toDouble())
            val mesh = JSONObject()
            mesh.put("positions", JSONArray(o.mesh.positions.map { it.toDouble() }))
            mesh.put("indices", JSONArray(o.mesh.indices.toList()))
            jo.put("mesh", mesh)
            arr.put(jo)
        }
        root.put("objects", arr)
        return root.toString(2)
    }

    fun fromJson(text: String): ModelProject {
        val root = JSONObject(text)
        val version = root.optInt("schemaVersion", 1)
        if (version > ModelProject.CURRENT_SCHEMA) {
            throw IllegalStateException("Projeto criado em versão mais nova do app (esquema $version).")
        }
        val objs = ArrayList<SceneObject>()
        val arr = root.optJSONArray("objects") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val jo = arr.getJSONObject(i)
            val pos = jo.getJSONArray("position")
            val m = jo.getJSONObject("mesh")
            val pa = m.getJSONArray("positions")
            val ia = m.getJSONArray("indices")
            val positions = FloatArray(pa.length()) { pa.getDouble(it).toFloat() }
            val indices = IntArray(ia.length()) { ia.getInt(it) }
            objs.add(
                SceneObject(
                    id = jo.getString("id"),
                    name = jo.getString("name"),
                    mesh = MeshData(positions, indices),
                    position = Vec3(pos.getDouble(0).toFloat(), pos.getDouble(1).toFloat(), pos.getDouble(2).toFloat()),
                    scale = jo.optDouble("scale", 1.0).toFloat()
                )
            )
        }
        return ModelProject(
            schemaVersion = ModelProject.CURRENT_SCHEMA,
            name = root.optString("name", "Projeto sem título"),
            objects = objs
        )
    }
}

/** Salvamento com arquivo temporário + cópia de segurança (.bak) do salvamento anterior. */
class ProjectStore(context: Context) {
    private val dir = File(context.filesDir, "projects").apply { mkdirs() }
    private val file = File(dir, "default.mmdproj.json")

    fun save(project: ModelProject) {
        val tmp = File(dir, "default.mmdproj.json.tmp")
        tmp.writeText(ProjectJson.toJson(project))
        if (file.exists()) file.copyTo(File(dir, "default.mmdproj.json.bak"), overwrite = true)
        if (!tmp.renameTo(file)) {
            tmp.copyTo(file, overwrite = true)
            tmp.delete()
        }
    }

    fun load(): ModelProject? {
        if (!file.exists()) return null
        return ProjectJson.fromJson(file.readText())
    }
}
