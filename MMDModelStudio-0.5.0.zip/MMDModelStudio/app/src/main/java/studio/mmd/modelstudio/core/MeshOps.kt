package studio.mmd.modelstudio.core

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Resultado de uma operação de malha. [selection] = triângulos que devem continuar selecionados. */
class MeshResult(val mesh: MeshData, val selection: Set<Int>, val note: String? = null)

/**
 * Operações de malha puras (sem Android), sobre malha de triângulos.
 * Uma "face" para o usuário = região de triângulos vizinhos e coplanares (ex.: os 2 triângulos de uma face do cubo).
 */
object MeshOps {

    private fun key(a: Int, b: Int): Long = (a.toLong() shl 32) or (b.toLong() and 0xFFFFFFFFL)

    /** Normal unitária do triângulo t (zero se degenerado). */
    fun triNormal(m: MeshData, t: Int): FloatArray {
        val p = m.positions
        val a = m.indices[t * 3] * 3; val b = m.indices[t * 3 + 1] * 3; val c = m.indices[t * 3 + 2] * 3
        val ux = p[b] - p[a]; val uy = p[b + 1] - p[a + 1]; val uz = p[b + 2] - p[a + 2]
        val vx = p[c] - p[a]; val vy = p[c + 1] - p[a + 1]; val vz = p[c + 2] - p[a + 2]
        var nx = uy * vz - uz * vy; var ny = uz * vx - ux * vz; var nz = ux * vy - uy * vx
        val l = sqrt(nx * nx + ny * ny + nz * nz)
        if (l > 0f) { nx /= l; ny /= l; nz /= l }
        return floatArrayOf(nx, ny, nz)
    }

    /** Triângulos conectados por aresta e coplanares ao triângulo [seed] (inclui o próprio). */
    fun faceRegion(m: MeshData, seed: Int): Set<Int> {
        if (seed < 0 || seed >= m.triangleCount) return emptySet()
        val edgeTris = HashMap<Long, MutableList<Int>>()
        for (t in 0 until m.triangleCount) {
            for (e in 0..2) {
                val a = m.indices[t * 3 + e]; val b = m.indices[t * 3 + (e + 1) % 3]
                edgeTris.getOrPut(key(min(a, b), max(a, b))) { ArrayList() }.add(t)
            }
        }
        val n0 = triNormal(m, seed)
        val out = HashSet<Int>()
        val queue = ArrayDeque<Int>()
        out.add(seed); queue.add(seed)
        while (queue.isNotEmpty()) {
            val t = queue.removeFirst()
            for (e in 0..2) {
                val a = m.indices[t * 3 + e]; val b = m.indices[t * 3 + (e + 1) % 3]
                val others = edgeTris[key(min(a, b), max(a, b))] ?: continue
                for (o in others) {
                    if (o in out) continue
                    val n = triNormal(m, o)
                    if (n0[0] * n[0] + n0[1] * n[1] + n0[2] * n[2] >= 0.9995f) { out.add(o); queue.add(o) }
                }
            }
        }
        return out
    }

    /** Vértices usados pelos triângulos dados. */
    fun vertsOfTris(m: MeshData, tris: Set<Int>): Set<Int> {
        val s = HashSet<Int>()
        for (t in tris) if (t in 0 until m.triangleCount) for (e in 0..2) s.add(m.indices[t * 3 + e])
        return s
    }

    /** Arestas orientadas (a→b) de borda da seleção: aquelas cuja oposta (b→a) não pertence a um triângulo selecionado. Valor = triângulo dono. */
    private fun boundaryEdges(m: MeshData, tris: Set<Int>): List<Triple<Int, Int, Int>> {
        val directed = HashSet<Long>()
        for (t in tris) for (e in 0..2) directed.add(key(m.indices[t * 3 + e], m.indices[t * 3 + (e + 1) % 3]))
        val out = ArrayList<Triple<Int, Int, Int>>()
        for (t in tris.sorted()) for (e in 0..2) {
            val a = m.indices[t * 3 + e]; val b = m.indices[t * 3 + (e + 1) % 3]
            if (key(b, a) !in directed) out.add(Triple(a, b, t))
        }
        return out
    }

    /**
     * Extrude as faces selecionadas por [dist] ao longo da normal (negativo = para dentro).
     * Os triângulos selecionados mantêm o mesmo índice (a seleção continua válida); paredes são acrescentadas no fim.
     */
    fun extrude(m: MeshData, tris: Set<Int>, dist: Float): MeshResult? {
        val sel = tris.filter { it in 0 until m.triangleCount }.toSet()
        if (sel.isEmpty()) return null
        val verts = vertsOfTris(m, sel).sorted()
        val base = m.vertexCount
        val newIndex = HashMap<Int, Int>()
        verts.forEachIndexed { i, v -> newIndex[v] = base + i }

        // direção por vértice = média (ponderada pela área) das normais dos triângulos selecionados que o usam
        val acc = HashMap<Int, FloatArray>()
        val p = m.positions
        for (t in sel) {
            val a = m.indices[t * 3] * 3; val b = m.indices[t * 3 + 1] * 3; val c = m.indices[t * 3 + 2] * 3
            val ux = p[b] - p[a]; val uy = p[b + 1] - p[a + 1]; val uz = p[b + 2] - p[a + 2]
            val vx = p[c] - p[a]; val vy = p[c + 1] - p[a + 1]; val vz = p[c + 2] - p[a + 2]
            val nx = uy * vz - uz * vy; val ny = uz * vx - ux * vz; val nz = ux * vy - uy * vx
            for (e in 0..2) {
                val v = acc.getOrPut(m.indices[t * 3 + e]) { FloatArray(3) }
                v[0] += nx; v[1] += ny; v[2] += nz
            }
        }

        val pos = m.positions.copyOf(m.positions.size + verts.size * 3)
        for (v in verts) {
            val n = acc[v]!!
            val l = sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2])
            val k = if (l > 0f) dist / l else 0f
            val o = newIndex[v]!! * 3
            pos[o] = p[v * 3] + n[0] * k
            pos[o + 1] = p[v * 3 + 1] + n[1] * k
            pos[o + 2] = p[v * 3 + 2] + n[2] * k
        }

        val border = boundaryEdges(m, sel)
        val idx = m.indices.copyOf(m.indices.size + border.size * 6)
        // tampa: mesmos triângulos, agora usando os vértices novos
        for (t in sel) for (e in 0..2) idx[t * 3 + e] = newIndex[m.indices[t * 3 + e]]!!
        var k = m.indices.size
        for ((a, b, _) in border) {
            val a2 = newIndex[a]!!; val b2 = newIndex[b]!!
            idx[k++] = a; idx[k++] = b; idx[k++] = b2
            idx[k++] = a; idx[k++] = b2; idx[k++] = a2
        }
        return MeshResult(MeshData(pos, idx), sel)
    }

    /**
     * Inset: encolhe as faces selecionadas para dentro por [amount] (unidades do objeto), criando um anel de faces em volta.
     * Só os vértices de borda são duplicados e movidos. O deslocamento é limitado para evitar inverter faces pequenas.
     */
    fun inset(m: MeshData, tris: Set<Int>, amount: Float): MeshResult? {
        val sel = tris.filter { it in 0 until m.triangleCount }.toSet()
        if (sel.isEmpty() || amount <= 0f) return null
        val border = boundaryEdges(m, sel)
        if (border.isEmpty()) return null
        val bverts = border.flatMap { listOf(it.first, it.second) }.toSortedSet().toList()
        val base = m.vertexCount
        val newIndex = HashMap<Int, Int>()
        bverts.forEachIndexed { i, v -> newIndex[v] = base + i }

        val p = m.positions
        // direção "para dentro" de cada aresta de borda = normal do triângulo × direção da aresta
        val inward = HashMap<Int, MutableList<FloatArray>>()
        for ((a, b, t) in border) {
            val n = triNormal(m, t)
            val ex = p[b * 3] - p[a * 3]; val ey = p[b * 3 + 1] - p[a * 3 + 1]; val ez = p[b * 3 + 2] - p[a * 3 + 2]
            var dx = n[1] * ez - n[2] * ey; var dy = n[2] * ex - n[0] * ez; var dz = n[0] * ey - n[1] * ex
            val l = sqrt(dx * dx + dy * dy + dz * dz)
            if (l == 0f) continue
            dx /= l; dy /= l; dz /= l
            val d = floatArrayOf(dx, dy, dz)
            inward.getOrPut(a) { ArrayList() }.add(d)
            inward.getOrPut(b) { ArrayList() }.add(d)
        }

        // limite por vértice: 90% da menor distância até o centro de um triângulo selecionado vizinho
        val limit = HashMap<Int, Float>()
        for (t in sel) {
            var cx = 0f; var cy = 0f; var cz = 0f
            for (e in 0..2) { val v = m.indices[t * 3 + e]; cx += p[v * 3]; cy += p[v * 3 + 1]; cz += p[v * 3 + 2] }
            cx /= 3f; cy /= 3f; cz /= 3f
            for (e in 0..2) {
                val v = m.indices[t * 3 + e]
                if (v !in newIndex) continue
                val dx = p[v * 3] - cx; val dy = p[v * 3 + 1] - cy; val dz = p[v * 3 + 2] - cz
                val dist = sqrt(dx * dx + dy * dy + dz * dz) * 0.9f
                limit[v] = min(limit[v] ?: Float.MAX_VALUE, dist)
            }
        }

        var clamped = false
        val pos = m.positions.copyOf(m.positions.size + bverts.size * 3)
        for (v in bverts) {
            val dirs = inward[v] ?: emptyList<FloatArray>()
            var sx = 0f; var sy = 0f; var sz = 0f
            for (d in dirs) { sx += d[0]; sy += d[1]; sz += d[2] }
            val sl = sqrt(sx * sx + sy * sy + sz * sz)
            var ox = 0f; var oy = 0f; var oz = 0f
            if (sl > 1e-6f) {
                sx /= sl; sy /= sl; sz /= sl
                var cosMin = 1f
                for (d in dirs) cosMin = min(cosMin, sx * d[0] + sy * d[1] + sz * d[2])
                var len = amount / max(cosMin, 0.3f)
                val lim = limit[v] ?: len
                if (len > lim) { len = lim; clamped = true }
                ox = sx * len; oy = sy * len; oz = sz * len
            }
            val o = newIndex[v]!! * 3
            pos[o] = p[v * 3] + ox; pos[o + 1] = p[v * 3 + 1] + oy; pos[o + 2] = p[v * 3 + 2] + oz
        }

        val idx = m.indices.copyOf(m.indices.size + border.size * 6)
        for (t in sel) for (e in 0..2) {
            val v = m.indices[t * 3 + e]
            idx[t * 3 + e] = newIndex[v] ?: v
        }
        var k = m.indices.size
        // anel: a face original ficou "por baixo"; o quadrilátero a,b,b',a' tem a mesma orientação das faces
        for ((a, b, _) in border) {
            val a2 = newIndex[a]!!; val b2 = newIndex[b]!!
            idx[k++] = a; idx[k++] = b; idx[k++] = b2
            idx[k++] = a; idx[k++] = b2; idx[k++] = a2
        }
        return MeshResult(MeshData(pos, idx), sel, if (clamped) "Inset limitado para não inverter faces pequenas." else null)
    }

    /** Apaga os triângulos dados e remove vértices que ficaram sem uso. Retorna null se apagaria tudo. */
    fun deleteTris(m: MeshData, tris: Set<Int>): MeshData? {
        val del = tris.filter { it in 0 until m.triangleCount }.toSet()
        if (del.isEmpty() || del.size >= m.triangleCount) return null
        val keep = (0 until m.triangleCount).filter { it !in del }
        val remap = IntArray(m.vertexCount) { -1 }
        var n = 0
        for (t in keep) for (e in 0..2) {
            val v = m.indices[t * 3 + e]
            if (remap[v] < 0) remap[v] = n++
        }
        val pos = FloatArray(n * 3)
        for (v in 0 until m.vertexCount) {
            val r = remap[v]
            if (r >= 0) { pos[r * 3] = m.positions[v * 3]; pos[r * 3 + 1] = m.positions[v * 3 + 1]; pos[r * 3 + 2] = m.positions[v * 3 + 2] }
        }
        val idx = IntArray(keep.size * 3)
        keep.forEachIndexed { i, t -> for (e in 0..2) idx[i * 3 + e] = remap[m.indices[t * 3 + e]] }
        return MeshData(pos, idx)
    }
}
