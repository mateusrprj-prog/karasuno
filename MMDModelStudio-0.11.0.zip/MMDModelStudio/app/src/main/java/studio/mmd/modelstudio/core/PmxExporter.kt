package studio.mmd.modelstudio.core

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Resumo do que foi exportado (para a mensagem de status e para o registro de testes). */
class PmxReport(val vertices: Int, val triangles: Int, val materials: Int, val bones: Int, val bytes: Int, val warnings: List<String>)

class PmxResult(val data: ByteArray, val report: PmxReport)

/**
 * Exportador PMX 2.0 (mínimo, mas estruturalmente completo).
 *
 * O que escreve: cabeçalho, vértices (BDEF1: cada objeto inteiro no osso a que está ligado), faces, 0 texturas,
 * 1 material por objeto visível, os ossos do esqueleto do projeto (sem esqueleto: 1 osso "センター"), 0 morphs,
 * quadros de exibição "Root", "表情" e "ボーン", 0 corpos rígidos, 0 juntas.
 * Não escreve (ainda): texturas/UV reais, pesos por vértice, IK, morphs, física.
 *
 * Conversão de coordenadas: o app é destro (Y para cima); o PMX/MMD é canhoto. Nega-se Z (posição e normal)
 * mantendo a ordem dos índices, o que resulta em faces frontais no sentido horário, como o MMD espera.
 * Escala: 1 unidade do app = [scale] unidades do MMD (provisório: 12, ou seja, 1 unidade ≈ 1 m com personagem ~20).
 * NÃO foi validado no MMD original.
 */
object PmxExporter {
    const val DEFAULT_SCALE = 12f
    private const val CREASE_COS = 0.7071f // 45°: normais de faces mais inclinadas que isso não são misturadas

    private class Affine(val a: DoubleArray, val t: DoubleArray) // a = 3x3 linha-a-linha

    private fun mul(x: DoubleArray, y: DoubleArray): DoubleArray {
        val r = DoubleArray(9)
        for (i in 0..2) for (j in 0..2) r[i * 3 + j] = x[i * 3] * y[j] + x[i * 3 + 1] * y[3 + j] + x[i * 3 + 2] * y[6 + j]
        return r
    }

    private fun worldOf(o: SceneObject, byId: Map<String, SceneObject>, depth: Int): Affine {
        val rx = Math.toRadians(o.rotation.x.toDouble()); val ry = Math.toRadians(o.rotation.y.toDouble()); val rz = Math.toRadians(o.rotation.z.toDouble())
        val cx = cos(rx); val sx = sin(rx); val cy = cos(ry); val sy = sin(ry); val cz = cos(rz); val sz = sin(rz)
        val rX = doubleArrayOf(1.0, 0.0, 0.0, 0.0, cx, -sx, 0.0, sx, cx)
        val rY = doubleArrayOf(cy, 0.0, sy, 0.0, 1.0, 0.0, -sy, 0.0, cy)
        val rZ = doubleArrayOf(cz, -sz, 0.0, sz, cz, 0.0, 0.0, 0.0, 1.0)
        // ordem igual à do renderizador: T · Ry · Rx · Rz · S
        val rot = mul(mul(rY, rX), rZ)
        val s = o.scale.toDouble()
        val local = DoubleArray(9) { rot[it] * s }
        val lt = doubleArrayOf(o.position.x.toDouble(), o.position.y.toDouble(), o.position.z.toDouble())
        val p = o.parentId?.let { byId[it] }
        if (p == null || depth >= 32) return Affine(local, lt)
        val pw = worldOf(p, byId, depth + 1)
        val a = mul(pw.a, local)
        val t = DoubleArray(3) { i -> pw.a[i * 3] * lt[0] + pw.a[i * 3 + 1] * lt[1] + pw.a[i * 3 + 2] * lt[2] + pw.t[i] }
        return Affine(a, t)
    }

    private class Out {
        val bos = ByteArrayOutputStream()
        private val tmp = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
        fun byte(v: Int) { bos.write(v and 0xFF) }
        fun short(v: Int) { tmp.clear(); tmp.putShort(v.toShort()); bos.write(tmp.array(), 0, 2) }
        fun int(v: Int) { tmp.clear(); tmp.putInt(v); bos.write(tmp.array(), 0, 4) }
        fun float(v: Float) { tmp.clear(); tmp.putFloat(v); bos.write(tmp.array(), 0, 4) }
        fun text(s: String) { val b = s.toByteArray(Charsets.UTF_16LE); int(b.size); bos.write(b) }
        fun bytes(b: ByteArray) { bos.write(b) }
    }

    fun export(project: ModelProject, scale: Float = DEFAULT_SCALE, modelName: String = "MMD Model Studio"): PmxResult {
        val warnings = ArrayList<String>()
        val byId = project.objects.associateBy { it.id }

        // geometria de todos os objetos visíveis
        class Mat(val name: String, val faceIndexCount: Int)
        val px = ArrayList<Float>(); val nx = ArrayList<Float>()
        val faces = ArrayList<Int>()
        val mats = ArrayList<Mat>()
        val vb = ArrayList<Int>() // osso de cada vértice
        val boneIndex = HashMap<String, Int>()
        project.bones.forEachIndexed { i, b -> boneIndex[b.id] = i }

        for (o in project.objects) {
            if (!o.visible) { warnings.add("\"${o.name}\" está oculto e não foi exportado."); continue }
            val m = o.mesh
            if (m.triangleCount == 0) { warnings.add("\"${o.name}\" não tem faces e não foi exportado."); continue }
            val w = worldOf(o, byId, 0)
            val objBone = o.boneId?.let { boneIndex[it] }
            if (objBone == null && project.bones.isNotEmpty()) warnings.add("\"${o.name}\" sem osso: ligado a \"${project.bones[0].name}\".")
            val bi = objBone ?: 0
            val p = m.positions
            // normais de área por triângulo (não normalizadas) e unitárias
            val area = Array(m.triangleCount) { DoubleArray(3) }
            val unit = Array(m.triangleCount) { DoubleArray(3) }
            val valid = BooleanArray(m.triangleCount)
            val incident = HashMap<Int, MutableList<Int>>()
            for (t in 0 until m.triangleCount) {
                val a = m.indices[t * 3] * 3; val b = m.indices[t * 3 + 1] * 3; val c = m.indices[t * 3 + 2] * 3
                val ux = (p[b] - p[a]).toDouble(); val uy = (p[b + 1] - p[a + 1]).toDouble(); val uz = (p[b + 2] - p[a + 2]).toDouble()
                val vx = (p[c] - p[a]).toDouble(); val vy = (p[c + 1] - p[a + 1]).toDouble(); val vz = (p[c + 2] - p[a + 2]).toDouble()
                val x = uy * vz - uz * vy; val y = uz * vx - ux * vz; val z = ux * vy - uy * vx
                val l = sqrt(x * x + y * y + z * z)
                if (l < 1e-12) continue
                valid[t] = true
                area[t] = doubleArrayOf(x, y, z)
                unit[t] = doubleArrayOf(x / l, y / l, z / l)
                for (e in 0..2) incident.getOrPut(m.indices[t * 3 + e]) { ArrayList() }.add(t)
            }
            val newIndex = HashMap<List<Int>, Int>()
            var faceCount = 0
            for (t in 0 until m.triangleCount) {
                if (!valid[t]) continue
                for (e in 0..2) {
                    val v = m.indices[t * 3 + e]
                    var sx = 0.0; var sy = 0.0; var sz = 0.0
                    for (u in incident[v]!!) {
                        val d = unit[t][0] * unit[u][0] + unit[t][1] * unit[u][1] + unit[t][2] * unit[u][2]
                        if (d >= CREASE_COS) { sx += area[u][0]; sy += area[u][1]; sz += area[u][2] }
                    }
                    var l = sqrt(sx * sx + sy * sy + sz * sz)
                    if (l < 1e-12) { sx = unit[t][0]; sy = unit[t][1]; sz = unit[t][2]; l = 1.0 }
                    sx /= l; sy /= l; sz /= l
                    val key = listOf(v, Math.round(sx * 1000).toInt(), Math.round(sy * 1000).toInt(), Math.round(sz * 1000).toInt())
                    val existing = newIndex[key]
                    val vi: Int
                    if (existing != null) vi = existing
                    else {
                        vi = px.size / 3
                        newIndex[key] = vi
                        // posição no mundo
                        val lx = p[v * 3].toDouble(); val ly = p[v * 3 + 1].toDouble(); val lz = p[v * 3 + 2].toDouble()
                        val wx = w.a[0] * lx + w.a[1] * ly + w.a[2] * lz + w.t[0]
                        val wy = w.a[3] * lx + w.a[4] * ly + w.a[5] * lz + w.t[1]
                        val wz = w.a[6] * lx + w.a[7] * ly + w.a[8] * lz + w.t[2]
                        // normal no mundo (escala uniforme: basta a parte linear, renormalizada)
                        var nwx = w.a[0] * sx + w.a[1] * sy + w.a[2] * sz
                        var nwy = w.a[3] * sx + w.a[4] * sy + w.a[5] * sz
                        var nwz = w.a[6] * sx + w.a[7] * sy + w.a[8] * sz
                        val nl = sqrt(nwx * nwx + nwy * nwy + nwz * nwz)
                        if (nl > 1e-12) { nwx /= nl; nwy /= nl; nwz /= nl }
                        px.add((wx * scale).toFloat()); px.add((wy * scale).toFloat()); px.add((-wz * scale).toFloat())
                        nx.add(nwx.toFloat()); nx.add(nwy.toFloat()); nx.add((-nwz).toFloat())
                        vb.add(bi)
                    }
                    faces.add(vi)
                }
                faceCount += 3
            }
            mats.add(Mat(o.name, faceCount))
        }
        // px acumula os vértices de todos os objetos, então os índices de face já são globais
        val vertexCount = px.size / 3
        if (vertexCount == 0) warnings.add("Nada para exportar: não há objetos visíveis com faces.")

        val out = Out()
        // cabeçalho
        out.bytes(byteArrayOf('P'.code.toByte(), 'M'.code.toByte(), 'X'.code.toByte(), ' '.code.toByte()))
        out.float(2.0f)
        out.byte(8)
        out.byte(0) // codificação: UTF-16LE
        out.byte(0) // UV adicionais
        out.byte(4) // tamanho do índice de vértice
        out.byte(4) // textura
        out.byte(4) // material
        out.byte(4) // osso
        out.byte(4) // morph
        out.byte(4) // corpo rígido
        out.text(modelName); out.text(modelName)
        out.text("Criado no MMD Model Studio. Exportação PMX 2.0 inicial: sem texturas, pesos, morphs ou física."); out.text("")
        // vértices
        out.int(vertexCount)
        for (i in 0 until vertexCount) {
            out.float(px[i * 3]); out.float(px[i * 3 + 1]); out.float(px[i * 3 + 2])
            out.float(nx[i * 3]); out.float(nx[i * 3 + 1]); out.float(nx[i * 3 + 2])
            out.float(0f); out.float(0f) // UV
            out.byte(0) // BDEF1
            out.int(vb[i])  // osso
            out.float(1f) // escala do contorno
        }
        // faces
        out.int(faces.size)
        for (f in faces) out.int(f)
        // texturas
        out.int(0)
        // materiais
        out.int(mats.size)
        for (mt in mats) {
            out.text(mt.name); out.text(mt.name)
            out.float(0.8f); out.float(0.8f); out.float(0.8f); out.float(1f) // difusa
            out.float(0f); out.float(0f); out.float(0f); out.float(5f)      // especular + intensidade
            out.float(0.4f); out.float(0.4f); out.float(0.4f)               // ambiente
            out.byte(0x07) // dupla face, sombra no chão, mapa de sombra próprio
            out.float(0f); out.float(0f); out.float(0f); out.float(1f); out.float(1f) // cor e tamanho do contorno
            out.int(-1) // textura
            out.int(-1) // esfera
            out.byte(0) // modo da esfera
            out.byte(1) // toon interno
            out.byte(0) // toon01
            out.text("")
            out.int(mt.faceIndexCount)
        }
        // ossos (sem esqueleto no projeto: um osso センター na origem)
        val skeleton = if (project.bones.isEmpty()) listOf(Bone("b:center", "センター", "Center", null, Vec3(0f, 0f, 0f))) else project.bones
        val bIndex = HashMap<String, Int>()
        skeleton.forEachIndexed { i, b -> bIndex[b.id] = i }
        out.int(skeleton.size)
        for (b in skeleton) {
            out.text(b.name); out.text(if (b.nameEn.isEmpty()) b.name else b.nameEn)
            val bx = b.position.x * scale; val by = b.position.y * scale; val bz = -b.position.z * scale
            out.float(bx); out.float(by); out.float(bz)
            val parent = b.parentId?.let { bIndex[it] } ?: -1
            out.int(parent)
            out.int(0)  // camada
            out.short(if (parent < 0) 0x001E else 0x001A) // raiz: gira e move; demais: só giram. Sempre visível e habilitado; ponta por deslocamento
            val child = skeleton.firstOrNull { it.parentId == b.id }
            if (child != null) {
                out.float(child.position.x * scale - bx); out.float(child.position.y * scale - by); out.float(-child.position.z * scale - bz)
            } else {
                out.float(0f); out.float(0.5f); out.float(0f)
            }
        }
        // morphs
        out.int(0)
        // quadros de exibição
        val extraBones = skeleton.size - 1
        out.int(if (extraBones > 0) 3 else 2)
        out.text("Root"); out.text("Root"); out.byte(1)
        out.int(1); out.byte(0); out.int(0)
        out.text("表情"); out.text("Exp"); out.byte(1)
        out.int(0)
        if (extraBones > 0) {
            out.text("ボーン"); out.text("Bones"); out.byte(0)
            out.int(extraBones)
            for (i in 1 until skeleton.size) { out.byte(0); out.int(i) }
        }
        // corpos rígidos e juntas
        out.int(0)
        out.int(0)

        val data = out.bos.toByteArray()
        return PmxResult(data, PmxReport(vertexCount, faces.size / 3, mats.size, skeleton.size, data.size, warnings))
    }
}
