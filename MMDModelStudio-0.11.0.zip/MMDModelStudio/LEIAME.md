# MMD Model Studio — 0.11.0

Projeto Android (Kotlin + Jetpack Compose + OpenGL ES 2.0). Veja `docs/MMD-Model-Studio-Contexto.md`
para visão, arquitetura e estado real do que foi implementado e testado.

Compilar: pelo GitHub Actions (`build.yml`), sem computador. O APK sai como artifact `MMDModelStudio-apk`.
